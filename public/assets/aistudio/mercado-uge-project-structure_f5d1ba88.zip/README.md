# Mercado Uíge — Next-Generation Provincial Commerce

**Comprar • Vender • Conectar** — O maior mercado digital da província do Uíge, Angola.
Idioma: Português de Angola. Moeda: Kwanza (Kz).

> Nota: esta entrega é a versão **web fullstack** (Next.js + PostgreSQL via Drizzle) do projecto Mercado Uíge, com a mesma identidade visual, funcionalidades e arquitectura previstas para a app Android (Flutter/Supabase). Os produtos exibidos são **dados de demonstração (dados de teste)**.

## Identidade visual
- Azul eléctrico `#246BFD`, Azul profundo `#07111F`, Verde tecnológico `#B7F34A`, Branco, Cinza `#8B95A5`
- Modo escuro (padrão) e claro, animações fluidas, skeleton loading, splash screen com logótipo, onboarding em 3 passos.

## Funcionalidades implementadas
- **Página inicial**: logótipo + localização, pesquisa inteligente, notificações, banner promocional, categorias, produtos em destaque, mais vendidos, recentes, lojas recomendadas, ofertas especiais, serviços locais, patrocinados e recomendações personalizadas. Cards com foto, nome, preço Kz, preço anterior, desconto, loja, avaliação, localização, stock, favorito e adicionar ao carrinho.
- **Contas**: registo, login, recuperação de palavra-passe (código demo `MU-2025-UG`), sessões seguras (cookie httpOnly + hash), perfil, edição de dados, eliminação de conta. Tipos: cliente, comerciante, entregador, administrador (permissões verificadas no servidor).
- **Comércio**: criar lojas, publicar/editar/eliminar produtos, gestão de stock e preços, categorias, fotografias por URL (galeria/câmara), marca, estado novo/usado, localização, variantes, histórico de preços. Validação: sem preços negativos, sem stock inválido, sem produtos sem nome/descrição/foto.
- **Pesquisa inteligente interna**: sem acentos, sinónimos (telemovel→telemóvel), tolerância a erros (Levenshtein), “iphone barato” ordena por preço, “computador para jogos” prioriza gaming, “sapatos no Uíge” filtra por localização. Filtros por preço, localização, categoria, disponibilidade; ordenação; histórico; sugestões; pesquisa por voz (Web Speech API); sem resultados com alternativas.
- **Pesquisa externa**: separadores Plataforma / Internet / Google / YouTube / Facebook / Instagram. Usa APIs oficiais (Google Programmable Search, YouTube Data API, Bing Web Search) com chaves **apenas no servidor** (`/api/search`). Sem chaves, mostra mensagem clara + ligação oficial. Sem scraping, sem resultados simulados.
- **Carrinho e encomendas**: adicionar/remover/alterar quantidades, subtotal, entrega, total, confirmar encomenda, histórico, estados (Pendente → Confirmada → Em preparação → Pronta → Em entrega → Entregue / Cancelada), cancelamento conforme regras, stock actualizado no servidor com verificação, preços recalculados no servidor.
- **Painel do comerciante**: total de produtos, disponíveis, esgotados, encomendas, vendas, receita, gráfico de vendas, gestão de stock, publicação de anúncios.
- **Painel administrativo**: estatísticas, gerir utilizadores (suspender/reactivar), aprovar lojas/produtos, gerir categorias, denúncias, VIP, broadcast, receita.
- **Localização**: província/município/bairro, municípios do Uíge, introdução manual, sem localização obrigatória.
- **Notificações**: nova encomenda, mudança de estado, nova mensagem, broadcast admin.
- **Chat**: mensagem ao vendedor a partir do produto.
- **Segurança**: hash de palavras-passe (scrypt), sessões com token hash, validação no servidor, protecção de preços/stock, controlo de permissões por papel.

## Contas de demonstração
- Vendedor: `vendedor@mercadouige.ao` / `demo123` (comerciante com lojas e produtos)
- Admin: regista-te com `admin@mercadouige.ao` (qualquer palavra-passe ≥ 6 chars)
- Novos registos: escolhe o papel Cliente / Comerciante / Entregador.

## Instalação
```bash
npm install
cp .env.example .env   # ajusta DATABASE_URL
npx drizzle-kit push   # cria tabelas
npm run build
npm run start
```
O catálogo de demonstração é criado automaticamente na primeira visita (`/api/catalog`).

## Estrutura
- `src/db/schema.ts` — tabelas Drizzle (users, sessions, categories, stores, products, favorites, cart_items, orders, order_items, notifications, messages, search_history, reports, price_history)
- `src/lib/auth.ts` — hash scrypt + sessões
- `src/lib/utils.ts` — formatação Kz, normalização, pesquisa fuzzy
- `src/lib/seed.ts` — categorias, lojas e produtos de teste
- `src/app/api/` — auth, catalog, orders, search, misc (favoritos/carrinho/notificações/mensagens/lojas/categorias/denúncias), admin
- `src/app/page.tsx` — aplicação (splash, onboarding, home, pesquisa, lojas, produto, carrinho, encomendas, favoritos, perfil, vendedor, admin, notificações)

## APIs externas (opcional)
Define no `.env` do servidor: `GOOGLE_CSE_API_KEY`, `GOOGLE_CSE_ID`, `YOUTUBE_API_KEY`, `BING_SEARCH_API_KEY`. Sem elas, a pesquisa externa abre a fonte oficial no navegador.
