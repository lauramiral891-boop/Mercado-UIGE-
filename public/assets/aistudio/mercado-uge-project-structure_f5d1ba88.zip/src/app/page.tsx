"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search, Bell, MapPin, Heart, ShoppingCart, Home, Store, Package, User, Star, Plus, Minus, X, ChevronRight, ChevronLeft,
  Smartphone, Shirt, Home as HomeIcon, Apple, Hammer, Wrench, Sparkles, Dumbbell, Tag, Mic, Globe, Play, Share2, Camera, Search as SearchIcon,
  Truck, ShieldCheck, Zap, Headphones, Crown, Wallet, LogOut, Moon, Sun, Settings, Trash2, Edit3, Eye, TrendingUp, DollarSign, BarChart3,
  CheckCircle2, AlertCircle, Send, MessageCircle, Flag, Filter, SlidersHorizontal, ArrowRight, BadgeCheck, Clock, CreditCard, Banknote,
  LayoutGrid, List, PackageCheck, Store as StoreIcon, Users, Megaphone, Image as ImageIcon, ChevronDown, SearchX, RefreshCw, Menu
} from "lucide-react";
import { fmtKz, normalize, UIGE_MUNICIPALITIES, ORDER_STATUSES } from "@/lib/utils";

type Product = any;
type StoreT = any;
type UserT = any;

const CAT_ICONS: Record<string, any> = { smartphone: Smartphone, shirt: Shirt, home: HomeIcon, apple: Apple, hammer: Hammer, wrench: Wrench, sparkles: Sparkles, dumbbell: Dumbbell, tag: Tag };

function Logo({ size = 40 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="relative grid place-items-center rounded-2xl anim-glow" style={{ width: size, height: size, background: "linear-gradient(135deg,#246BFD,#0B2A5B)" }}>
        <ShoppingCart size={size * 0.55} color="#B7F34A" strokeWidth={2.4} />
        <span className="absolute -top-1 -right-1 text-[10px]">⭐</span>
      </div>
      <div className="leading-none">
        <div className="font-black text-lg tracking-tight">Mercado <span style={{ color: "#B7F34A" }}>Uíge</span></div>
        <div className="text-[10px] tracking-widest uppercase opacity-60">Comprar • Vender • Conectar</div>
      </div>
    </div>
  );
}

export default function Page() {
  const [booted, setBooted] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardStep, setOnboardStep] = useState(0);
  const [dark, setDark] = useState(true);
  const [view, setView] = useState("home");
  const [user, setUser] = useState<UserT>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [stores, setStores] = useState<StoreT[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<{ productId: string; qty: number }[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoreT | null>(null);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searchSource, setSearchSource] = useState("plataforma");
  const [external, setExternal] = useState<any>(null);
  const [filters, setFilters] = useState({ sort: "relevancia", maxPrice: "", location: "todas", category: "todas", available: false });
  const [showFilters, setShowFilters] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [toast, setToast] = useState("");
  const [authModal, setAuthModal] = useState<null | "login" | "register" | "recover">(null);
  const [bannerIdx, setBannerIdx] = useState(0);
  const [qty, setQty] = useState(1);
  const [variant, setVariant] = useState("");
  const [checkout, setCheckout] = useState({ address: "", payment: "Multicaixa Express", delivery: 1500 });
  const [sellerForm, setSellerForm] = useState({ name: "", description: "", price: "", oldPrice: "", stock: "", categoryName: "Electrónicos", brand: "", image: "", condition: "novo", municipality: "Uíge" });
  const [storeForm, setStoreForm] = useState({ name: "", description: "", municipality: "Uíge" });
  const [profileForm, setProfileForm] = useState({ name: "", phone: "", municipality: "Uíge", bairro: "" });
  const [adminData, setAdminData] = useState<any>(null);
  const [broadcast, setBroadcast] = useState({ title: "", body: "" });
  const [newCategory, setNewCategory] = useState("");
  const [chatBody, setChatBody] = useState("");
  const [reportReason, setReportReason] = useState("");
  const [showReport, setShowReport] = useState(false);
  const [authForm, setAuthForm] = useState({ name: "", email: "", phone: "", password: "", role: "cliente", municipality: "Uíge", bairro: "", code: "" });
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [location, setLocation] = useState("Uíge, Angola");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [listening, setListening] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(""), 2800); };

  // Boot / splash
  useEffect(() => {
    const seen = localStorage.getItem("mu_onboarded");
    const t = setTimeout(() => { setBooted(true); if (!seen) setShowOnboarding(true); }, 2200);
    return () => clearTimeout(t);
  }, []);

  // Load persisted
  useEffect(() => {
    try {
      setCart(JSON.parse(localStorage.getItem("mu_cart") || "[]"));
      setFavorites(JSON.parse(localStorage.getItem("mu_favs") || "[]"));
      setHistory(JSON.parse(localStorage.getItem("mu_history") || "[]"));
      setDark(localStorage.getItem("mu_dark") !== "0");
    } catch {}
  }, []);
  useEffect(() => { localStorage.setItem("mu_cart", JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem("mu_favs", JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { localStorage.setItem("mu_history", JSON.stringify(history)); }, [history]);
  useEffect(() => { localStorage.setItem("mu_dark", dark ? "1" : "0"); document.documentElement.classList.toggle("light", !dark); }, [dark]);

  const loadCatalog = async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/catalog");
      const j = await r.json();
      setProducts(j.products || []); setStores(j.stores || []); setCategories(j.categories || []);
    } catch { showToast("Erro ao carregar produtos."); }
    setLoading(false);
  };
  const loadMe = async () => {
    try {
      const r = await fetch("/api/auth");
      const j = await r.json();
      setUser(j.user);
      if (j.user) setProfileForm({ name: j.user.name || "", phone: j.user.phone || "", municipality: j.user.municipality || "Uíge", bairro: j.user.bairro || "" });
    } catch {}
  };
  const loadOrders = async () => { try { const r = await fetch("/api/orders"); const j = await r.json(); if (j.orders) setOrders(j.orders); } catch {} };
  const loadNotifs = async () => { try { const r = await fetch("/api/misc?kind=notifications"); const j = await r.json(); setNotifications(j.notifications || []); } catch {} };
  const loadFavsServer = async () => { try { const r = await fetch("/api/misc?kind=favorites"); const j = await r.json(); if (j.favorites?.length) setFavorites(j.favorites.map((p: any) => p.id)); } catch {} };

  useEffect(() => { loadCatalog(); loadMe(); }, []);
  useEffect(() => { if (user) { loadOrders(); loadNotifs(); loadFavsServer(); } }, [user]);
  useEffect(() => { const t = setInterval(() => setBannerIdx((i) => (i + 1) % 3), 4000); return () => clearInterval(t); }, []);

  const cartDetailed = useMemo(() => cart.map((c) => ({ ...c, product: products.find((p) => p.id === c.productId) })).filter((c) => c.product), [cart, products]);
  const cartCount = cart.reduce((s, c) => s + c.qty, 0);
  const subtotal = cartDetailed.reduce((s, c) => s + c.product.price * c.qty, 0);
  const unread = notifications.filter((n) => !n.isRead).length;

  const doSearch = async (q: string, source = searchSource) => {
    setQuery(q);
    if (!q.trim()) { setSearchResults([]); return; }
    if (source !== "plataforma") {
      const r = await fetch(`/api/search?q=${encodeURIComponent(q)}&source=${source}`);
      setExternal(await r.json());
      setSearchResults([]);
      return;
    }
    setExternal(null);
    const params = new URLSearchParams({ q, source: "plataforma", sort: filters.sort, location: filters.location, category: filters.category });
    if (filters.maxPrice) params.set("maxPrice", filters.maxPrice);
    if (filters.available) params.set("available", "1");
    const r = await fetch(`/api/search?${params}`);
    const j = await r.json();
    setSearchResults(j.results || []); setSuggestions(j.suggestions || []);
    if (q.trim() && !history.includes(q)) setHistory([q, ...history].slice(0, 8));
    setView("search");
  };

  const addToCart = async (p: Product, q = 1) => {
    if (Number(p.stock) <= 0) { showToast("Produto esgotado."); return; }
    const existing = cart.find((c) => c.productId === p.id);
    const newQty = (existing?.qty || 0) + q;
    if (newQty > Number(p.stock)) { showToast("Quantidade superior ao stock disponível."); return; }
    if (existing) setCart(cart.map((c) => c.productId === p.id ? { ...c, qty: newQty } : c));
    else setCart([...cart, { productId: p.id, qty: q }]);
    if (user) { try { await fetch("/api/misc?kind=cart", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: p.id }) }); } catch {} }
    showToast("Adicionado ao carrinho ✓");
  };

  const toggleFav = async (p: Product) => {
    const isFav = favorites.includes(p.id);
    setFavorites(isFav ? favorites.filter((f) => f !== p.id) : [...favorites, p.id]);
    if (user) { try { await fetch("/api/misc?kind=favorite", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: p.id }) }); } catch {} }
    showToast(isFav ? "Removido dos favoritos." : "Adicionado aos favoritos ❤️");
  };

  const handleAuth = async (action: string) => {
    setAuthError(""); setAuthLoading(true);
    try {
      const r = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ...authForm }) });
      const j = await r.json();
      if (!r.ok) { setAuthError(j.error || "Erro."); setAuthLoading(false); return; }
      if (j.user) { setUser(j.user); setAuthModal(null); showToast("Bem-vindo ao Mercado Uíge!"); loadOrders(); loadNotifs(); }
      else showToast(j.message || "Verifica o teu e-mail.");
    } catch { setAuthError("Erro de rede. Tenta novamente."); }
    setAuthLoading(false);
  };

  const logout = async () => { await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout" }) }); setUser(null); setOrders([]); setNotifications([]); showToast("Sessão terminada."); setView("home"); };

  const confirmOrder = async () => {
    if (!user) { setAuthModal("login"); return; }
    if (!checkout.address.trim()) { showToast("Indica o endereço de entrega."); return; }
    const r = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: cart, address: checkout.address, paymentMethod: checkout.payment, deliveryFee: checkout.delivery }) });
    const j = await r.json();
    if (!r.ok) { showToast(j.error || "Erro ao confirmar encomenda."); return; }
    setCart([]); loadOrders(); loadCatalog(); showToast("Encomenda confirmada com sucesso! 🎉"); setView("orders");
  };

  const changeOrderStatus = async (id: string, status: string) => {
    const r = await fetch("/api/orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    const j = await r.json();
    if (!r.ok) { showToast(j.error || "Erro."); return; }
    showToast(`Encomenda actualizada: ${status}`); loadOrders();
  };

  const publishProduct = async () => {
    if (!user) { setAuthModal("login"); return; }
    const r = await fetch("/api/catalog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sellerForm) });
    const j = await r.json();
    if (!r.ok) { showToast(j.error || "Erro ao publicar."); return; }
    showToast("Produto publicado com sucesso!"); setSellerForm({ name: "", description: "", price: "", oldPrice: "", stock: "", categoryName: "Electrónicos", brand: "", image: "", condition: "novo", municipality: "Uíge" }); loadCatalog();
  };

  const createStore = async () => {
    if (!user) { setAuthModal("login"); return; }
    const r = await fetch("/api/misc?kind=store", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(storeForm) });
    const j = await r.json();
    if (!r.ok) { showToast(j.error || "Erro."); return; }
    showToast("Loja criada!"); loadCatalog();
  };

  const loadAdmin = async () => { const r = await fetch("/api/admin"); const j = await r.json(); if (r.ok) setAdminData(j); else showToast(j.error || "Sem acesso."); };

  const adminAction = async (payload: any) => { await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }); loadAdmin(); showToast("Acção concluída."); };

  const voiceSearch = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { showToast("Pesquisa por voz não suportada neste navegador."); return; }
    const rec = new SR(); rec.lang = "pt-PT"; setListening(true);
    rec.onresult = (e: any) => { const t = e.results[0][0].transcript; setListening(false); doSearch(t); };
    rec.onerror = () => { setListening(false); showToast("Não foi possível ouvir. Tenta novamente."); };
    rec.start();
  };

  const sendMessage = async () => {
    if (!user) { setAuthModal("login"); return; }
    if (!chatBody.trim() || !selectedProduct?.sellerId) return;
    const r = await fetch("/api/misc?kind=message", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ receiverId: selectedProduct.sellerId, productId: selectedProduct.id, body: chatBody }) });
    if (r.ok) { showToast("Mensagem enviada ao vendedor."); setChatBody(""); } else showToast("Erro ao enviar.");
  };

  const featured = products.filter((p) => p.isFeatured);
  const bestSellers = [...products].sort((a, b) => (b.sales || 0) - (a.sales || 0)).slice(0, 8);
  const recent = [...products].slice(0, 8);
  const offers = products.filter((p) => p.discount > 0).sort((a, b) => b.discount - a.discount).slice(0, 8);
  const sponsored = products.filter((p) => p.isSponsored || p.discount >= 25).slice(0, 6);
  const personalized = favorites.length ? products.filter((p) => favorites.includes(p.id) || p.categoryName === products.find((x) => favorites.includes(x.id))?.categoryName).slice(0, 6) : bestSellers.slice(0, 6);

  const myProducts = user ? products.filter((p) => p.sellerId === user.id) : [];
  const myStores = user ? stores.filter((s) => s.ownerId === user.id) : [];
  const sellerRevenue = orders.filter((o) => o.status !== "Cancelada").reduce((s, o) => s + Number(o.total || 0), 0);

  const ProductCard = ({ p }: { p: Product }) => (
    <div className="group rounded-3xl overflow-hidden border anim-fadeUp" style={{ background: "var(--mu-card)", borderColor: "var(--mu-border)" }}>
      <div className="relative cursor-pointer" onClick={() => { setSelectedProduct(p); setQty(1); setView("product"); }}>
        <img src={p.image} alt={p.name} className="w-full h-44 object-cover group-hover:scale-105 transition duration-500" loading="lazy" />
        {p.discount > 0 && <span className="absolute top-2 left-2 text-xs font-black px-2 py-1 rounded-full" style={{ background: "#B7F34A", color: "#07111F" }}>-{p.discount}%</span>}
        {p.storeVip && <span className="absolute top-2 right-10 text-[10px] font-bold px-2 py-1 rounded-full bg-amber-400 text-black flex items-center gap-1"><Crown size={10} /> VIP</span>}
        <button onClick={(e) => { e.stopPropagation(); toggleFav(p); }} className="absolute top-2 right-2 w-8 h-8 grid place-items-center rounded-full bg-black/40 backdrop-blur">
          <Heart size={16} color={favorites.includes(p.id) ? "#FF4D6D" : "#fff"} fill={favorites.includes(p.id) ? "#FF4D6D" : "none"} />
        </button>
        {Number(p.stock) <= 0 && <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-1 rounded-full bg-red-500 text-white">Esgotado</span>}
        {Number(p.stock) > 0 && Number(p.stock) <= 5 && <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-1 rounded-full bg-orange-500 text-white">Só {p.stock} un.</span>}
      </div>
      <div className="p-3">
        <div className="text-[11px] opacity-60 flex items-center gap-1"><Store size={11} /> {p.storeName} • <MapPin size={11} /> {p.municipality}</div>
        <div className="font-bold text-sm leading-tight mt-1 line-clamp-2 cursor-pointer" onClick={() => { setSelectedProduct(p); setView("product"); }}>{p.name}</div>
        <div className="flex items-baseline gap-2 mt-1">
          <span className="font-black" style={{ color: "#B7F34A" }}>{fmtKz(p.price)}</span>
          {p.oldPrice && <span className="text-xs line-through opacity-50">{fmtKz(p.oldPrice)}</span>}
        </div>
        <div className="flex items-center gap-1 text-xs mt-1"><Star size={12} color="#FFB020" fill="#FFB020" /> {Number(p.rating).toFixed(1)} ({p.reviewsCount || 0}) <span className="opacity-50">• {p.condition === "usado" ? "Usado" : "Novo"}</span></div>
        <button onClick={() => addToCart(p)} disabled={Number(p.stock) <= 0} className="mt-3 w-full py-2 rounded-xl font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40" style={{ background: "#246BFD", color: "#fff" }}>
          <ShoppingCart size={15} /> Adicionar
        </button>
      </div>
    </div>
  );

  const SectionTitle = ({ title, action }: any) => (
    <div className="flex items-center justify-between mt-7 mb-3">
      <h2 className="font-black text-lg">{title}</h2>
      {action && <button onClick={action} className="text-sm font-bold flex items-center gap-1" style={{ color: "#246BFD" }}>Ver todos <ArrowRight size={14} /></button>}
    </div>
  );

  if (!booted) {
    return (
      <div className="min-h-screen grid place-items-center px-6" style={{ background: "radial-gradient(ellipse at top, #0B2A5B 0%, #07111F 60%)" }}>
        <div className="text-center anim-fadeUp">
          <div className="mx-auto w-28 h-28 grid place-items-center rounded-[2rem] anim-float anim-glow" style={{ background: "linear-gradient(135deg,#246BFD,#07111F)", border: "1px solid rgba(183,243,74,.4)" }}>
            <ShoppingCart size={56} color="#B7F34A" strokeWidth={2.2} />
          </div>
          <h1 className="mt-6 text-4xl font-black">Mercado <span style={{ color: "#B7F34A" }}>Uíge</span></h1>
          <p className="opacity-70 mt-1">Comprar • Vender • Conectar</p>
          <div className="mt-8 w-10 h-10 mx-auto rounded-full border-4 border-white/20 border-t-[#B7F34A]" style={{ animation: "mu-spin 1s linear infinite" }} />
          <p className="mt-4 text-sm opacity-60">A carregar a sua experiência…</p>
          <p className="mt-8 italic text-lg">Uíge cresce com o <span style={{ color: "#B7F34A" }}>comércio digital</span></p>
        </div>
      </div>
    );
  }

  if (showOnboarding) {
    const steps = [
      { title: "Tudo o que precisas, num só lugar!", desc: "Produtos, lojas e serviços locais do Uíge e de Angola, com entrega rápida.", icon: Zap },
      { title: "Pesquisa inteligente", desc: "Pesquisa por nome, marca, loja ou localização — mesmo com erros de ortografia. Ex.: “telemovel” encontra “telemóvel”.", icon: Search },
      { title: "Compra segura e vende fácil", desc: "Paga com Multicaixa Express, acompanha a encomenda e vende os teus produtos como comerciante.", icon: ShieldCheck },
    ];
    const S = steps[onboardStep];
    return (
      <div className="min-h-screen grid place-items-center px-6" style={{ background: "radial-gradient(ellipse at top, #0B2A5B 0%, #07111F 65%)" }}>
        <div className="w-full max-w-md text-center anim-fadeUp">
          <Logo size={52} />
          <div className="mt-10 mx-auto w-24 h-24 grid place-items-center rounded-3xl" style={{ background: "rgba(36,107,253,.15)", border: "1px solid rgba(36,107,253,.4)" }}>
            <S.icon size={44} color="#B7F34A" />
          </div>
          <h2 className="mt-6 text-2xl font-black">{S.title}</h2>
          <p className="mt-3 opacity-70 leading-relaxed">{S.desc}</p>
          <div className="flex justify-center gap-2 mt-6">{steps.map((_, i) => <span key={i} className="w-2.5 h-2.5 rounded-full" style={{ background: i === onboardStep ? "#B7F34A" : "rgba(255,255,255,.25)" }} />)}</div>
          <div className="flex gap-3 mt-8">
            <button onClick={() => { localStorage.setItem("mu_onboarded", "1"); setShowOnboarding(false); }} className="flex-1 py-3 rounded-2xl font-bold border border-white/20">Saltar</button>
            <button onClick={() => { if (onboardStep < 2) setOnboardStep(onboardStep + 1); else { localStorage.setItem("mu_onboarded", "1"); setShowOnboarding(false); } }} className="flex-1 py-3 rounded-2xl font-black" style={{ background: "#B7F34A", color: "#07111F" }}>{onboardStep < 2 ? "Avançar" : "Entrar no mercado"}</button>
          </div>
        </div>
      </div>
    );
  }

  const bg = dark ? "#07111F" : "#F4F7FB";
  const card = dark ? "#0E1E33" : "#FFFFFF";
  const border = dark ? "rgba(255,255,255,0.08)" : "rgba(7,17,31,0.08)";
  const textMain = dark ? "#FFFFFF" : "#07111F";

  return (
    <div className="min-h-screen pb-24 md:pb-0" style={{ background: bg, color: textMain }}>
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl border-b" style={{ background: dark ? "rgba(7,17,31,.85)" : "rgba(255,255,255,.9)", borderColor: border }}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => setView("home")}><Logo size={36} /></button>
          <button onClick={() => { const m = prompt("Província / Município (ex.: Uíge, Negage, Luanda):", location); if (m) setLocation(m); }} className="hidden sm:flex items-center gap-1 text-xs font-bold px-3 py-2 rounded-full border" style={{ borderColor: border }}>
            <MapPin size={13} color="#B7F34A" /> {location}
          </button>
          <div className="flex-1 flex items-center gap-2 rounded-2xl px-3 py-2.5 border" style={{ background: card, borderColor: border }}>
            <Search size={18} className="opacity-50 shrink-0" />
            <input ref={searchRef} value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doSearch(query)} placeholder="Pesquisar produtos, lojas ou serviços…" className="flex-1 bg-transparent outline-none text-sm min-w-0" />
            <button onClick={voiceSearch} className="shrink-0"><Mic size={17} color={listening ? "#FF4D6D" : "#246BFD"} /></button>
          </div>
          <button onClick={() => setDark(!dark)} className="w-10 h-10 grid place-items-center rounded-full border" style={{ borderColor: border }}>{dark ? <Sun size={18} /> : <Moon size={18} />}</button>
          <button onClick={() => { if (!user) { setAuthModal("login"); return; } setView("notifications"); }} className="relative w-10 h-10 grid place-items-center rounded-full border" style={{ borderColor: border }}>
            <Bell size={18} />{unread > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 grid place-items-center text-[10px] font-black rounded-full bg-red-500 text-white">{unread}</span>}
          </button>
          {user ? (
            <button onClick={() => setView("profile")} className="flex items-center gap-2">
              <span className="w-10 h-10 rounded-full grid place-items-center font-black text-white" style={{ background: "#246BFD" }}>{(user.name || "U").slice(0, 1).toUpperCase()}</span>
              <span className="hidden md:block text-left leading-tight"><span className="block text-sm font-bold">{user.name}</span><span className="block text-[11px] opacity-60 capitalize">{user.role}</span></span>
            </button>
          ) : (
            <button onClick={() => setAuthModal("login")} className="px-4 py-2.5 rounded-2xl font-bold text-sm text-white" style={{ background: "#246BFD" }}>Entrar</button>
          )}
        </div>
        <nav className="max-w-7xl mx-auto px-4 pb-2 flex gap-2 overflow-x-auto no-scrollbar text-sm font-bold">
          {[["home", "Início"], ["stores", "Lojas"], ["search", "Pesquisa"], ["orders", "Pedidos"], ["favorites", "Favoritos"], ["seller", "Vender"], ["admin", "Admin"]].map(([v, l]) => (
            <button key={v} onClick={() => { if (v === "admin") loadAdmin(); setView(v); }} className="px-4 py-2 rounded-full whitespace-nowrap" style={view === v ? { background: "#246BFD", color: "#fff" } : { background: card, border: `1px solid ${border}` }}>{l}</button>
          ))}
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-4">
        <div className="mt-3 text-center text-[11px] font-bold px-3 py-1.5 rounded-full border inline-flex mx-auto" style={{ borderColor: border, background: card }}>
          <span className="flex items-center gap-1"><BadgeCheck size={12} color="#B7F34A" /> Plataforma Mercado Uíge — os produtos listados são dados de demonstração para testes (dados de teste).</span>
        </div>

        {view === "home" && (
          <div className="anim-fadeUp">
            {/* Banner */}
            <div className="relative mt-4 rounded-[2rem] overflow-hidden" style={{ background: "linear-gradient(120deg,#246BFD,#0B2A5B 60%,#07111F)" }}>
              <div className="p-6 md:p-10 max-w-xl">
                <span className="text-xs font-black px-3 py-1 rounded-full" style={{ background: "#B7F34A", color: "#07111F" }}>ATÉ -70% ESTA SEMANA</span>
                <h1 className="mt-4 text-3xl md:text-5xl font-black leading-tight">Grandes Ofertas<br />em Uíge!</h1>
                <p className="mt-2 opacity-80 text-sm md:text-base">Telemóveis, moda, alimentos frescos e muito mais — com entrega local.</p>
                <button onClick={() => doSearch("oferta")} className="mt-5 px-6 py-3 rounded-2xl font-black text-white" style={{ background: "#246BFD" }}>Comprar agora</button>
              </div>
              <img src="https://images.pexels.com/photos/12360229/pexels-photo-12360229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" className="absolute right-0 top-0 h-full w-1/2 object-cover opacity-40 md:opacity-70" style={{ maskImage: "linear-gradient(to left, black, transparent)" }} />
              <div className="absolute bottom-3 right-4 flex gap-1.5">{[0, 1, 2].map((i) => <span key={i} className="w-2 h-2 rounded-full" style={{ background: i === bannerIdx ? "#B7F34A" : "rgba(255,255,255,.4)" }} />)}</div>
            </div>

            {/* Trust strip */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4">
              {[[Zap, "Pesquisa Inteligente", "Google e Internet"], [ShieldCheck, "Compra Segura", "e Confiável"], [Truck, "Entregas em Uíge", "Rápidas"], [Store, "Lojas Locais", "e Nacionais"], [Headphones, "Suporte 24h", "Sempre contigo"]].map(([Icon, t, s]: any) => (
                <div key={t} className="flex items-center gap-2 p-3 rounded-2xl border" style={{ background: card, borderColor: border }}><Icon size={20} color="#B7F34A" /><div className="leading-tight"><div className="text-xs font-black">{t}</div><div className="text-[10px] opacity-60">{s}</div></div></div>
              ))}
            </div>

            {/* Categories */}
            <SectionTitle title="Categorias" action={() => doSearch("")} />
            <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
              {categories.map((c) => { const Icon = CAT_ICONS[c.icon] || Tag; return (
                <button key={c.id} onClick={() => { setFilters({ ...filters, category: c.name }); doSearch(""); }} className="flex flex-col items-center gap-2 p-3 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <span className="w-12 h-12 grid place-items-center rounded-2xl" style={{ background: `${c.color}22`, color: c.color }}><Icon size={24} /></span>
                  <span className="text-[11px] font-bold text-center leading-tight">{c.name}</span>
                </button> ); })}
            </div>

            <SectionTitle title="Produtos em Destaque" action={() => doSearch("")} />
            {loading ? <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{[1, 2, 3, 4].map((i) => <div key={i} className="skeleton h-64 rounded-3xl" />)}</div> : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{featured.slice(0, 8).map((p) => <ProductCard key={p.id} p={p} />)}</div>
            )}

            <SectionTitle title="Ofertas Especiais" action={() => doSearch("oferta")} />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{offers.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>

            <SectionTitle title="Lojas Recomendadas" action={() => setView("stores")} />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {stores.slice(0, 4).map((s) => (
                <button key={s.id} onClick={() => { setSelectedStore(s); setView("store"); }} className="text-left p-4 rounded-3xl border flex gap-3 items-center" style={{ background: card, borderColor: border }}>
                  <img src={s.logo || "https://images.pexels.com/photos/12360229/pexels-photo-12360229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"} alt={s.name} className="w-14 h-14 rounded-2xl object-cover" />
                  <div className="min-w-0"><div className="font-black flex items-center gap-1 truncate">{s.name} {s.isVip && <Crown size={13} color="#FFB020" />}</div>
                    <div className="text-xs opacity-60 flex items-center gap-1"><Star size={11} color="#FFB020" fill="#FFB020" /> {Number(s.rating || 4.8).toFixed(1)} • {s.municipality}</div>
                    <div className="text-xs opacity-60 truncate">{s.description}</div></div>
                </button>
              ))}
            </div>

            <SectionTitle title="Mais Vendidos" action={() => doSearch("")} />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{bestSellers.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>

            <SectionTitle title="Produtos Recentes" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{recent.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>

            <SectionTitle title="Serviços Locais" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[["Entrega Expressa", "Entregas no Uíge em 24h", Truck], ["Reparação de Telemóveis", "Técnicos certificados", Wrench], ["Catering & Eventos", "Para festas e empresas", Apple], ["Limpeza Profissional", "Casas e escritórios", Sparkles]].map(([t, s, Icon]: any) => (
                <div key={t} className="p-4 rounded-3xl border" style={{ background: card, borderColor: border }}><Icon size={22} color="#246BFD" /><div className="font-black mt-2 text-sm">{t}</div><div className="text-xs opacity-60">{s}</div></div>
              ))}
            </div>

            <SectionTitle title="Produtos Patrocinados" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{sponsored.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>

            <SectionTitle title="Recomendações para Ti" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{personalized.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>
          </div>
        )}

        {view === "search" && (
          <div className="anim-fadeUp mt-4">
            <div className="flex flex-wrap gap-2">
              {[["plataforma", "Plataforma", Store], ["internet", "Internet", Globe], ["google", "Google", SearchIcon], ["youtube", "YouTube", Play], ["facebook", "Facebook", Share2], ["instagram", "Instagram", Camera]].map(([v, l, Icon]: any) => (
                <button key={v} onClick={() => { setSearchSource(v); if (query) doSearch(query, v); }} className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-bold" style={searchSource === v ? { background: "#246BFD", color: "#fff" } : { background: card, border: `1px solid ${border}` }}><Icon size={15} /> {l}</button>
              ))}
              <button onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-bold border" style={{ borderColor: border, background: card }}><SlidersHorizontal size={15} /> Filtros</button>
            </div>

            {showFilters && (
              <div className="mt-3 p-4 rounded-3xl border grid grid-cols-2 md:grid-cols-5 gap-3" style={{ background: card, borderColor: border }}>
                <label className="text-xs font-bold">Ordenar<select value={filters.sort} onChange={(e) => setFilters({ ...filters, sort: e.target.value })} className="mt-1 w-full p-2.5 rounded-xl border bg-transparent text-sm" style={{ borderColor: border }}><option value="relevancia">Relevância</option><option value="preco-asc">Preço: menor</option><option value="preco-desc">Preço: maior</option></select></label>
                <label className="text-xs font-bold">Preço máximo (Kz)<input type="number" value={filters.maxPrice} onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })} className="mt-1 w-full p-2.5 rounded-xl border bg-transparent text-sm" style={{ borderColor: border }} placeholder="Ex.: 100000" /></label>
                <label className="text-xs font-bold">Localização<select value={filters.location} onChange={(e) => setFilters({ ...filters, location: e.target.value })} className="mt-1 w-full p-2.5 rounded-xl border bg-transparent text-sm" style={{ borderColor: border }}><option value="todas">Todas</option>{UIGE_MUNICIPALITIES.map((m) => <option key={m} value={m}>{m}</option>)}</select></label>
                <label className="text-xs font-bold">Categoria<select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })} className="mt-1 w-full p-2.5 rounded-xl border bg-transparent text-sm" style={{ borderColor: border }}><option value="todas">Todas</option>{categories.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}</select></label>
                <label className="flex items-end gap-2 text-sm font-bold pb-2"><input type="checkbox" checked={filters.available} onChange={(e) => setFilters({ ...filters, available: e.target.checked })} /> Só disponíveis</label>
                <button onClick={() => doSearch(query)} className="col-span-2 md:col-span-5 py-3 rounded-2xl font-black text-white" style={{ background: "#246BFD" }}>Aplicar filtros</button>
              </div>
            )}

            {history.length > 0 && searchSource === "plataforma" && (
              <div className="mt-4 flex flex-wrap gap-2 items-center"><span className="text-xs font-bold opacity-60 flex items-center gap-1"><Clock size={12} /> Histórico:</span>{history.map((h) => <button key={h} onClick={() => doSearch(h)} className="text-xs px-3 py-1.5 rounded-full border" style={{ borderColor: border }}>{h}</button>)}</div>
            )}
            {suggestions.length > 0 && <div className="mt-2 text-xs opacity-70">Sugestões: {suggestions.join(" • ")}</div>}

            {searchSource !== "plataforma" && external && (
              <div className="mt-4 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                {!external.configured && <div className="flex gap-3"><AlertCircle color="#FFB020" /><div><div className="font-black">API externa não configurada</div><p className="text-sm opacity-70 mt-1">{external.message}</p><a href={external.officialLink} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Abrir pesquisa oficial <ArrowRight size={15} /></a></div></div>}
                {external.configured && external.results?.length > 0 && <div className="grid gap-3">{external.results.map((r: any, i: number) => <a key={i} href={r.link} target="_blank" rel="noreferrer" className="p-4 rounded-2xl border" style={{ borderColor: border }}><div className="text-[10px] font-black uppercase tracking-widest" style={{ color: "#246BFD" }}>{r.source}</div><div className="font-bold mt-1">{r.title}</div><p className="text-sm opacity-70 mt-1">{r.snippet}</p></a>)}</div>}
              </div>
            )}

            {searchSource === "plataforma" && (
              <>
                <div className="mt-4 text-sm opacity-70">{searchResults.length} resultado(s) para “{query}”</div>
                {searchResults.length === 0 ? (
                  <div className="mt-6 text-center py-16 rounded-3xl border" style={{ background: card, borderColor: border }}>
                    <SearchX size={40} className="mx-auto opacity-40" /><div className="font-black mt-3">Sem resultados</div><p className="text-sm opacity-60 mt-1">Tenta palavras mais simples ou explora as sugestões abaixo.</p>
                    <div className="flex flex-wrap justify-center gap-2 mt-4">{["telemóvel", "iphone barato", "computador para jogos", "sapatos no Uíge", "auscultadores"].map((s) => <button key={s} onClick={() => doSearch(s)} className="px-4 py-2 rounded-full text-sm font-bold" style={{ background: "#246BFD", color: "#fff" }}>{s}</button>)}</div>
                  </div>
                ) : <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">{searchResults.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
              </>
            )}
          </div>
        )}

        {view === "stores" && (
          <div className="anim-fadeUp mt-4">
            <h1 className="text-2xl font-black">Lojas</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">
              {stores.map((s) => (
                <button key={s.id} onClick={() => { setSelectedStore(s); setView("store"); }} className="text-left p-4 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <img src={s.logo || "https://images.pexels.com/photos/12360229/pexels-photo-12360229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"} alt={s.name} className="w-full h-32 object-cover rounded-2xl" />
                  <div className="font-black mt-3 flex items-center gap-1">{s.name} {s.isVip && <Crown size={14} color="#FFB020" />}</div>
                  <div className="text-xs opacity-60 mt-1">{s.description}</div>
                  <div className="text-xs mt-2 flex items-center gap-2"><span className="flex items-center gap-1"><Star size={11} color="#FFB020" fill="#FFB020" /> {Number(s.rating || 4.8).toFixed(1)}</span><span className="flex items-center gap-1"><MapPin size={11} /> {s.municipality}, {s.province || "Uíge"}</span></div>
                </button>
              ))}
            </div>
          </div>
        )}

        {view === "store" && selectedStore && (
          <div className="anim-fadeUp mt-4">
            <button onClick={() => setView("stores")} className="flex items-center gap-1 text-sm font-bold"><ChevronLeft size={16} /> Lojas</button>
            <div className="mt-3 p-5 rounded-3xl border flex gap-4 items-center" style={{ background: card, borderColor: border }}>
              <img src={selectedStore.logo || ""} alt="" className="w-20 h-20 rounded-3xl object-cover" />
              <div><h1 className="text-xl font-black flex items-center gap-2">{selectedStore.name} {selectedStore.isVip && <Crown size={16} color="#FFB020" />}</h1><p className="text-sm opacity-70 mt-1">{selectedStore.description}</p><div className="text-xs mt-2 flex gap-3"><span className="flex items-center gap-1"><Star size={12} color="#FFB020" fill="#FFB020" /> {Number(selectedStore.rating || 4.8).toFixed(1)}</span><span className="flex items-center gap-1"><MapPin size={12} /> {selectedStore.municipality}</span></div></div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">{products.filter((p) => p.storeId === selectedStore.id).map((p) => <ProductCard key={p.id} p={p} />)}</div>
          </div>
        )}

        {view === "product" && selectedProduct && (
          <div className="anim-slideIn mt-4 max-w-4xl mx-auto">
            <button onClick={() => setView("home")} className="flex items-center gap-1 text-sm font-bold"><ChevronLeft size={16} /> Voltar</button>
            <div className="grid md:grid-cols-2 gap-5 mt-3">
              <div className="rounded-[2rem] overflow-hidden border" style={{ borderColor: border }}><img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-80 object-cover" /></div>
              <div>
                <div className="text-xs opacity-60">{selectedProduct.storeName} • {selectedProduct.municipality}, {selectedProduct.province || "Uíge"} • {selectedProduct.condition === "usado" ? "Usado" : "Novo"}</div>
                <h1 className="text-2xl font-black mt-1">{selectedProduct.name}</h1>
                <div className="flex items-center gap-1 mt-2 text-sm"><Star size={15} color="#FFB020" fill="#FFB020" /> {Number(selectedProduct.rating).toFixed(1)} ({selectedProduct.reviewsCount || 0} avaliações) • {selectedProduct.sales || 0} vendidos</div>
                <div className="flex items-baseline gap-3 mt-3"><span className="text-3xl font-black" style={{ color: "#B7F34A" }}>{fmtKz(selectedProduct.price)}</span>{selectedProduct.oldPrice && <span className="line-through opacity-50">{fmtKz(selectedProduct.oldPrice)}</span>}{selectedProduct.discount > 0 && <span className="text-xs font-black px-2 py-1 rounded-full" style={{ background: "#B7F34A", color: "#07111F" }}>-{selectedProduct.discount}%</span>}</div>
                <p className="mt-3 text-sm opacity-80 leading-relaxed">{selectedProduct.description}</p>
                <div className="mt-3 text-sm">Marca: <b>{selectedProduct.brand || "—"}</b> • Stock: <b>{selectedProduct.stock} un.</b></div>
                {(selectedProduct.variants?.length > 0) && <div className="mt-3"><div className="text-xs font-bold opacity-60">Variante</div><div className="flex gap-2 mt-1">{selectedProduct.variants.map((v: string) => <button key={v} onClick={() => setVariant(v)} className="px-3 py-1.5 rounded-full text-sm font-bold border" style={{ borderColor: variant === v ? "#246BFD" : border, background: variant === v ? "#246BFD" : card, color: variant === v ? "#fff" : textMain }}>{v}</button>)}</div></div>}
                <div className="flex items-center gap-3 mt-5">
                  <div className="flex items-center gap-2 border rounded-2xl px-2 py-1" style={{ borderColor: border }}><button onClick={() => setQty(Math.max(1, qty - 1))}><Minus size={16} /></button><span className="font-black w-8 text-center">{qty}</span><button onClick={() => setQty(Math.min(Number(selectedProduct.stock), qty + 1))}><Plus size={16} /></button></div>
                  <button onClick={() => toggleFav(selectedProduct)} className="w-11 h-11 grid place-items-center rounded-2xl border" style={{ borderColor: border }}><Heart size={19} color={favorites.includes(selectedProduct.id) ? "#FF4D6D" : textMain} fill={favorites.includes(selectedProduct.id) ? "#FF4D6D" : "none"} /></button>
                </div>
                <div className="flex gap-2 mt-4">
                  <button onClick={() => addToCart(selectedProduct, qty)} disabled={Number(selectedProduct.stock) <= 0} className="flex-1 py-3.5 rounded-2xl font-black text-white disabled:opacity-40 flex items-center justify-center gap-2" style={{ background: "#246BFD" }}><ShoppingCart size={18} /> Adicionar ao carrinho</button>
                </div>
                <div className="mt-5 p-4 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black text-sm">Falar com o vendedor</div>
                  <div className="flex gap-2 mt-2"><input value={chatBody} onChange={(e) => setChatBody(e.target.value)} placeholder="Olá, ainda está disponível?" className="flex-1 p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><button onClick={sendMessage} className="px-4 rounded-2xl text-white" style={{ background: "#246BFD" }}><Send size={17} /></button></div>
                  {!showReport ? <button onClick={() => setShowReport(true)} className="mt-3 text-xs font-bold flex items-center gap-1 opacity-60"><Flag size={12} /> Denunciar produto</button> : (
                    <div className="mt-3 flex gap-2"><input value={reportReason} onChange={(e) => setReportReason(e.target.value)} placeholder="Motivo da denúncia" className="flex-1 p-2.5 rounded-xl border bg-transparent text-sm" style={{ borderColor: border }} /><button onClick={async () => { if (!user) { setAuthModal("login"); return; } await fetch("/api/misc?kind=report", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: selectedProduct.id, reason: reportReason }) }); showToast("Denúncia enviada. Obrigado."); setShowReport(false); }} className="px-4 rounded-xl font-bold text-white text-sm" style={{ background: "#FF4D6D" }}>Enviar</button></div>
                  )}
                </div>
              </div>
            </div>
            <SectionTitle title="Produtos semelhantes" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{products.filter((p) => p.id !== selectedProduct.id && (p.categoryName === selectedProduct.categoryName || normalize(p.name).split(" ")[0] === normalize(selectedProduct.name).split(" ")[0])).slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>
          </div>
        )}

        {view === "cart" && (
          <div className="anim-fadeUp mt-4 max-w-3xl mx-auto">
            <h1 className="text-2xl font-black">Carrinho ({cartCount})</h1>
            {cartDetailed.length === 0 ? <div className="mt-6 text-center py-16 rounded-3xl border" style={{ background: card, borderColor: border }}><ShoppingCart size={40} className="mx-auto opacity-40" /><div className="font-black mt-3">Carrinho vazio</div><button onClick={() => setView("home")} className="mt-4 px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Explorar produtos</button></div> : (
              <>
                <div className="grid gap-3 mt-4">{cartDetailed.map((c) => (
                  <div key={c.productId} className="flex gap-3 p-3 rounded-3xl border items-center" style={{ background: card, borderColor: border }}>
                    <img src={c.product.image} alt="" className="w-20 h-20 rounded-2xl object-cover" />
                    <div className="flex-1 min-w-0"><div className="font-bold text-sm truncate">{c.product.name}</div><div className="font-black mt-1" style={{ color: "#B7F34A" }}>{fmtKz(c.product.price)}</div>
                      <div className="flex items-center gap-2 mt-2"><button onClick={() => setCart(cart.map((x) => x.productId === c.productId ? { ...x, qty: Math.max(1, x.qty - 1) } : x))} className="w-8 h-8 grid place-items-center rounded-xl border" style={{ borderColor: border }}><Minus size={14} /></button><span className="font-black w-6 text-center">{c.qty}</span><button onClick={() => setCart(cart.map((x) => x.productId === c.productId ? { ...x, qty: Math.min(Number(c.product.stock), x.qty + 1) } : x))} className="w-8 h-8 grid place-items-center rounded-xl border" style={{ borderColor: border }}><Plus size={14} /></button>
                        <button onClick={() => setCart(cart.filter((x) => x.productId !== c.productId))} className="ml-auto text-red-400"><Trash2 size={16} /></button></div></div>
                  </div>))}</div>
                <div className="mt-5 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black">Resumo</div>
                  <div className="flex justify-between text-sm mt-3"><span>Subtotal</span><b>{fmtKz(subtotal)}</b></div>
                  <div className="flex justify-between text-sm mt-1"><span>Entrega (Uíge)</span><b>{fmtKz(checkout.delivery)}</b></div>
                  <div className="flex justify-between mt-3 pt-3 border-t font-black text-lg" style={{ borderColor: border }}><span>Total</span><span style={{ color: "#B7F34A" }}>{fmtKz(subtotal + checkout.delivery)}</span></div>
                  <label className="block text-xs font-bold mt-4">Endereço de entrega<input value={checkout.address} onChange={(e) => setCheckout({ ...checkout, address: e.target.value })} placeholder="Bairro, rua, número — Uíge" className="mt-1 w-full p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /></label>
                  <label className="block text-xs font-bold mt-3">Pagamento<select value={checkout.payment} onChange={(e) => setCheckout({ ...checkout, payment: e.target.value })} className="mt-1 w-full p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}><option>Multicaixa Express</option><option>Transferência</option><option>Pagamento na entrega</option></select></label>
                  <button onClick={confirmOrder} className="mt-5 w-full py-4 rounded-2xl font-black text-white flex items-center justify-center gap-2" style={{ background: "#246BFD" }}><PackageCheck size={19} /> Confirmar encomenda</button>
                </div>
              </>
            )}
          </div>
        )}

        {view === "orders" && (
          <div className="anim-fadeUp mt-4 max-w-3xl mx-auto">
            <h1 className="text-2xl font-black">Minhas Encomendas</h1>
            {!user ? <div className="mt-6 p-6 rounded-3xl border text-center" style={{ background: card, borderColor: border }}><div className="font-black">Faz login para veres as tuas encomendas.</div><button onClick={() => setAuthModal("login")} className="mt-4 px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Entrar</button></div> : orders.length === 0 ? <div className="mt-6 text-center py-16 rounded-3xl border" style={{ background: card, borderColor: border }}><Package size={40} className="mx-auto opacity-40" /><div className="font-black mt-3">Ainda sem encomendas</div></div> : (
              <div className="grid gap-3 mt-4">{orders.map((o) => (
                <div key={o.id} className="p-4 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="flex justify-between items-center"><span className="font-black">#{o.code}</span><span className="text-xs font-black px-3 py-1 rounded-full" style={{ background: o.status === "Entregue" ? "#B7F34A" : o.status === "Cancelada" ? "#FF4D6D" : "#246BFD", color: o.status === "Entregue" ? "#07111F" : "#fff" }}>{o.status}</span></div>
                  <div className="text-sm mt-2">{o.items?.map((it: any) => <div key={it.id} className="flex justify-between"><span>{it.qty}× {it.productName}</span><b>{fmtKz(it.price * it.qty)}</b></div>)}</div>
                  <div className="flex justify-between mt-3 pt-3 border-t text-sm" style={{ borderColor: border }}><span>Total</span><b style={{ color: "#B7F34A" }}>{fmtKz(o.total)}</b></div>
                  <div className="flex flex-wrap gap-1.5 mt-3">{ORDER_STATUSES.map((s) => <button key={s} onClick={() => changeOrderStatus(o.id, s)} className="text-[10px] px-2.5 py-1.5 rounded-full font-bold border" style={{ borderColor: o.status === s ? "#B7F34A" : border, background: o.status === s ? "#B7F34A" : "transparent", color: o.status === s ? "#07111F" : textMain }}>{s}</button>)}</div>
                </div>))}</div>
            )}
          </div>
        )}

        {view === "favorites" && (
          <div className="anim-fadeUp mt-4">
            <h1 className="text-2xl font-black">Favoritos ({favorites.length})</h1>
            {products.filter((p) => favorites.includes(p.id)).length === 0 ? <div className="mt-6 text-center py-16 rounded-3xl border" style={{ background: card, borderColor: border }}><Heart size={40} className="mx-auto opacity-40" /><div className="font-black mt-3">Sem favoritos ainda</div><p className="text-sm opacity-60">Toca no coração de um produto para o guardar aqui.</p></div> : <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">{products.filter((p) => favorites.includes(p.id)).map((p) => <ProductCard key={p.id} p={p} />)}</div>}
          </div>
        )}

        {view === "profile" && (
          <div className="anim-fadeUp mt-4 max-w-2xl mx-auto">
            {!user ? <div className="p-8 rounded-3xl border text-center" style={{ background: card, borderColor: border }}><User size={40} className="mx-auto opacity-40" /><div className="font-black mt-3 text-lg">Entra para acederes ao perfil</div><div className="flex gap-2 justify-center mt-4"><button onClick={() => setAuthModal("login")} className="px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Entrar</button><button onClick={() => setAuthModal("register")} className="px-6 py-3 rounded-2xl font-bold border" style={{ borderColor: border }}>Criar conta</button></div></div> : (
              <>
                <div className="p-5 rounded-3xl border flex items-center gap-4" style={{ background: "linear-gradient(120deg,#246BFD,#0B2A5B)", color: "#fff" }}>
                  <span className="w-16 h-16 rounded-full grid place-items-center text-2xl font-black bg-white/20">{(user.name || "U").slice(0, 1)}</span>
                  <div><div className="font-black text-lg flex items-center gap-1">{user.name} <BadgeCheck size={16} color="#B7F34A" /></div><div className="text-sm opacity-80 capitalize">{user.role === "cliente" ? "Cliente Premium" : user.role}</div><div className="text-xs opacity-70">{user.email}</div></div>
                </div>
                <div className="mt-3 p-4 rounded-3xl border flex items-center justify-between" style={{ background: "linear-gradient(120deg,#FFB020,#FF7A45)", color: "#07111F" }}>
                  <div className="flex items-center gap-2"><Wallet size={22} /><div><div className="text-xs font-bold">Saldo da Carteira</div><div className="font-black text-xl">{fmtKz(user.walletBalance || 12500)}</div></div></div>
                  <button onClick={() => showToast("Recarga via Multicaixa Express em breve. Saldo de demonstração.")} className="px-5 py-2.5 rounded-full font-black bg-white text-black text-sm">Recarregar</button>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-3">
                  {[[orders.length, "Encomendas", Package], [myStores.length, "Lojas", Store], [favorites.length, "Favoritos", Heart]].map(([n, l, Icon]: any) => <div key={l} className="p-4 rounded-3xl border text-center" style={{ background: card, borderColor: border }}><Icon size={20} className="mx-auto" color="#246BFD" /><div className="font-black text-xl mt-1">{n}</div><div className="text-xs opacity-60">{l}</div></div>)}
                </div>
                <div className="mt-4 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black">Editar perfil</div>
                  <div className="grid gap-3 mt-3">
                    <input value={profileForm.name} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} placeholder="Nome" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                    <input value={profileForm.phone} onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })} placeholder="Telefone" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                    <select value={profileForm.municipality} onChange={(e) => setProfileForm({ ...profileForm, municipality: e.target.value })} className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}>{UIGE_MUNICIPALITIES.map((m) => <option key={m}>{m}</option>)}</select>
                    <input value={profileForm.bairro} onChange={(e) => setProfileForm({ ...profileForm, bairro: e.target.value })} placeholder="Bairro" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                    <button onClick={async () => { const r = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "update", ...profileForm }) }); const j = await r.json(); if (r.ok) { setUser(j.user); showToast("Perfil actualizado."); } else showToast(j.error); }} className="py-3 rounded-2xl font-black text-white" style={{ background: "#246BFD" }}>Guardar alterações</button>
                  </div>
                </div>
                <div className="mt-4 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black">Configurações</div>
                  <div className="grid gap-2 mt-3 text-sm font-bold">
                    <button onClick={() => setDark(!dark)} className="flex justify-between items-center p-3 rounded-2xl border" style={{ borderColor: border }}><span className="flex items-center gap-2">{dark ? <Moon size={16} /> : <Sun size={16} />} Modo {dark ? "Escuro" : "Claro"}</span><span className="w-11 h-6 rounded-full p-0.5" style={{ background: dark ? "#246BFD" : "#ccc" }}><span className="block w-5 h-5 rounded-full bg-white" style={{ transform: dark ? "translateX(20px)" : "none" }} /></span></button>
                    <button onClick={() => setView("seller")} className="flex justify-between p-3 rounded-2xl border" style={{ borderColor: border }}><span>Painel do Comerciante</span><ChevronRight size={16} /></button>
                    <button onClick={() => setView("admin")} className="flex justify-between p-3 rounded-2xl border" style={{ borderColor: border }}><span>Painel Administrativo</span><ChevronRight size={16} /></button>
                    <button onClick={logout} className="flex justify-between p-3 rounded-2xl border text-red-400" style={{ borderColor: border }}><span className="flex items-center gap-2"><LogOut size={16} /> Terminar sessão</span></button>
                    <button onClick={async () => { if (!confirm("Eliminar a tua conta? Esta acção é irreversível.")) return; await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "delete" }) }); setUser(null); showToast("Conta eliminada."); }} className="flex justify-between p-3 rounded-2xl border text-red-400" style={{ borderColor: border }}><span className="flex items-center gap-2"><Trash2 size={16} /> Eliminar conta</span></button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {view === "seller" && (
          <div className="anim-fadeUp mt-4">
            <h1 className="text-2xl font-black">Painel do Comerciante</h1>
            {!user ? <div className="mt-4 p-6 rounded-3xl border text-center" style={{ background: card, borderColor: border }}><div className="font-black">Faz login como comerciante para gerires a tua loja.</div><button onClick={() => setAuthModal("register")} className="mt-4 px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Criar conta de comerciante</button></div> : (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                  {[[myProducts.length, "Total de produtos", Package], [myProducts.filter((p) => Number(p.stock) > 0).length, "Disponíveis", CheckCircle2], [myProducts.filter((p) => Number(p.stock) <= 0).length, "Esgotados", AlertCircle], [fmtKz(sellerRevenue), "Receita", DollarSign]].map(([n, l, Icon]: any) => <div key={l} className="p-4 rounded-3xl border" style={{ background: card, borderColor: border }}><Icon size={20} color="#246BFD" /><div className="font-black text-xl mt-2">{n}</div><div className="text-xs opacity-60">{l}</div></div>)}
                </div>
                <div className="mt-4 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black flex items-center gap-2"><BarChart3 size={18} /> Vendas (últimos 7 dias)</div>
                  <div className="flex items-end gap-2 h-28 mt-4">{[40, 65, 50, 80, 60, 95, 75].map((h, i) => <div key={i} className="flex-1 rounded-t-xl" style={{ height: `${h}%`, background: i === 5 ? "#B7F34A" : "#246BFD" }} />)}</div>
                  <div className="flex justify-between text-[10px] opacity-50 mt-1"><span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span></div>
                </div>
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                    <div className="font-black">Criar loja</div>
                    <div className="grid gap-2 mt-3">
                      <input value={storeForm.name} onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })} placeholder="Nome da loja" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                      <input value={storeForm.description} onChange={(e) => setStoreForm({ ...storeForm, description: e.target.value })} placeholder="Descrição" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                      <select value={storeForm.municipality} onChange={(e) => setStoreForm({ ...storeForm, municipality: e.target.value })} className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}>{UIGE_MUNICIPALITIES.map((m) => <option key={m}>{m}</option>)}</select>
                      <button onClick={createStore} className="py-3 rounded-2xl font-black text-white" style={{ background: "#246BFD" }}>Criar loja</button>
                    </div>
                  </div>
                  <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                    <div className="font-black">Publicar produto</div>
                    <div className="grid gap-2 mt-3">
                      <input value={sellerForm.name} onChange={(e) => setSellerForm({ ...sellerForm, name: e.target.value })} placeholder="Nome do produto *" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                      <textarea value={sellerForm.description} onChange={(e) => setSellerForm({ ...sellerForm, description: e.target.value })} placeholder="Descrição *" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} rows={2} />
                      <div className="grid grid-cols-2 gap-2"><input type="number" value={sellerForm.price} onChange={(e) => setSellerForm({ ...sellerForm, price: e.target.value })} placeholder="Preço (Kz) *" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><input type="number" value={sellerForm.oldPrice} onChange={(e) => setSellerForm({ ...sellerForm, oldPrice: e.target.value })} placeholder="Preço anterior" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /></div>
                      <div className="grid grid-cols-2 gap-2"><input type="number" value={sellerForm.stock} onChange={(e) => setSellerForm({ ...sellerForm, stock: e.target.value })} placeholder="Stock *" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><input value={sellerForm.brand} onChange={(e) => setSellerForm({ ...sellerForm, brand: e.target.value })} placeholder="Marca" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /></div>
                      <div className="grid grid-cols-2 gap-2"><select value={sellerForm.categoryName} onChange={(e) => setSellerForm({ ...sellerForm, categoryName: e.target.value })} className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}>{categories.map((c) => <option key={c.id}>{c.name}</option>)}</select><select value={sellerForm.condition} onChange={(e) => setSellerForm({ ...sellerForm, condition: e.target.value })} className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}><option value="novo">Novo</option><option value="usado">Usado</option></select></div>
                      <input value={sellerForm.image} onChange={(e) => setSellerForm({ ...sellerForm, image: e.target.value })} placeholder="URL da fotografia * (galeria/câmara)" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
                      <div className="flex flex-wrap gap-1.5">{["https://images.pexels.com/photos/12360229/pexels-photo-12360229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", "https://images.pexels.com/photos/8979071/pexels-photo-8979071.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940", "https://images.pexels.com/photos/33481395/pexels-photo-33481395.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"].map((u) => <button key={u} onClick={() => setSellerForm({ ...sellerForm, image: u })} className="text-[10px] px-2 py-1 rounded-full border" style={{ borderColor: border }}>Usar foto demo</button>)}</div>
                      <button onClick={publishProduct} className="py-3 rounded-2xl font-black" style={{ background: "#B7F34A", color: "#07111F" }}>Publicar anúncio</button>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-5 rounded-3xl border" style={{ background: card, borderColor: border }}>
                  <div className="font-black">Meus produtos ({myProducts.length})</div>
                  <div className="grid gap-2 mt-3">{myProducts.map((p) => <div key={p.id} className="flex items-center gap-3 p-2 rounded-2xl border" style={{ borderColor: border }}><img src={p.image} alt="" className="w-12 h-12 rounded-xl object-cover" /><div className="flex-1 min-w-0"><div className="font-bold text-sm truncate">{p.name}</div><div className="text-xs opacity-60">{fmtKz(p.price)} • Stock: {p.stock}</div></div><button onClick={async () => { const ns = prompt("Novo stock:", String(p.stock)); if (ns !== null) { await fetch("/api/catalog", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: p.id, stock: Number(ns) }) }); loadCatalog(); } }} className="text-xs font-bold px-3 py-2 rounded-xl border" style={{ borderColor: border }}>Stock</button><button onClick={async () => { if (!confirm("Eliminar produto?")) return; await fetch("/api/catalog", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: p.id }) }); loadCatalog(); showToast("Produto eliminado."); }} className="text-red-400"><Trash2 size={16} /></button></div>)}</div>
                </div>
              </>
            )}
          </div>
        )}

        {view === "admin" && (
          <div className="anim-fadeUp mt-4">
            <h1 className="text-2xl font-black flex items-center gap-2"><ShieldCheck color="#B7F34A" /> Painel Administrativo</h1>
            {user?.role !== "admin" ? <div className="mt-4 p-6 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Acesso restrito.</div><p className="text-sm opacity-70 mt-1">Apenas administradores podem aceder. Regista-te com <b>admin@mercadouige.ao</b> para obter acesso de demonstração, ou entra como comerciante para o painel de vendedor.</p><button onClick={() => setAuthModal("register")} className="mt-4 px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Registar como admin (demo)</button></div> : (
              <>
                {!adminData ? <button onClick={loadAdmin} className="mt-4 px-6 py-3 rounded-2xl font-bold text-white" style={{ background: "#246BFD" }}>Carregar estatísticas</button> : (
                  <>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                      {[[adminData.stats.users, "Utilizadores", Users], [adminData.stats.stores, "Lojas", Store], [adminData.stats.products, "Produtos", Package], [fmtKz(adminData.stats.revenue), "Receita total", DollarSign]].map(([n, l, Icon]: any) => <div key={l} className="p-4 rounded-3xl border" style={{ background: card, borderColor: border }}><Icon size={20} color="#246BFD" /><div className="font-black text-xl mt-2">{n}</div><div className="text-xs opacity-60">{l}</div></div>)}
                    </div>
                    <div className="grid md:grid-cols-2 gap-4 mt-4">
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Utilizadores</div>{adminData.users.map((u: any) => <div key={u.id} className="flex justify-between items-center py-2 border-b text-sm" style={{ borderColor: border }}><span><b>{u.name}</b> <span className="opacity-50">({u.role})</span></span><button onClick={() => adminAction({ action: "suspend", userId: u.id, current: u.isSuspended })} className="text-xs font-bold px-3 py-1.5 rounded-full" style={{ background: u.isSuspended ? "#B7F34A" : "#FF4D6D", color: u.isSuspended ? "#07111F" : "#fff" }}>{u.isSuspended ? "Reactivar" : "Suspender"}</button></div>)}</div>
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Lojas</div>{adminData.stores.map((s: any) => <div key={s.id} className="flex justify-between items-center py-2 border-b text-sm" style={{ borderColor: border }}><span><b>{s.name}</b> {s.isVip && <Crown size={12} color="#FFB020" />}</span><button onClick={() => adminAction({ action: "vip-store", storeId: s.id, current: s.isVip })} className="text-xs font-bold px-3 py-1.5 rounded-full border" style={{ borderColor: border }}>{s.isVip ? "Remover VIP" : "Tornar VIP"}</button></div>)}</div>
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Produtos</div>{adminData.products.slice(0, 10).map((p: any) => <div key={p.id} className="flex justify-between items-center py-2 border-b text-sm" style={{ borderColor: border }}><span className="truncate"><b>{p.name}</b> • {fmtKz(p.price)}</span><button onClick={() => adminAction({ action: "reject-product", productId: p.id })} className="text-xs font-bold text-red-400">Remover</button></div>)}</div>
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Denúncias ({adminData.reports.length})</div>{adminData.reports.map((r: any) => <div key={r.id} className="flex justify-between py-2 border-b text-sm" style={{ borderColor: border }}><span>{r.reason || "Sem motivo"} <span className="opacity-50">({r.status})</span></span><button onClick={() => adminAction({ action: "resolve-report", reportId: r.id })} className="text-xs font-bold" style={{ color: "#B7F34A" }}>Resolver</button></div>)}</div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4 mt-4">
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black flex items-center gap-2"><Megaphone size={17} /> Publicidade / Broadcast</div><div className="grid gap-2 mt-3"><input value={broadcast.title} onChange={(e) => setBroadcast({ ...broadcast, title: e.target.value })} placeholder="Título" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><input value={broadcast.body} onChange={(e) => setBroadcast({ ...broadcast, body: e.target.value })} placeholder="Mensagem para todos os utilizadores" className="p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><button onClick={() => adminAction({ action: "broadcast", ...broadcast })} className="py-3 rounded-2xl font-black text-white" style={{ background: "#246BFD" }}>Enviar a todos</button></div></div>
                      <div className="p-5 rounded-3xl border" style={{ background: card, borderColor: border }}><div className="font-black">Nova categoria</div><div className="flex gap-2 mt-3"><input value={newCategory} onChange={(e) => setNewCategory(e.target.value)} placeholder="Nome da categoria" className="flex-1 p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} /><button onClick={async () => { await fetch("/api/misc?kind=category", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newCategory }) }); setNewCategory(""); loadCatalog(); showToast("Categoria criada."); }} className="px-5 rounded-2xl font-black" style={{ background: "#B7F34A", color: "#07111F" }}>Adicionar</button></div></div>
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        )}

        {view === "notifications" && (
          <div className="anim-fadeUp mt-4 max-w-2xl mx-auto">
            <div className="flex justify-between items-center"><h1 className="text-2xl font-black">Notificações</h1><button onClick={async () => { await fetch("/api/misc?kind=notif-read", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }); loadNotifs(); }} className="text-sm font-bold" style={{ color: "#246BFD" }}>Marcar todas como lidas</button></div>
            <div className="grid gap-2 mt-4">{notifications.length === 0 ? <div className="p-8 rounded-3xl border text-center" style={{ background: card, borderColor: border }}><Bell size={36} className="mx-auto opacity-40" /><div className="font-black mt-2">Sem notificações</div></div> : notifications.map((n) => <div key={n.id} className="p-4 rounded-3xl border" style={{ background: n.isRead ? card : "rgba(36,107,253,.12)", borderColor: border }}><div className="font-black text-sm">{n.title}</div><div className="text-sm opacity-70 mt-1">{n.body}</div><div className="text-[11px] opacity-50 mt-1">{new Date(n.createdAt).toLocaleString("pt-AO")}</div></div>)}</div>
          </div>
        )}
      </main>

      {/* Bottom nav mobile */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t backdrop-blur-xl" style={{ background: dark ? "rgba(7,17,31,.92)" : "rgba(255,255,255,.95)", borderColor: border }}>
        <div className="grid grid-cols-5 items-end px-2 pb-2 pt-1">
          {[["home", Home, "Início"], ["stores", Store, "Lojas"], ["cart", ShoppingCart, "Carrinho"], ["orders", Package, "Pedidos"], ["profile", User, "Perfil"]].map(([v, Icon, l]: any) => (
            <button key={v} onClick={() => setView(v)} className="flex flex-col items-center gap-0.5 py-1.5 relative">
              {v === "cart" ? <span className="w-12 h-12 -mt-6 grid place-items-center rounded-full text-white shadow-lg" style={{ background: "#246BFD" }}><Icon size={22} />{cartCount > 0 && <span className="absolute top-0 right-3 w-5 h-5 grid place-items-center text-[10px] font-black rounded-full bg-red-500">{cartCount}</span>}</span> : <Icon size={21} color={view === v ? "#B7F34A" : textMain} />}
              <span className="text-[10px] font-bold" style={{ color: view === v ? "#B7F34A" : textMain }}>{l}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Auth modal */}
      {authModal && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setAuthModal(null)}>
          <div className="w-full max-w-md rounded-[2rem] p-6 anim-pop" style={{ background: card, color: textMain }} onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center"><Logo size={34} /><button onClick={() => setAuthModal(null)}><X size={20} /></button></div>
            <div className="flex gap-2 mt-5">
              {(["login", "register", "recover"] as const).map((m) => <button key={m} onClick={() => setAuthModal(m)} className="flex-1 py-2.5 rounded-xl text-sm font-black" style={authModal === m ? { background: "#246BFD", color: "#fff" } : { border: `1px solid ${border}` }}>{m === "login" ? "Entrar" : m === "register" ? "Registar" : "Recuperar"}</button>)}
            </div>
            <div className="grid gap-3 mt-5">
              {authModal === "register" && <input value={authForm.name} onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })} placeholder="Nome completo" className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />}
              <input value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} placeholder="E-mail" type="email" className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />
              {authModal === "register" && <input value={authForm.phone} onChange={(e) => setAuthForm({ ...authForm, phone: e.target.value })} placeholder="Telefone (ex.: 923 000 000)" className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />}
              {authModal !== "recover" && <input value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} placeholder="Palavra-passe" type="password" className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />}
              {authModal === "register" && <>
                <select value={authForm.role} onChange={(e) => setAuthForm({ ...authForm, role: e.target.value })} className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}><option value="cliente">Cliente</option><option value="comerciante">Comerciante</option><option value="entregador">Entregador</option><option value="admin">Administrador (demo)</option></select>
                <select value={authForm.municipality} onChange={(e) => setAuthForm({ ...authForm, municipality: e.target.value })} className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }}>{UIGE_MUNICIPALITIES.map((m) => <option key={m}>{m}</option>)}</select>
              </>}
              {authModal === "recover" && <input value={authForm.code} onChange={(e) => setAuthForm({ ...authForm, code: e.target.value })} placeholder="Código (demo: MU-2025-UG)" className="p-3.5 rounded-2xl border bg-transparent text-sm" style={{ borderColor: border }} />}
              {authError && <div className="text-sm font-bold text-red-400 flex items-center gap-1"><AlertCircle size={14} /> {authError}</div>}
              <button disabled={authLoading} onClick={() => handleAuth(authModal === "login" ? "login" : authModal === "register" ? "register" : authForm.code ? "reset" : "recover")} className="py-3.5 rounded-2xl font-black text-white disabled:opacity-50" style={{ background: "#246BFD" }}>{authLoading ? "A processar…" : authModal === "login" ? "Entrar" : authModal === "register" ? "Criar conta" : authForm.code ? "Redefinir palavra-passe" : "Enviar recuperação"}</button>
              <div className="text-[11px] opacity-60 text-center">Demo: vendedor@mercadouige.ao / demo123 • admin@mercadouige.ao (regista-te com este e-mail)</div>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="fixed bottom-24 md:bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl font-bold text-sm shadow-2xl anim-pop" style={{ background: "#B7F34A", color: "#07111F" }}>{toast}</div>}

      <footer className="hidden md:block mt-16 border-t py-8" style={{ borderColor: border }}>
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between gap-4 text-sm opacity-70">
          <span>© 2025 Mercado Uíge — O maior mercado digital da nossa província. Uíge cresce com o comércio digital.</span>
          <span>Comprar • Vender • Conectar — Preços em Kwanza (Kz)</span>
        </div>
      </footer>
    </div>
  );
}
