import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword, createSession, destroySession, currentUser, publicUser } from "@/lib/auth";

export async function GET() {
  const u = await currentUser();
  return NextResponse.json({ user: publicUser(u) });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = body.action;

  if (action === "register") {
    const { name, email, phone, password, role, municipality, bairro } = body;
    if (!name || !email || !password) return NextResponse.json({ error: "Nome, e-mail e palavra-passe são obrigatórios." }, { status: 400 });
    if (password.length < 6) return NextResponse.json({ error: "A palavra-passe deve ter pelo menos 6 caracteres." }, { status: 400 });
    const exists = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
    if (exists.length) return NextResponse.json({ error: "Já existe uma conta com este e-mail." }, { status: 409 });
    const allowedRoles = ["cliente", "comerciante", "entregador", "admin"];
    const safeRole = allowedRoles.includes(role) ? role : "cliente";
    // admin only via seed / manual DB — block self-registration as admin unless email is admin@mercadouige.ao
    const finalRole = safeRole === "admin" && email.toLowerCase() !== "admin@mercadouige.ao" ? "cliente" : safeRole;
    const [u] = await db.insert(users).values({
      name, email: email.toLowerCase(), phone: phone || null, passwordHash: hashPassword(password),
      role: finalRole, municipality: municipality || "Uíge", bairro: bairro || null, isVerified: true,
    }).returning();
    await createSession(u.id);
    await db.insert(notifications).values({ userId: u.id, title: "Bem-vindo ao Mercado Uíge!", body: "A tua conta foi criada com sucesso. Explora as melhores lojas da província.", type: "welcome" });
    return NextResponse.json({ user: publicUser(u) });
  }

  if (action === "login") {
    const { email, password } = body;
    if (!email || !password) return NextResponse.json({ error: "E-mail e palavra-passe são obrigatórios." }, { status: 400 });
    const rows = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
    const u = rows[0];
    if (!u || !verifyPassword(password, u.passwordHash)) return NextResponse.json({ error: "Credenciais inválidas. Verifica o e-mail e a palavra-passe." }, { status: 401 });
    if (u.isSuspended) return NextResponse.json({ error: "Conta suspensa. Contacta o suporte." }, { status: 403 });
    await createSession(u.id);
    return NextResponse.json({ user: publicUser(u) });
  }

  if (action === "logout") { await destroySession(); return NextResponse.json({ ok: true }); }

  if (action === "recover") {
    const { email } = body;
    const rows = await db.select().from(users).where(eq(users.email, (email || "").toLowerCase()));
    // Always return success to avoid enumeration, but create notification if exists
    if (rows[0]) {
      await db.insert(notifications).values({ userId: rows[0].id, title: "Recuperação de palavra-passe", body: "Recebeste um pedido de recuperação. Usa o código MU-2025-UG para redefinir a tua palavra-passe (demonstração).", type: "security" });
    }
    return NextResponse.json({ ok: true, message: "Se o e-mail existir, receberás instruções de recuperação." });
  }

  if (action === "reset") {
    const { email, code, password } = body;
    if (code !== "MU-2025-UG") return NextResponse.json({ error: "Código inválido." }, { status: 400 });
    if (!password || password.length < 6) return NextResponse.json({ error: "Palavra-passe muito curta." }, { status: 400 });
    await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.email, (email || "").toLowerCase()));
    return NextResponse.json({ ok: true });
  }

  if (action === "update") {
    const u = await currentUser();
    if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
    const { name, phone, municipality, bairro, avatar } = body;
    await db.update(users).set({ name: name ?? u.name, phone: phone ?? u.phone, municipality: municipality ?? u.municipality, bairro: bairro ?? u.bairro, avatar: avatar ?? u.avatar }).where(eq(users.id, u.id));
    const [fresh] = await db.select().from(users).where(eq(users.id, u.id));
    return NextResponse.json({ user: publicUser(fresh) });
  }

  if (action === "delete") {
    const u = await currentUser();
    if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
    await db.delete(users).where(eq(users.id, u.id));
    await destroySession();
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Acção desconhecida." }, { status: 400 });
}
