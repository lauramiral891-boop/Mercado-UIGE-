import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { favorites, cartItems, products, notifications, messages, users, stores, categories, reports, orders, orderItems } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { currentUser } from "@/lib/auth";

// Favorites + Cart + Notifications + Messages + Stores + Categories + Reports in one router via ?kind=
export async function GET(req: NextRequest) {
  const kind = req.nextUrl.searchParams.get("kind") || "favorites";
  const u = await currentUser();
  if (kind === "favorites") {
    if (!u) return NextResponse.json({ favorites: [] });
    const favs = await db.select().from(favorites).where(eq(favorites.userId, u.id));
    const ids = favs.map((f) => f.productId);
    const all = await db.select().from(products);
    return NextResponse.json({ favorites: all.filter((p) => ids.includes(p.id)).map((p) => ({ ...p, price: Number(p.price), oldPrice: p.oldPrice ? Number(p.oldPrice) : null, rating: Number(p.rating || 4.7) })) });
  }
  if (kind === "cart") {
    if (!u) return NextResponse.json({ items: [] });
    const items = await db.select().from(cartItems).where(eq(cartItems.userId, u.id));
    const out = [];
    for (const it of items) {
      const pr = (await db.select().from(products).where(eq(products.id, it.productId)))[0];
      if (pr) out.push({ id: it.id, productId: it.productId, qty: it.qty, product: { ...pr, price: Number(pr.price), oldPrice: pr.oldPrice ? Number(pr.oldPrice) : null, rating: Number(pr.rating || 4.7) } });
    }
    return NextResponse.json({ items: out });
  }
  if (kind === "notifications") {
    if (!u) return NextResponse.json({ notifications: [] });
    const rows = await db.select().from(notifications).where(eq(notifications.userId, u.id)).orderBy(desc(notifications.createdAt));
    return NextResponse.json({ notifications: rows });
  }
  if (kind === "messages") {
    if (!u) return NextResponse.json({ messages: [] });
    const rows = await db.select().from(messages).where(eq(messages.receiverId, u.id)).orderBy(desc(messages.createdAt));
    return NextResponse.json({ messages: rows });
  }
  if (kind === "stores") {
    const rows = await db.select().from(stores).where(eq(stores.isApproved, true));
    return NextResponse.json({ stores: rows });
  }
  if (kind === "categories") {
    const rows = await db.select().from(categories);
    return NextResponse.json({ categories: rows });
  }
  return NextResponse.json({ error: "kind inválido" }, { status: 400 });
}

export async function POST(req: NextRequest) {
  const kind = req.nextUrl.searchParams.get("kind") || "favorite";
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Faz login para continuar." }, { status: 401 });
  const b = await req.json().catch(() => ({}));

  if (kind === "favorite") {
    const existing = await db.select().from(favorites).where(and(eq(favorites.userId, u.id), eq(favorites.productId, b.productId)));
    if (existing.length) { await db.delete(favorites).where(eq(favorites.id, existing[0].id)); return NextResponse.json({ favorited: false }); }
    await db.insert(favorites).values({ userId: u.id, productId: b.productId });
    return NextResponse.json({ favorited: true });
  }
  if (kind === "cart") {
    const pr = (await db.select().from(products).where(eq(products.id, b.productId)))[0];
    if (!pr) return NextResponse.json({ error: "Produto não encontrado." }, { status: 404 });
    if (Number(pr.stock) <= 0) return NextResponse.json({ error: "Produto esgotado." }, { status: 400 });
    const existing = await db.select().from(cartItems).where(and(eq(cartItems.userId, u.id), eq(cartItems.productId, b.productId)));
    if (existing.length) {
      const newQty = existing[0].qty + 1;
      if (newQty > Number(pr.stock)) return NextResponse.json({ error: "Quantidade superior ao stock." }, { status: 400 });
      await db.update(cartItems).set({ qty: newQty }).where(eq(cartItems.id, existing[0].id));
    } else await db.insert(cartItems).values({ userId: u.id, productId: b.productId, qty: 1 });
    return NextResponse.json({ ok: true });
  }
  if (kind === "cart-update") {
    const it = (await db.select().from(cartItems).where(eq(cartItems.id, b.id)))[0];
    if (!it || it.userId !== u.id) return NextResponse.json({ error: "Item não encontrado." }, { status: 404 });
    const pr = (await db.select().from(products).where(eq(products.id, it.productId)))[0];
    if (b.qty <= 0) { await db.delete(cartItems).where(eq(cartItems.id, b.id)); return NextResponse.json({ ok: true }); }
    if (pr && b.qty > Number(pr.stock)) return NextResponse.json({ error: "Quantidade superior ao stock." }, { status: 400 });
    await db.update(cartItems).set({ qty: b.qty }).where(eq(cartItems.id, b.id));
    return NextResponse.json({ ok: true });
  }
  if (kind === "cart-remove") {
    await db.delete(cartItems).where(and(eq(cartItems.id, b.id), eq(cartItems.userId, u.id)));
    return NextResponse.json({ ok: true });
  }
  if (kind === "notif-read") {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, u.id));
    return NextResponse.json({ ok: true });
  }
  if (kind === "message") {
    if (!b.receiverId || !b.body?.trim()) return NextResponse.json({ error: "Mensagem vazia." }, { status: 400 });
    await db.insert(messages).values({ senderId: u.id, receiverId: b.receiverId, productId: b.productId || null, body: b.body.trim() });
    await db.insert(notifications).values({ userId: b.receiverId, title: "Nova mensagem", body: b.body.trim().slice(0, 120), type: "message" });
    return NextResponse.json({ ok: true });
  }
  if (kind === "store") {
    if (!b.name?.trim()) return NextResponse.json({ error: "Nome da loja obrigatório." }, { status: 400 });
    const [st] = await db.insert(stores).values({ ownerId: u.id, name: b.name.trim(), description: b.description || "", category: b.category || "Geral", municipality: b.municipality || u.municipality || "Uíge", bairro: b.bairro || null, logo: b.logo || null, isApproved: true }).returning();
    return NextResponse.json({ store: st });
  }
  if (kind === "category") {
    if (u.role !== "admin") return NextResponse.json({ error: "Apenas admin." }, { status: 403 });
    if (!b.name?.trim()) return NextResponse.json({ error: "Nome obrigatório." }, { status: 400 });
    const slug = b.name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-");
    const [c] = await db.insert(categories).values({ name: b.name.trim(), slug, icon: b.icon || "tag", color: b.color || "#246BFD" }).returning();
    return NextResponse.json({ category: c });
  }
  if (kind === "report") {
    await db.insert(reports).values({ reporterId: u.id, productId: b.productId || null, reason: b.reason || "" });
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "kind inválido" }, { status: 400 });
}
