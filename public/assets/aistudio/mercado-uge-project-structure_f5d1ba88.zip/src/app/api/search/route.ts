import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, stores, searchHistory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { smartSearch, normalize } from "@/lib/utils";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q") || "";
  const source = sp.get("source") || "plataforma";
  const sort = sp.get("sort") || "relevancia";
  const maxPrice = sp.get("maxPrice") ? Number(sp.get("maxPrice")) : undefined;
  const location = sp.get("location") || "todas";
  const category = sp.get("category") || "todas";
  const onlyAvailable = sp.get("available") === "1";

  if (source !== "plataforma") {
    // External search via official APIs — keys stay server-side
    const googleKey = process.env.GOOGLE_CSE_API_KEY;
    const googleCx = process.env.GOOGLE_CSE_ID;
    const youtubeKey = process.env.YOUTUBE_API_KEY;
    const bingKey = process.env.BING_SEARCH_API_KEY;
    const externalLinks: Record<string, string> = {
      google: `https://www.google.com/search?q=${encodeURIComponent(q + " Angola")}`,
      youtube: `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`,
      facebook: `https://www.facebook.com/search/top?q=${encodeURIComponent(q)}`,
      instagram: `https://www.instagram.com/explore/search/keyword/?q=${encodeURIComponent(q)}`,
      bing: `https://www.bing.com/search?q=${encodeURIComponent(q)}`,
      internet: `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
    };
    let results: any[] = [];
    let configured = false;
    try {
      if (source === "google" && googleKey && googleCx) {
        configured = true;
        const r = await fetch(`https://www.googleapis.com/customsearch/v1?key=${googleKey}&cx=${googleCx}&q=${encodeURIComponent(q)}&num=8`);
        const j = await r.json();
        results = (j.items || []).map((i: any) => ({ title: i.title, snippet: i.snippet, link: i.link, source: "Google" }));
      } else if (source === "youtube" && youtubeKey) {
        configured = true;
        const r = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=8&q=${encodeURIComponent(q)}&key=${youtubeKey}`);
        const j = await r.json();
        results = (j.items || []).map((i: any) => ({ title: i.snippet.title, snippet: i.snippet.description, link: `https://www.youtube.com/watch?v=${i.id.videoId}`, source: "YouTube", thumb: i.snippet.thumbnails?.default?.url }));
      } else if ((source === "bing" || source === "internet") && bingKey) {
        configured = true;
        const r = await fetch(`https://api.bing.microsoft.com/v7.0/search?q=${encodeURIComponent(q)}&count=8`, { headers: { "Ocp-Apim-Subscription-Key": bingKey } });
        const j = await r.json();
        results = (j.webPages?.value || []).map((i: any) => ({ title: i.name, snippet: i.snippet, link: i.url, source: "Bing" }));
      }
    } catch { /* fall through to message */ }
    return NextResponse.json({
      source, configured, results,
      message: configured ? undefined : `A API de ${source === "google" ? "Google" : source === "youtube" ? "YouTube" : source === "facebook" ? "Facebook" : source === "instagram" ? "Instagram" : "Bing"} ainda não está configurada no servidor. Abre a pesquisa oficial directamente no navegador ou usa a pesquisa interna da plataforma.`,
      officialLink: externalLinks[source] || externalLinks.internet,
    });
  }

  const prods = await db.select().from(products).where(eq(products.isApproved, true));
  const sts = await db.select().from(stores);
  const storeMap = new Map(sts.map((s) => [s.id, s]));
  const enriched = prods.map((p) => {
    const st = p.storeId ? storeMap.get(p.storeId) : null;
    return { ...p, price: Number(p.price), oldPrice: p.oldPrice ? Number(p.oldPrice) : null, rating: Number(p.rating || 4.7), storeName: st?.name || "Loja Uíge", discount: p.oldPrice ? Math.round((1 - Number(p.price) / Number(p.oldPrice)) * 100) : 0 };
  });
  const found = smartSearch(enriched, q, { sort, maxPrice, location, category, onlyAvailable });
  const suggestions = q ? enriched.filter((p) => normalize(p.name).includes(normalize(q).slice(0, 4))).slice(0, 5).map((p) => p.name) : [];
  const u = await currentUser();
  if (q && u) { try { await db.insert(searchHistory).values({ userId: u.id, query: q }); } catch {} }
  return NextResponse.json({ results: found.map((f) => f.item), suggestions, query: q });
}
