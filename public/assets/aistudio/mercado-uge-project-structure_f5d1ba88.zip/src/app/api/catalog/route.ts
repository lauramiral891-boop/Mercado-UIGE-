import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, stores, categories, users, priceHistory } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { CATEGORIES, SEED_PRODUCTS, SEED_STORES } from "@/lib/seed";

async function ensureSeed() {
  const cats = await db.select().from(categories);
  if (cats.length === 0) {
    for (const c of CATEGORIES) await db.insert(categories).values(c);
  }
  const prods = await db.select().from(products).limit(1);
  if (prods.length === 0) {
    // create demo seller
    const { hashPassword } = await import("@/lib/auth");
    let seller = (await db.select().from(users).where(eq(users.email, "vendedor@mercadouige.ao")))[0];
    if (!seller) {
      const [s] = await db.insert(users).values({ name: "Vendedor Demo", email: "vendedor@mercadouige.ao", passwordHash: hashPassword("demo123"), role: "comerciante", municipality: "Uíge" }).returning();
      seller = s;
    }
    const catRows = await db.select().from(categories);
    const catMap = new Map(catRows.map((c) => [c.name, c.id]));
    const storeIds: string[] = [];
    for (const s of SEED_STORES) {
      const [st] = await db.insert(stores).values({ ownerId: seller.id, name: s.name, description: s.description, category: s.category, municipality: s.municipality, bairro: s.bairro, rating: s.rating, isVip: s.isVip, logo: s.logo, isApproved: true }).returning();
      storeIds.push(st.id);
    }
    for (let i = 0; i < SEED_PRODUCTS.length; i++) {
      const p = SEED_PRODUCTS[i];
      const storeId = storeIds[i % storeIds.length];
      await db.insert(products).values({
        storeId, sellerId: seller.id, name: p.name, description: p.description, price: String(p.price), oldPrice: String(p.oldPrice),
        stock: p.stock, categoryId: catMap.get(p.categoryName) || null, categoryName: p.categoryName, brand: p.brand,
        image: p.image, municipality: p.municipality, rating: String(p.rating), reviewsCount: p.reviewsCount, sales: p.sales,
        isFeatured: !!p.isFeatured, isApproved: true, province: "Uíge",
      });
    }
  }
}

export async function GET() {
  await ensureSeed();
  const [prods, sts, cats] = await Promise.all([
    db.select().from(products).where(eq(products.isApproved, true)).orderBy(desc(products.createdAt)),
    db.select().from(stores).where(eq(stores.isApproved, true)),
    db.select().from(categories),
  ]);
  const storeMap = new Map(sts.map((s) => [s.id, s]));
  const enriched = prods.map((p) => {
    const st = p.storeId ? storeMap.get(p.storeId) : null;
    return {
      ...p,
      price: Number(p.price), oldPrice: p.oldPrice ? Number(p.oldPrice) : null,
      rating: Number(p.rating || 4.7), storeName: st?.name || "Loja Uíge", storeRating: st ? Number(st.rating || 4.8) : 4.8, storeVip: st?.isVip || false,
      discount: p.oldPrice ? Math.round((1 - Number(p.price) / Number(p.oldPrice)) * 100) : 0,
    };
  });
  return NextResponse.json({ products: enriched, stores: sts, categories: cats });
}

export async function POST(req: NextRequest) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Faz login para publicar produtos." }, { status: 401 });
  if (u.role !== "comerciante" && u.role !== "admin") return NextResponse.json({ error: "Apenas comerciantes podem publicar produtos." }, { status: 403 });
  const b = await req.json();
  const price = Number(b.price), stock = Number(b.stock);
  if (!b.name?.trim() || !b.description?.trim()) return NextResponse.json({ error: "Nome e descrição são obrigatórios." }, { status: 400 });
  if (!price || price <= 0) return NextResponse.json({ error: "Preço inválido. Não são permitidos preços negativos." }, { status: 400 });
  if (isNaN(stock) || stock < 0) return NextResponse.json({ error: "Stock inválido." }, { status: 400 });
  if (!b.image?.trim()) return NextResponse.json({ error: "Adiciona uma fotografia do produto." }, { status: 400 });

  let storeId = b.storeId || null;
  if (!storeId) {
    const mine = await db.select().from(stores).where(eq(stores.ownerId, u.id));
    if (mine[0]) storeId = mine[0].id;
    else {
      const [st] = await db.insert(stores).values({ ownerId: u.id, name: b.storeName || `Loja de ${u.name}`, description: "Loja criada no Mercado Uíge", municipality: b.municipality || u.municipality || "Uíge", isApproved: true }).returning();
      storeId = st.id;
    }
  } else {
    const st = (await db.select().from(stores).where(eq(stores.id, storeId)))[0];
    if (!st) return NextResponse.json({ error: "Loja não encontrada." }, { status: 404 });
    if (st.ownerId !== u.id && u.role !== "admin") return NextResponse.json({ error: "Não podes publicar produtos noutras lojas." }, { status: 403 });
  }
  const catRows = await db.select().from(categories);
  const cat = catRows.find((c) => c.name === b.categoryName) || catRows[0];
  const [p] = await db.insert(products).values({
    storeId, sellerId: u.id, name: b.name.trim(), description: b.description.trim(), price: String(price),
    oldPrice: b.oldPrice ? String(Number(b.oldPrice)) : null, stock, categoryId: cat?.id || null,
    categoryName: b.categoryName || cat?.name || "Geral", brand: b.brand || "", condition: b.condition || "novo",
    image: b.image, municipality: b.municipality || u.municipality || "Uíge", province: "Uíge", isApproved: true,
    variants: b.variants || [],
  }).returning();
  await db.insert(priceHistory).values({ productId: p.id, price: String(price) });
  return NextResponse.json({ product: p });
}

export async function PATCH(req: NextRequest) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  const b = await req.json();
  if (!b.id) return NextResponse.json({ error: "ID em falta." }, { status: 400 });
  const rows = await db.select().from(products).where(eq(products.id, b.id));
  const p = rows[0];
  if (!p) return NextResponse.json({ error: "Produto não encontrado." }, { status: 404 });
  if (p.sellerId !== u.id && u.role !== "admin") return NextResponse.json({ error: "Não podes editar produtos de outras lojas." }, { status: 403 });
  if (b.price !== undefined && Number(b.price) <= 0) return NextResponse.json({ error: "Preço inválido." }, { status: 400 });
  if (b.stock !== undefined && Number(b.stock) < 0) return NextResponse.json({ error: "Stock inválido." }, { status: 400 });
  const patch: any = { updatedAt: new Date() };
  if (b.name) patch.name = b.name;
  if (b.description !== undefined) patch.description = b.description;
  if (b.price !== undefined) patch.price = String(Number(b.price));
  if (b.oldPrice !== undefined) patch.oldPrice = b.oldPrice ? String(Number(b.oldPrice)) : null;
  if (b.stock !== undefined) patch.stock = Number(b.stock);
  if (b.image) patch.image = b.image;
  if (b.categoryName) patch.categoryName = b.categoryName;
  if (b.brand !== undefined) patch.brand = b.brand;
  if (b.condition) patch.condition = b.condition;
  if (b.municipality) patch.municipality = b.municipality;
  const [updated] = await db.update(products).set(patch).where(eq(products.id, b.id)).returning();
  if (b.price !== undefined) await db.insert(priceHistory).values({ productId: b.id, price: String(Number(b.price)) });
  return NextResponse.json({ product: updated });
}

export async function DELETE(req: NextRequest) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  const { id } = await req.json();
  const rows = await db.select().from(products).where(eq(products.id, id));
  const p = rows[0];
  if (!p) return NextResponse.json({ error: "Produto não encontrado." }, { status: 404 });
  if (p.sellerId !== u.id && u.role !== "admin") return NextResponse.json({ error: "Sem permissão." }, { status: 403 });
  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
