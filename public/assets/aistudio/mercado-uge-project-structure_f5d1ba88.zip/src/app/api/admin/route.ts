import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, stores, products, orders, reports, categories, notifications } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { currentUser } from "@/lib/auth";

async function requireAdmin() {
  const u = await currentUser();
  if (!u) return null;
  if (u.role !== "admin") return null;
  return u;
}

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Acesso restrito ao administrador." }, { status: 403 });
  const [allUsers, allStores, allProducts, allOrders, allReports] = await Promise.all([
    db.select().from(users).orderBy(desc(users.createdAt)),
    db.select().from(stores).orderBy(desc(stores.createdAt)),
    db.select().from(products).orderBy(desc(products.createdAt)),
    db.select().from(orders).orderBy(desc(orders.createdAt)),
    db.select().from(reports).orderBy(desc(reports.createdAt)),
  ]);
  const revenue = allOrders.filter((o) => o.status !== "Cancelada").reduce((s, o) => s + Number(o.total), 0);
  return NextResponse.json({
    stats: { users: allUsers.length, stores: allStores.length, products: allProducts.length, orders: allOrders.length, revenue, reports: allReports.filter((r) => r.status === "pendente").length },
    users: allUsers.map((u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, isSuspended: u.isSuspended, municipality: u.municipality, createdAt: u.createdAt })),
    stores: allStores, products: allProducts.map((p) => ({ ...p, price: Number(p.price) })), orders: allOrders.map((o) => ({ ...o, total: Number(o.total) })), reports: allReports,
  });
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Acesso restrito ao administrador." }, { status: 403 });
  const b = await req.json();
  if (b.action === "suspend") {
    await db.update(users).set({ isSuspended: !b.current }).where(eq(users.id, b.userId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "approve-store") {
    await db.update(stores).set({ isApproved: true }).where(eq(stores.id, b.storeId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "approve-product") {
    await db.update(products).set({ isApproved: true }).where(eq(products.id, b.productId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "reject-product") {
    await db.delete(products).where(eq(products.id, b.productId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "resolve-report") {
    await db.update(reports).set({ status: "resolvida" }).where(eq(reports.id, b.reportId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "vip-store") {
    await db.update(stores).set({ isVip: !b.current }).where(eq(stores.id, b.storeId));
    return NextResponse.json({ ok: true });
  }
  if (b.action === "broadcast") {
    const all = await db.select().from(users);
    for (const u of all) await db.insert(notifications).values({ userId: u.id, title: b.title || "Aviso", body: b.body || "", type: "broadcast" });
    return NextResponse.json({ ok: true, sent: all.length });
  }
  return NextResponse.json({ error: "Acção inválida." }, { status: 400 });
}
