import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, products, notifications, stores } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { ORDER_STATUSES } from "@/lib/utils";

export async function GET() {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Faz login para ver encomendas." }, { status: 401 });
  let rows: any[] = [];
  if (u.role === "admin") rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  else if (u.role === "comerciante") {
    const myStores = await db.select().from(stores).where(eq(stores.ownerId, u.id));
    const ids = myStores.map((s) => s.id);
    const all = await db.select().from(orders).orderBy(desc(orders.createdAt));
    rows = all.filter((o) => ids.includes(o.storeId || "") || o.userId === u.id);
  } else rows = await db.select().from(orders).where(eq(orders.userId, u.id)).orderBy(desc(orders.createdAt));
  const withItems = [];
  for (const o of rows) {
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
    const enrichedItems = [];
    for (const it of items) {
      const pr = (await db.select().from(products).where(eq(products.id, it.productId || "")))[0];
      enrichedItems.push({ ...it, price: Number(it.price), productName: pr?.name || "Produto", productImage: pr?.image || "" });
    }
    withItems.push({ ...o, subtotal: Number(o.subtotal), deliveryFee: Number(o.deliveryFee), total: Number(o.total), items: enrichedItems });
  }
  return NextResponse.json({ orders: withItems });
}

export async function POST(req: NextRequest) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Faz login para confirmar a encomenda." }, { status: 401 });
  const b = await req.json();
  const items = b.items as { productId: string; qty: number }[];
  if (!items?.length) return NextResponse.json({ error: "Carrinho vazio." }, { status: 400 });
  // Server-side price calculation — never trust client prices
  let subtotal = 0;
  const validated: { productId: string; qty: number; price: number; storeId: string | null }[] = [];
  for (const it of items) {
    const pr = (await db.select().from(products).where(eq(products.id, it.productId)))[0];
    if (!pr) return NextResponse.json({ error: "Produto indisponível." }, { status: 400 });
    if (Number(pr.stock) < it.qty) return NextResponse.json({ error: `Stock insuficiente para "${pr.name}". Disponível: ${pr.stock}.` }, { status: 400 });
    const price = Number(pr.price);
    subtotal += price * it.qty;
    validated.push({ productId: pr.id, qty: it.qty, price, storeId: pr.storeId });
  }
  const deliveryFee = b.deliveryFee !== undefined ? Number(b.deliveryFee) : 1500;
  const total = subtotal + deliveryFee;
  const code = `MU${new Date().getFullYear()}${Math.floor(1000 + Math.random() * 9000)}`;
  // Group by store for simplicity: create one order per store
  const byStore = new Map<string, typeof validated>();
  for (const v of validated) {
    const k = v.storeId || "geral";
    if (!byStore.has(k)) byStore.set(k, []);
    byStore.get(k)!.push(v);
  }
  const created = [];
  for (const [storeId, its] of byStore) {
    const stSub = its.reduce((s, x) => s + x.price * x.qty, 0);
    const [o]: any = await db.insert(orders).values({
      code: `${code}-${created.length + 1}`, userId: u.id, storeId: storeId === "geral" ? null : storeId,
      subtotal: String(stSub), deliveryFee: String(deliveryFee), total: String(stSub + deliveryFee),
      address: b.address || "", paymentMethod: b.paymentMethod || "Multicaixa Express", status: "Pendente",
    }).returning();
    for (const it of its) {
      await db.insert(orderItems).values({ orderId: o.id, productId: it.productId, qty: it.qty, price: String(it.price) });
      await db.update(products).set({ stock: sql`${products.stock} - ${it.qty}`, sales: sql`${products.sales} + ${it.qty}` }).where(eq(products.id, it.productId));
    }
    // notify seller
    const pr0 = (await db.select().from(products).where(eq(products.id, its[0].productId)))[0];
    if (pr0?.sellerId) await db.insert(notifications).values({ userId: pr0.sellerId, title: "Nova encomenda recebida", body: `Encomenda ${o.code} no valor de ${Number(o.total).toLocaleString("pt-AO")} Kz.`, type: "order" });
    created.push(o);
  }
  await db.insert(notifications).values({ userId: u.id, title: "Encomenda confirmada", body: `A tua encomenda ${created[0]?.code} foi registada. Estado: Pendente.`, type: "order" });
  return NextResponse.json({ orders: created });
}

export async function PATCH(req: NextRequest) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  const b = await req.json();
  if (!ORDER_STATUSES.includes(b.status)) return NextResponse.json({ error: "Estado inválido." }, { status: 400 });
  const rows = await db.select().from(orders).where(eq(orders.id, b.id));
  const o = rows[0];
  if (!o) return NextResponse.json({ error: "Encomenda não encontrada." }, { status: 404 });
  const isOwner = o.userId === u.id;
  const isAdmin = u.role === "admin";
  let isSeller = false;
  if (o.storeId) {
    const st = (await db.select().from(stores).where(eq(stores.id, o.storeId)))[0];
    isSeller = st?.ownerId === u.id;
  }
  if (!isOwner && !isAdmin && !isSeller) return NextResponse.json({ error: "Sem permissão." }, { status: 403 });
  // Clients can only cancel pending orders
  if (isOwner && !isAdmin && !isSeller && b.status !== "Cancelada") return NextResponse.json({ error: "Apenas podes cancelar a tua encomenda." }, { status: 403 });
  if (isOwner && b.status === "Cancelada" && o.status !== "Pendente" && o.status !== "Confirmada") return NextResponse.json({ error: "Encomenda já não pode ser cancelada." }, { status: 400 });
  await db.update(orders).set({ status: b.status }).where(eq(orders.id, b.id));
  if (b.status === "Cancelada") {
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
    for (const it of items) if (it.productId) await db.update(products).set({ stock: sql`${products.stock} + ${it.qty}` }).where(eq(products.id, it.productId));
  }
  await db.insert(notifications).values({ userId: o.userId, title: "Actualização da encomenda", body: `Encomenda ${o.code}: novo estado "${b.status}".`, type: "order" });
  return NextResponse.json({ ok: true });
}
