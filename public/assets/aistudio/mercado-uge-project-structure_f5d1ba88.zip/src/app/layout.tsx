import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mercado Uíge — Comprar • Vender • Conectar",
  description: "O maior mercado digital da província do Uíge, Angola. Produtos, lojas e serviços locais em Kwanza.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt">
      <body className="antialiased">{children}</body>
    </html>
  );
}
