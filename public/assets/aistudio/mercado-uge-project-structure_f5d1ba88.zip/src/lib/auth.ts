import { createHash, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq, gt } from "drizzle-orm";

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
export function verifyPassword(password: string, stored: string) {
  try {
    const [salt, hash] = stored.split(":");
    const candidate = scryptSync(password, salt, 64).toString("hex");
    return timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(candidate, "hex"));
  } catch { return false; }
}
function tokenHash(t: string) { return createHash("sha256").update(t).digest("hex"); }

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30);
  await db.insert(sessions).values({ userId, tokenHash: tokenHash(token), expiresAt: expires });
  const c = await cookies();
  c.set("mu_session", token, { httpOnly: true, sameSite: "lax", path: "/", expires, secure: process.env.NODE_ENV === "production" });
  return token;
}
export async function destroySession() {
  const c = await cookies();
  const token = c.get("mu_session")?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash(token)));
  c.delete("mu_session");
}
export async function currentUser() {
  const c = await cookies();
  const token = c.get("mu_session")?.value;
  if (!token) return null;
  const rows = await db.select().from(sessions).where(eq(sessions.tokenHash, tokenHash(token)));
  const s = rows[0];
  if (!s || s.expiresAt < new Date()) return null;
  const u = await db.select().from(users).where(eq(users.id, s.userId));
  return u[0] ?? null;
}
export function publicUser(u: any) {
  if (!u) return null;
  const { passwordHash, ...rest } = u;
  return { ...rest, walletBalance: Number(rest.walletBalance ?? 0) };
}
