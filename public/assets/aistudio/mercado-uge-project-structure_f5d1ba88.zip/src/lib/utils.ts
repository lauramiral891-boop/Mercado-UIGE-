export const fmtKz = (n: number | string) => `${Number(n).toLocaleString("pt-AO", { maximumFractionDigits: 0 })} Kz`;
export const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

const SYNONYMS: Record<string, string[]> = {
  telemovel: ["telemovel", "telefone", "smartphone", "celular", "samsung", "iphone", "xiaomi", "galaxy"],
  telefone: ["telemovel", "telefone", "smartphone"],
  smartphone: ["telemovel", "smartphone", "telefone"],
  celular: ["telemovel", "smartphone"],
  iphone: ["iphone", "apple", "telemovel"],
  samsung: ["samsung", "galaxy", "telemovel"],
  computador: ["computador", "laptop", "pc", "notebook", "gaming"],
  laptop: ["laptop", "computador", "notebook", "gaming"],
  jogos: ["gaming", "jogos", "rtx", "gpu", "laptop"],
  gaming: ["gaming", "jogos", "laptop", "computador"],
  tenis: ["tenis", "sneakers", "nike", "calcado", "sapatos"],
  sapatos: ["sapatos", "tenis", "calcado", "nike"],
  calcado: ["calcado", "sapatos", "tenis"],
  fone: ["fone", "auscultadores", "headphones", "sony", "jbl"],
  auscultadores: ["auscultadores", "fone", "headphones"],
  headphones: ["headphones", "auscultadores", "fone"],
  roupa: ["roupa", "vestido", "moda", "camisa"],
  vestido: ["vestido", "moda", "roupa"],
  comida: ["comida", "alimentos", "fruta", "verdura"],
  alimentos: ["alimentos", "comida", "fruta"],
  beleza: ["beleza", "cosmetico", "creme", "serum"],
  casa: ["casa", "sofa", "mobilia", "lar"],
  barato: ["barato", "promocao", "oferta", "desconto"],
};

export function expandQuery(q: string): string[] {
  const n = normalize(q);
  const tokens = n.split(" ").filter(Boolean);
  const out = new Set<string>(tokens);
  for (const t of tokens) {
    (SYNONYMS[t] || []).forEach((s) => out.add(s));
  }
  // intent detection
  if (n.includes("para jogos") || n.includes("gaming")) { ["gaming", "laptop", "rtx"].forEach((s) => out.add(s)); }
  return Array.from(out);
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 1; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) {
    dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  }
  return dp[m][n];
}
export function fuzzyScore(query: string, text: string): number {
  const q = normalize(query), t = normalize(text);
  if (!q) return 0;
  if (t.includes(q)) return 100;
  const expanded = expandQuery(q);
  let best = 0;
  for (const e of expanded) if (t.includes(e)) best = Math.max(best, 80);
  const qTokens = q.split(" "), tTokens = t.split(" ");
  for (const qt of qTokens) {
    for (const tt of tTokens) {
      const d = levenshtein(qt, tt);
      const maxLen = Math.max(qt.length, tt.length, 1);
      const sim = (1 - d / maxLen) * 100;
      if (sim > 70) best = Math.max(best, sim);
    }
  }
  return best;
}

export function smartSearch<T extends { name: string; description?: string | null; brand?: string | null; categoryName?: string | null; municipality?: string | null; province?: string | null; price?: any; stock?: any; rating?: any }>(items: T[], query: string, opts?: { sort?: string; maxPrice?: number; location?: string; category?: string; onlyAvailable?: boolean }) {
  const q = query.trim();
  let list = [...items];
  if (opts?.category && opts.category !== "todas") list = list.filter((i: any) => normalize(i.categoryName || "") === normalize(opts.category!));
  if (opts?.location && opts.location !== "todas") list = list.filter((i: any) => normalize(i.municipality || "") === normalize(opts.location!) || normalize(i.province || "") === normalize(opts.location!));
  if (opts?.maxPrice) list = list.filter((i: any) => Number(i.price) <= opts.maxPrice!);
  if (opts?.onlyAvailable) list = list.filter((i: any) => Number(i.stock) > 0);
  if (!q) {
    if (opts?.sort === "preco-asc") list.sort((a: any, b: any) => Number(a.price) - Number(b.price));
    if (opts?.sort === "preco-desc") list.sort((a: any, b: any) => Number(b.price) - Number(a.price));
    if (opts?.sort === "relevancia") list.sort((a: any, b: any) => Number(b.rating || 0) - Number(a.rating || 0));
    return list.map((i) => ({ item: i, score: 0 }));
  }
  const wantsCheap = normalize(q).includes("barato") || normalize(q).includes("promocao") || normalize(q).includes("oferta");
  const scored = list.map((i) => {
    const hay = `${i.name} ${i.description || ""} ${i.brand || ""} ${i.categoryName || ""} ${i.municipality || ""} ${i.province || ""}`;
    const score = fuzzyScore(q, hay);
    return { item: i, score };
  }).filter((s) => s.score > 40);
  scored.sort((a, b) => {
    if (wantsCheap) return Number(a.item.price) - Number(b.item.price);
    if (opts?.sort === "preco-asc") return Number(a.item.price) - Number(b.item.price);
    if (opts?.sort === "preco-desc") return Number(b.item.price) - Number(a.item.price);
    return b.score - a.score;
  });
  return scored;
}

export const ANGOLA_PROVINCES = ["Uíge", "Luanda", "Benguela", "Huambo", "Huíla", "Cabinda", "Bengo", "Malanje", "Namibe", "Cuando Cubango", "Cunene", "Lunda Norte", "Lunda Sul", "Bié", "Moxico", "Zaire", "Kuando Kubango", "Benguela"];
export const UIGE_MUNICIPALITIES = ["Uíge", "Negage", "Banga", "Bolongongo", "Bembe", "Canza", "Damba", "Maquela do Zombo", "Mucaba", "Pombo", "Quimbele", "Sanza Pombo", "Songo", "Uíge Cidade"];
export const ORDER_STATUSES = ["Pendente", "Confirmada", "Em preparação", "Pronta para levantamento", "Em entrega", "Entregue", "Cancelada"];
