# Mercado Uíge — Plataforma de Comércio Provincial de Próxima Geração

**Comprar • Vender • Conectar** — O maior mercado digital da província do Uíge, Angola.  
**Moeda:** Kwanza (Kz) | **Idioma:** Português de Angola | **Ambiente:** Web / PWA Standalone Android

---

## 1. Identidade Visual e Tokens de Design
A identidade visual do Mercado Uíge é preservada e elevada através de uma paleta de cores tecnológica e futurista com suporte completo a **Modo Escuro**, **Modo Claro** e **Modo Automático (Android)**:

| Token CSS | Modo Escuro (Assinatura) | Modo Claro | Utilização |
|---|---|---|---|
| `--primary` | `#246BFD` (Azul Eléctrico) | `#246BFD` | Ações principais, botões, separadores activos |
| `--accent` | `#B7F34A` (Verde Tecnológico) | `#78A900` | Preços, descontos, destaques visuais |
| `--background` | `#07111F` (Azul Profundo) | `#F6F8FC` | Fundo principal da aplicação |
| `--surface` | `#172338` | `#FFFFFF` | Cartões de produtos, modais, cabeçalho |
| `--surface-secondary` | `#111D30` | `#F0F4FA` | Sub-painéis, inputs de formulário |
| `--text-primary` | `#F8FAFC` | `#111827` | Títulos, nomes de produtos, texto principal |
| `--text-secondary` | `#A6B2C5` | `#64748B` | Subtítulos, avaliações, informações secundárias |
| `--border` | `#26354B` | `#E2E8F0` | Linhas de divisão, bordas de componentes |

---

## 2. Estrutura e Componentes Desenvolvidos

- **`/src/App.tsx`**: Ponto central da aplicação, gerindo vistas dinâmicas, estados de carrinho, favoritos, encomendas, notificações, autenticação e painéis.
- **`/src/components/Header.tsx`**: Cabeçalho compacto, elegante e responsivo contendo logótipo animado, selector modal de localização, comutador de temas (Escuro / Claro / Auto), notificações e pesquisa inteligente com pesquisa por voz.
- **`/src/components/BottomNav.tsx`**: Barra de navegação inferior estilo Android com safe area, indicador activo iluminado e contador de carrinho.
- **`/src/components/ProductCard.tsx`**: Componente reutilizável de apresentação de produto com proporção de imagem fixa, descontos, selo de loja VIP, avaliação, preço em Kz, favoritos animados e adição ao carrinho com verificação de stock.
- **`/src/components/LocationModal.tsx`**: Selector de municípios do Uíge (Uíge Cidade, Negage, Banga, Bolongongo, Bembe, etc.), províncias de Angola e bairros locais.
- **`/src/components/AuthModal.tsx`**: Autenticação com Login, Registo (Cliente, Comerciante, Entregador, Administrador) e Recuperação de Palavra-passe (código demo `MU-2025-UG`).
- **`/src/components/ProductDetailModal.tsx`**: Vista detalhada com galeria de fotografias, variantes, selector de quantidade, conversa directa com vendedor e denúncia de anúncios.
- **`/src/components/WalletModal.tsx`**: Recarga e gestão da carteira digital via Multicaixa Express.
- **`/src/services/api.ts`**: Camada unificada de dados e APIs (catálogo, encomendas, pesquisa, lojas, notificações, moderação).
- **`/src/lib/utils.ts`**: Algoritmo Levenshtein para pesquisa tolerante a erros ortográficos, expansão de sinónimos em português de Angola e formatação em Kwanzas (`fmtKz`).
- **`/src/lib/storage.ts`**: Persistência de dados local segura para navegação offline contínua e sincronização de dados de teste.
- **`/public/manifest.json` & `/public/icon.svg`**: Suporte PWA standalone para instalação em dispositivos Android.

---

## 3. Pesquisa Inteligente e Pesquisa Externa
1. **Pesquisa Interna:**
   - Remoção automática de acentos (ex.: `telemovel` encontra `telemóvel`).
   - Tolerância a gralhas e distância de Levenshtein.
   - Reconhecimento de intenções:
     - `iphone barato`: Ordena os telemóveis do menor para o maior preço.
     - `computador para jogos`: Prioriza laptops e torres gaming com RTX.
     - `sapatos no Uíge`: Filtra automaticamente pela localização seleccionada.
   - Pesquisa por voz através da Web Speech API em português.
   - Histórico e sugestões em tempo real.
2. **Pesquisa Externa:**
   - Separadores dedicados para **Google, YouTube, Facebook, Instagram e Internet Geral**.
   - Mensagem de estado clara e ligações oficiais seguras, sem scraping invasivo ou simulação de dados fictícios.

---

## 4. Contas de Demonstração para Testes
- **Comerciante (Vendedor):** `vendedor@mercadouige.ao` / palavra-passe: `demo123`
- **Administrador:** `admin@mercadouige.ao` / palavra-passe: `demo123`
- **Cliente:** `cliente@mercadouige.ao` / palavra-passe: `demo123`

---

## 5. Regras de Segurança Implementadas
- Não são permitidos preços negativos ou nulos.
- Validação de quantidade de stock no acto de encomenda.
- O vendedor apenas gere produtos associados à sua própria loja.
- Dados protegidos sem exposição de segredos no código cliente.

---

## 6. Como Executar
```bash
# Instalar dependências
npm install

# Iniciar servidor de desenvolvimento
npm run dev

# Validar TypeScript e Lint
npm run lint

# Compilar para produção
npm run build
```
