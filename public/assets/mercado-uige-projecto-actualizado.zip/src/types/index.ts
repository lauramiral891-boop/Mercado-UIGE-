export type UserRole = "cliente" | "comerciante" | "entregador" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  role: UserRole;
  avatar?: string | null;
  province?: string;
  municipality?: string;
  bairro?: string | null;
  walletBalance: number;
  isSuspended?: boolean;
  isVerified?: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  count?: number;
}

export interface Store {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  category: string;
  province: string;
  municipality: string;
  bairro?: string;
  logo: string;
  cover?: string;
  isApproved: boolean;
  isVip: boolean;
  rating: number;
  salesCount: number;
  createdAt: string;
  phone?: string;
  verified?: boolean;
}

export interface Product {
  id: string;
  storeId?: string;
  sellerId?: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number | null;
  discount: number;
  stock: number;
  categoryId?: string;
  categoryName: string;
  brand?: string;
  condition: "novo" | "usado";
  image: string;
  images?: string[];
  province: string;
  municipality: string;
  bairro?: string;
  isApproved: boolean;
  isFeatured?: boolean;
  isSponsored?: boolean;
  sales: number;
  rating: number;
  reviewsCount: number;
  variants?: string[];
  storeName?: string;
  storeRating?: number;
  storeVip?: boolean;
  createdAt: string;
}

export interface CartItem {
  productId: string;
  qty: number;
  selectedVariant?: string;
  product?: Product;
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  productImage?: string;
  qty: number;
  price: number;
  selectedVariant?: string;
}

export interface Order {
  id: string;
  code: string;
  userId: string;
  userName?: string;
  userPhone?: string;
  storeId?: string;
  storeName?: string;
  status: "Pendente" | "Confirmada" | "Em preparação" | "Pronta para levantamento" | "Em entrega" | "Entregue" | "Cancelada";
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  address: string;
  paymentMethod: string;
  createdAt: string;
  estimatedDelivery?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: "info" | "order" | "promo" | "security" | "system" | "welcome";
  isRead: boolean;
  createdAt: string;
  link?: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterName?: string;
  productId: string;
  productName?: string;
  reason: string;
  status: "pendente" | "resolvido" | "rejeitado";
  createdAt: string;
}

export interface ExternalSearchResult {
  title: string;
  snippet: string;
  link: string;
  source: string;
  thumb?: string;
}

export interface ExternalSearchResponse {
  source: string;
  configured: boolean;
  results: ExternalSearchResult[];
  message?: string;
  officialLink: string;
}

export type ThemeMode = "dark" | "light" | "system";
