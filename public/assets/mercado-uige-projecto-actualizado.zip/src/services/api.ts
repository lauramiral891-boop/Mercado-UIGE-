import {
  Product,
  Store,
  Category,
  User,
  Order,
  NotificationItem,
  ReportItem,
  ExternalSearchResponse,
} from "@/types";
import {
  getStoredProducts,
  saveProducts,
  getStoredStores,
  saveStores,
  getStoredCategories,
  saveCategories,
  getStoredUsers,
  saveUsers,
  getStoredCurrentUser,
  saveCurrentUser,
  getStoredOrders,
  saveOrders,
  getStoredNotifications,
  saveNotifications,
  getStoredReports,
  saveReports,
} from "@/lib/storage";
import { smartSearch, generateOrderCode, normalize } from "@/lib/utils";

export const api = {
  // --- CATALOG ---
  async getCatalog(): Promise<{ products: Product[]; stores: Store[]; categories: Category[] }> {
    try {
      const res = await fetch("/api/catalog");
      if (res.ok) {
        const data = await res.json();
        if (data.products && data.products.length > 0) {
          saveProducts(data.products);
          saveStores(data.stores);
          saveCategories(data.categories);
          return data;
        }
      }
    } catch {
      // Fallback to local persistent storage
    }
    return {
      products: getStoredProducts(),
      stores: getStoredStores(),
      categories: getStoredCategories(),
    };
  },

  async publishProduct(payload: Partial<Product> & { storeName?: string }): Promise<Product> {
    const user = getStoredCurrentUser();
    if (!user) {
      throw new Error("É necessário fazer login para publicar produtos.");
    }
    if (user.role !== "comerciante" && user.role !== "admin") {
      throw new Error("Apenas comerciantes ou administradores podem publicar produtos.");
    }

    const price = Number(payload.price);
    const stock = Number(payload.stock);

    if (!payload.name?.trim()) throw new Error("O nome do produto é obrigatório.");
    if (!payload.description?.trim()) throw new Error("A descrição do produto é obrigatória.");
    if (isNaN(price) || price <= 0) throw new Error("Preço inválido. Não são permitidos valores negativos ou nulos.");
    if (isNaN(stock) || stock < 0) throw new Error("Quantidade em stock inválida.");
    if (!payload.image?.trim()) throw new Error("Por favor, adicione uma fotografia ao produto.");

    // Check store
    const stores = getStoredStores();
    let store = stores.find((s) => s.ownerId === user.id);
    if (!store) {
      // Automatically create store for user
      store = {
        id: `store-${Date.now()}`,
        ownerId: user.id,
        name: payload.storeName || `Loja de ${user.name}`,
        description: `Loja comercial de ${user.name} no Mercado Uíge.`,
        category: payload.categoryName || "Geral",
        province: user.province || "Uíge",
        municipality: user.municipality || "Uíge",
        bairro: user.bairro || "Centro",
        logo: payload.image,
        cover: payload.image,
        isApproved: true,
        isVip: false,
        rating: 5.0,
        salesCount: 0,
        createdAt: new Date().toISOString(),
      };
      stores.push(store);
      saveStores(stores);
    }

    const oldPrice = payload.oldPrice ? Number(payload.oldPrice) : null;
    const discount = oldPrice && oldPrice > price ? Math.round((1 - price / oldPrice) * 100) : 0;

    const newProd: Product = {
      id: `prod-${Date.now()}`,
      storeId: store.id,
      sellerId: user.id,
      name: payload.name.trim(),
      description: payload.description.trim(),
      price,
      oldPrice,
      discount,
      stock,
      categoryId: payload.categoryId,
      categoryName: payload.categoryName || "Electrónicos",
      brand: payload.brand?.trim() || "Genérico",
      condition: payload.condition || "novo",
      image: payload.image.trim(),
      province: user.province || "Uíge",
      municipality: user.municipality || "Uíge",
      bairro: user.bairro || "Centro",
      isApproved: true,
      isFeatured: false,
      isSponsored: false,
      sales: 0,
      rating: 5.0,
      reviewsCount: 0,
      storeName: store.name,
      storeRating: store.rating,
      storeVip: store.isVip,
      createdAt: new Date().toISOString(),
    };

    const products = getStoredProducts();
    products.unshift(newProd);
    saveProducts(products);

    return newProd;
  },

  async updateProductStock(id: string, newStock: number): Promise<void> {
    if (newStock < 0) throw new Error("Stock não pode ser negativo.");
    const products = getStoredProducts();
    const idx = products.findIndex((p) => p.id === id);
    if (idx !== -1) {
      products[idx].stock = newStock;
      saveProducts(products);
    }
  },

  async deleteProduct(id: string): Promise<void> {
    const products = getStoredProducts().filter((p) => p.id !== id);
    saveProducts(products);
  },

  // --- STORES ---
  async createStore(payload: Partial<Store>): Promise<Store> {
    const user = getStoredCurrentUser();
    if (!user) throw new Error("Faz login para criar uma loja.");
    if (!payload.name?.trim()) throw new Error("O nome da loja é obrigatório.");

    const newStore: Store = {
      id: `store-${Date.now()}`,
      ownerId: user.id,
      name: payload.name.trim(),
      description: payload.description?.trim() || "Loja registada no Mercado Uíge.",
      category: payload.category || "Geral",
      province: user.province || "Uíge",
      municipality: payload.municipality || user.municipality || "Uíge",
      bairro: payload.bairro || user.bairro || "Centro",
      logo: payload.logo || "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=600&q=80",
      cover: payload.cover || "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80",
      isApproved: true,
      isVip: false,
      rating: 5.0,
      salesCount: 0,
      phone: payload.phone || user.phone || undefined,
      createdAt: new Date().toISOString(),
    };

    const stores = getStoredStores();
    stores.push(newStore);
    saveStores(stores);
    return newStore;
  },

  // --- ORDERS ---
  async getOrders(): Promise<Order[]> {
    const user = getStoredCurrentUser();
    const orders = getStoredOrders();
    if (!user) return [];
    if (user.role === "admin") return orders;
    if (user.role === "comerciante") {
      // Merchant sees orders where seller matches or user orders
      const myStores = getStoredStores().filter((s) => s.ownerId === user.id).map((s) => s.id);
      return orders.filter((o) => o.userId === user.id || (o.storeId && myStores.includes(o.storeId)));
    }
    return orders.filter((o) => o.userId === user.id);
  },

  async createOrder(payload: {
    items: { productId: string; qty: number; selectedVariant?: string }[];
    address: string;
    paymentMethod: string;
    deliveryFee: number;
  }): Promise<Order> {
    const user = getStoredCurrentUser();
    if (!user) throw new Error("Inicie sessão para confirmar a sua encomenda.");
    if (!payload.address.trim()) throw new Error("O endereço de entrega é obrigatório.");
    if (!payload.items || payload.items.length === 0) throw new Error("O carrinho está vazio.");

    const products = getStoredProducts();
    let subtotal = 0;
    const orderItems = [];

    for (const item of payload.items) {
      const prod = products.find((p) => p.id === item.productId);
      if (!prod) throw new Error("Produto não encontrado.");
      if (prod.stock < item.qty) {
        throw new Error(`O produto "${prod.name}" tem apenas ${prod.stock} unidades disponíveis.`);
      }
      // Decrement stock
      prod.stock -= item.qty;
      prod.sales = (prod.sales || 0) + item.qty;

      const itemTotal = prod.price * item.qty;
      subtotal += itemTotal;

      orderItems.push({
        id: `oi-${Date.now()}-${item.productId}`,
        productId: prod.id,
        productName: prod.name,
        productImage: prod.image,
        qty: item.qty,
        price: prod.price,
        selectedVariant: item.selectedVariant,
      });
    }

    saveProducts(products);

    const deliveryFee = payload.deliveryFee || 1500;
    const total = subtotal + deliveryFee;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      code: generateOrderCode(),
      userId: user.id,
      userName: user.name,
      userPhone: user.phone || undefined,
      status: "Pendente",
      items: orderItems,
      subtotal,
      deliveryFee,
      total,
      address: payload.address.trim(),
      paymentMethod: payload.paymentMethod || "Multicaixa Express",
      createdAt: new Date().toISOString(),
      estimatedDelivery: "24h - 48h em Uíge",
    };

    const orders = getStoredOrders();
    orders.unshift(newOrder);
    saveOrders(orders);

    // Notify user
    const notifs = getStoredNotifications();
    notifs.unshift({
      id: `notif-${Date.now()}`,
      userId: user.id,
      title: "Encomenda Confirmada! 🎉",
      body: `A sua encomenda #${newOrder.code} de ${total.toLocaleString("pt-AO")} Kz foi recebida e está a ser preparada.`,
      type: "order",
      isRead: false,
      createdAt: new Date().toISOString(),
    });
    saveNotifications(notifs);

    return newOrder;
  },

  async updateOrderStatus(orderId: string, status: Order["status"]): Promise<void> {
    const orders = getStoredOrders();
    const order = orders.find((o) => o.id === orderId);
    if (!order) throw new Error("Encomenda não encontrada.");
    order.status = status;
    saveOrders(orders);

    // Send status notification
    const notifs = getStoredNotifications();
    notifs.unshift({
      id: `notif-${Date.now()}`,
      userId: order.userId,
      title: `Estado da Encomenda #${order.code}`,
      body: `A sua encomenda agora está: ${status}.`,
      type: "order",
      isRead: false,
      createdAt: new Date().toISOString(),
    });
    saveNotifications(notifs);
  },

  // --- SEARCH ---
  async search(query: string, opts?: {
    sort?: string;
    maxPrice?: number;
    location?: string;
    category?: string;
    available?: boolean;
    source?: string;
  }): Promise<{
    results: Product[];
    suggestions: string[];
    external?: ExternalSearchResponse;
  }> {
    const source = opts?.source || "plataforma";

    if (source !== "plataforma") {
      return {
        results: [],
        suggestions: [],
        external: this.getExternalSearchStatus(query, source),
      };
    }

    const products = getStoredProducts();
    const found = smartSearch(products, query, {
      sort: opts?.sort,
      maxPrice: opts?.maxPrice,
      location: opts?.location,
      category: opts?.category,
      onlyAvailable: opts?.available,
    });

    const suggestions = query.trim()
      ? products
          .filter((p) => normalize(p.name).includes(normalize(query).slice(0, 4)))
          .slice(0, 5)
          .map((p) => p.name)
      : [];

    return {
      results: found.map((f) => f.item),
      suggestions,
    };
  },

  getExternalSearchStatus(query: string, source: string): ExternalSearchResponse {
    const q = encodeURIComponent(query || "Mercado Uíge Angola");
    const externalLinks: Record<string, string> = {
      google: `https://www.google.com/search?q=${q}+Uige+Angola`,
      youtube: `https://www.youtube.com/results?search_query=${q}+Angola`,
      facebook: `https://www.facebook.com/search/top?q=${q}+Uige`,
      instagram: `https://www.instagram.com/explore/tags/uige/`,
      bing: `https://www.bing.com/search?q=${q}+Angola`,
      internet: `https://duckduckgo.com/?q=${q}+Uige+Angola`,
    };

    const sourceNames: Record<string, string> = {
      google: "Google Search",
      youtube: "YouTube",
      facebook: "Facebook",
      instagram: "Instagram",
      bing: "Bing",
      internet: "Internet Geral",
    };

    const label = sourceNames[source] || source;

    return {
      source,
      configured: false,
      results: [],
      message: `A integração oficial com a API de ${label} requer chaves de API empresariais configuradas nas variáveis do servidor. Pode abrir directamente os resultados oficiais correspondentes na plataforma externa.`,
      officialLink: externalLinks[source] || externalLinks.internet,
    };
  },

  // --- NOTIFICATIONS & MISC ---
  async getNotifications(): Promise<NotificationItem[]> {
    const user = getStoredCurrentUser();
    const notifs = getStoredNotifications();
    if (!user) return [];
    return notifs.filter((n) => n.userId === user.id || n.userId === "all");
  },

  async markAllNotificationsRead(): Promise<void> {
    const user = getStoredCurrentUser();
    if (!user) return;
    const notifs = getStoredNotifications();
    notifs.forEach((n) => {
      if (n.userId === user.id || n.userId === "all") n.isRead = true;
    });
    saveNotifications(notifs);
  },

  async reportProduct(productId: string, reason: string): Promise<void> {
    const user = getStoredCurrentUser();
    const prods = getStoredProducts();
    const prod = prods.find((p) => p.id === productId);
    const reports = getStoredReports();
    reports.unshift({
      id: `rep-${Date.now()}`,
      reporterId: user ? user.id : "anon",
      reporterName: user ? user.name : "Utilizador Anónimo",
      productId,
      productName: prod ? prod.name : "Produto desconhecido",
      reason: reason.trim() || "Não especificado",
      status: "pendente",
      createdAt: new Date().toISOString(),
    });
    saveReports(reports);
  },

  // --- ADMIN ACTIONS ---
  async getAdminData(): Promise<{
    stats: { users: number; stores: number; products: number; orders: number; revenue: number };
    users: User[];
    stores: Store[];
    products: Product[];
    orders: Order[];
    reports: ReportItem[];
  }> {
    const users = getStoredUsers();
    const stores = getStoredStores();
    const products = getStoredProducts();
    const orders = getStoredOrders();
    const reports = getStoredReports();

    const revenue = orders
      .filter((o) => o.status !== "Cancelada")
      .reduce((sum, o) => sum + Number(o.total || 0), 0);

    return {
      stats: {
        users: users.length,
        stores: stores.length,
        products: products.length,
        orders: orders.length,
        revenue,
      },
      users,
      stores,
      products,
      orders,
      reports,
    };
  },

  async suspendUser(userId: string, current: boolean): Promise<void> {
    const users = getStoredUsers();
    const u = users.find((x) => x.id === userId);
    if (u) {
      u.isSuspended = !current;
      saveUsers(users);
    }
  },

  async toggleStoreVip(storeId: string, current: boolean): Promise<void> {
    const stores = getStoredStores();
    const s = stores.find((x) => x.id === storeId);
    if (s) {
      s.isVip = !current;
      saveStores(stores);
    }
  },

  async resolveReport(reportId: string): Promise<void> {
    const reports = getStoredReports();
    const r = reports.find((x) => x.id === reportId);
    if (r) {
      r.status = "resolvido";
      saveReports(reports);
    }
  },

  async broadcastMessage(title: string, body: string): Promise<void> {
    if (!title.trim() || !body.trim()) throw new Error("Título e mensagem obrigatórios.");
    const notifs = getStoredNotifications();
    notifs.unshift({
      id: `notif-${Date.now()}`,
      userId: "all",
      title: `[Aviso Geral] ${title.trim()}`,
      body: body.trim(),
      type: "system",
      isRead: false,
      createdAt: new Date().toISOString(),
    });
    saveNotifications(notifs);
  },

  async addCategory(name: string): Promise<Category> {
    if (!name.trim()) throw new Error("Nome da categoria obrigatório.");
    const cats = getStoredCategories();
    const newCat: Category = {
      id: `cat-${Date.now()}`,
      name: name.trim(),
      slug: normalize(name),
      icon: "tag",
      color: "#246BFD",
      count: 0,
    };
    cats.push(newCat);
    saveCategories(cats);
    return newCat;
  },
};
