import React, { useState } from "react";
import {
  X,
  Heart,
  ShoppingCart,
  Star,
  MapPin,
  Store as StoreIcon,
  Crown,
  Share2,
  Flag,
  Send,
  Plus,
  Minus,
  ShieldCheck,
  Truck,
  CheckCircle2,
} from "lucide-react";
import { Product } from "@/types";
import { fmtKz } from "@/lib/utils";

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (product: Product) => void;
  onAddToCart: (product: Product, qty: number, variant?: string) => void;
  onOpenStore?: (storeId: string) => void;
  similarProducts: Product[];
  onSelectProduct: (p: Product) => void;
  onSendMessage: (productId: string, message: string) => void;
  onReportProduct: (productId: string, reason: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
  onOpenStore,
  similarProducts,
  onSelectProduct,
  onSendMessage,
  onReportProduct,
}) => {
  if (!isOpen || !product) return null;

  const [qty, setQty] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState(
    product.variants && product.variants.length > 0 ? product.variants[0] : ""
  );
  const [activeImage, setActiveImage] = useState(product.image);
  const [chatMessage, setChatMessage] = useState("");
  const [showReportInput, setShowReportInput] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [copiedLink, setCopiedLink] = useState(false);

  const isOutOfStock = Number(product.stock) <= 0;
  const maxQty = Math.max(1, Number(product.stock));

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `Confere este produto no Mercado Uíge: ${product.name} por ${fmtKz(product.price)}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    onSendMessage(product.id, chatMessage);
    setChatMessage("");
  };

  const handleSendReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportReason.trim()) return;
    onReportProduct(product.id, reportReason);
    setReportReason("");
    setShowReportInput(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-3 sm:p-5 bg-black/80 backdrop-blur-md anim-fadeUp"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl rounded-3xl p-4 sm:p-6 border shadow-2xl anim-pop max-h-[92vh] overflow-y-auto"
        style={{
          backgroundColor: "var(--surface)",
          borderColor: "var(--border)",
          color: "var(--text-primary)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b mb-4" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2 text-xs font-bold" style={{ color: "var(--text-secondary)" }}>
            <span className="capitalize">{product.categoryName}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <MapPin size={12} /> {product.municipality}, Uíge
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleShare}
              className="w-8 h-8 rounded-full border grid place-items-center hover:bg-slate-500/10 cursor-pointer"
              style={{ borderColor: "var(--border)" }}
              title="Partilhar produto"
            >
              <Share2 size={15} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full border grid place-items-center hover:bg-slate-500/10 cursor-pointer"
              style={{ borderColor: "var(--border)" }}
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {copiedLink && (
          <div className="mb-3 p-2 text-xs font-bold bg-[#B7F34A]/20 text-emerald-400 rounded-xl text-center">
            Ligação do produto copiada para a área de transferência!
          </div>
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Images Section */}
          <div className="space-y-3">
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden border" style={{ borderColor: "var(--border)" }}>
              <img
                src={activeImage}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {product.discount > 0 && (
                <span
                  className="absolute top-3 left-3 text-xs font-black px-3 py-1 rounded-full shadow-lg"
                  style={{ backgroundColor: "var(--accent)", color: "var(--accent-text)" }}
                >
                  -{product.discount}% DESCONTO
                </span>
              )}
              {product.storeVip && (
                <span className="absolute top-3 right-12 text-xs font-bold px-2.5 py-1 rounded-full bg-amber-400 text-slate-950 flex items-center gap-1 shadow-md">
                  <Crown size={12} className="fill-current" /> Loja VIP
                </span>
              )}
              <button
                type="button"
                onClick={() => onToggleFavorite(product)}
                className="absolute top-3 right-3 w-9 h-9 rounded-full grid place-items-center bg-black/50 backdrop-blur-md cursor-pointer hover:scale-105 transition-transform"
              >
                <Heart
                  size={18}
                  className={isFavorite ? "text-red-500 fill-red-500" : "text-white fill-none"}
                />
              </button>
            </div>

            {/* Thumbnail selector if multiple images exist */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto no-scrollbar">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImage(img)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 cursor-pointer ${
                      activeImage === img ? "border-[#246BFD]" : "border-transparent opacity-60"
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Trust Badges */}
            <div className="p-3.5 rounded-2xl border space-y-2 text-xs" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
              <div className="flex items-center gap-2 font-semibold">
                <Truck size={16} className="text-[#246BFD] shrink-0" />
                <span>Entrega rápida em Uíge e Negage (24h a 48h)</span>
              </div>
              <div className="flex items-center gap-2 font-semibold">
                <ShieldCheck size={16} className="text-emerald-500 shrink-0" />
                <span>Compra protegida • Pagamento Multicaixa Express</span>
              </div>
            </div>
          </div>

          {/* Details Section */}
          <div className="flex flex-col justify-between space-y-4">
            <div>
              {/* Store info banner */}
              <div className="flex items-center justify-between text-xs pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                <div className="flex items-center gap-1.5 font-bold" style={{ color: "var(--text-secondary)" }}>
                  <StoreIcon size={14} className="text-[#246BFD]" />
                  <span>Vendido por: </span>
                  <span className="text-[#246BFD] font-black">{product.storeName || "Loja Oficial Uíge"}</span>
                </div>
                <div className="flex items-center gap-1 text-amber-400 font-bold">
                  <Star size={13} className="fill-current" />
                  <span>{Number(product.rating || 4.8).toFixed(1)}</span>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-xl sm:text-2xl font-black mt-2 leading-tight" style={{ color: "var(--text-primary)" }}>
                {product.name}
              </h1>

              {/* Price */}
              <div className="mt-3 flex items-baseline gap-3">
                <span className="text-2xl sm:text-3xl font-black tracking-tight" style={{ color: "var(--accent)" }}>
                  {fmtKz(product.price)}
                </span>
                {product.oldPrice && (
                  <span className="text-sm line-through opacity-50" style={{ color: "var(--text-muted)" }}>
                    {fmtKz(product.oldPrice)}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="mt-3 text-xs sm:text-sm leading-relaxed opacity-85" style={{ color: "var(--text-primary)" }}>
                {product.description}
              </p>

              {/* Details table */}
              <div className="grid grid-cols-2 gap-2 mt-4 text-xs">
                <div className="p-2.5 rounded-xl border" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
                  <span className="opacity-60 block">Marca:</span>
                  <span className="font-bold">{product.brand || "Oficial"}</span>
                </div>
                <div className="p-2.5 rounded-xl border" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
                  <span className="opacity-60 block">Estado:</span>
                  <span className="font-bold capitalize">{product.condition === "usado" ? "Usado (Garantido)" : "Novo em Caixa"}</span>
                </div>
                <div className="p-2.5 rounded-xl border" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
                  <span className="opacity-60 block">Disponibilidade:</span>
                  <span className={`font-bold ${isOutOfStock ? "text-red-500" : "text-emerald-500"}`}>
                    {isOutOfStock ? "Sem Stock" : `${product.stock} unidades`}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl border" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
                  <span className="opacity-60 block">Local de Levantamento:</span>
                  <span className="font-bold">{product.municipality}, Uíge</span>
                </div>
              </div>

              {/* Variants */}
              {product.variants && product.variants.length > 0 && (
                <div className="mt-4">
                  <label className="block text-xs font-bold mb-1.5" style={{ color: "var(--text-secondary)" }}>
                    Opção / Variante:
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => setSelectedVariant(v)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          selectedVariant === v
                            ? "bg-[#246BFD] text-white border-[#246BFD]"
                            : "border-[var(--border)] hover:border-[#246BFD]"
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity Stepper */}
              <div className="mt-4 flex items-center gap-3">
                <span className="text-xs font-bold" style={{ color: "var(--text-secondary)" }}>Quantidade:</span>
                <div className="flex items-center border rounded-xl overflow-hidden" style={{ borderColor: "var(--border)" }}>
                  <button
                    type="button"
                    disabled={qty <= 1}
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    className="w-8 h-8 grid place-items-center hover:bg-slate-500/10 disabled:opacity-40 cursor-pointer"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="w-10 text-center font-black text-sm">{qty}</span>
                  <button
                    type="button"
                    disabled={qty >= maxQty}
                    onClick={() => setQty(Math.min(maxQty, qty + 1))}
                    className="w-8 h-8 grid place-items-center hover:bg-slate-500/10 disabled:opacity-40 cursor-pointer"
                  >
                    <Plus size={14} />
                  </button>
                </div>
                <span className="text-[11px] opacity-60">Total: {fmtKz(product.price * qty)}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                disabled={isOutOfStock}
                onClick={() => {
                  onAddToCart(product, qty, selectedVariant);
                  onClose();
                }}
                className="w-full py-3.5 rounded-2xl font-black text-sm text-white shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ backgroundColor: "var(--primary)" }}
              >
                <ShoppingCart size={18} />
                <span>{isOutOfStock ? "Produto Esgotado" : "Adicionar ao Carrinho"}</span>
              </button>

              {/* Message to vendor */}
              <div className="p-3 rounded-2xl border" style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}>
                <span className="text-xs font-bold block mb-1.5" style={{ color: "var(--text-secondary)" }}>
                  Mensagem directa ao Comerciante:
                </span>
                <form onSubmit={handleSendChat} className="flex gap-2">
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    placeholder="Ex: Olá! Tem disponível para entrega hoje no Uíge?"
                    className="flex-1 px-3 py-2 rounded-xl text-xs border bg-transparent outline-none focus:border-[#246BFD]"
                    style={{ borderColor: "var(--border)" }}
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-xl text-xs font-bold text-white flex items-center gap-1 cursor-pointer"
                    style={{ backgroundColor: "var(--primary)" }}
                  >
                    <Send size={13} />
                    <span>Enviar</span>
                  </button>
                </form>
              </div>

              {/* Report product */}
              <div className="pt-1 text-center">
                {!showReportInput ? (
                  <button
                    type="button"
                    onClick={() => setShowReportInput(true)}
                    className="text-[11px] font-semibold opacity-60 hover:opacity-100 flex items-center justify-center gap-1 mx-auto cursor-pointer"
                  >
                    <Flag size={12} /> Denunciar anúncio ou irregularidade
                  </button>
                ) : (
                  <form onSubmit={handleSendReport} className="flex gap-2 mt-2">
                    <input
                      type="text"
                      value={reportReason}
                      onChange={(e) => setReportReason(e.target.value)}
                      placeholder="Indique o motivo da denúncia..."
                      className="flex-1 px-3 py-1.5 rounded-xl text-xs border bg-transparent outline-none"
                      style={{ borderColor: "var(--border)" }}
                    />
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-red-600 text-white cursor-pointer"
                    >
                      Submeter
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowReportInput(false)}
                      className="px-2 py-1.5 rounded-xl text-xs border cursor-pointer"
                      style={{ borderColor: "var(--border)" }}
                    >
                      Cancelar
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Similar Products Carousel */}
        {similarProducts.length > 0 && (
          <div className="mt-8 pt-5 border-t" style={{ borderColor: "var(--border)" }}>
            <h3 className="font-black text-sm sm:text-base mb-3">Produtos Semelhantes em Uíge</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {similarProducts.slice(0, 4).map((p) => (
                <div
                  key={p.id}
                  onClick={() => onSelectProduct(p)}
                  className="p-2.5 rounded-2xl border cursor-pointer hover:border-[#246BFD] transition-colors"
                  style={{ backgroundColor: "var(--surface-secondary)", borderColor: "var(--border)" }}
                >
                  <img src={p.image} alt={p.name} className="w-full h-24 object-cover rounded-xl" />
                  <div className="font-bold text-xs truncate mt-2">{p.name}</div>
                  <div className="font-black text-xs mt-0.5" style={{ color: "var(--accent)" }}>{fmtKz(p.price)}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
