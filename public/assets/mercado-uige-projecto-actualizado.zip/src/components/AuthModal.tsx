import React, { useState } from "react";
import { X, User as UserIcon, Lock, Mail, Phone, MapPin, AlertCircle, ShoppingCart } from "lucide-react";
import { User, UserRole } from "@/types";
import { UIGE_MUNICIPALITIES } from "@/lib/utils";
import { getStoredUsers, saveUsers, saveCurrentUser } from "@/lib/storage";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: "login" | "register" | "recover";
  onSuccess: (user: User) => void;
  showToast: (msg: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = "login",
  onSuccess,
  showToast,
}) => {
  const [mode, setMode] = useState<"login" | "register" | "recover" | "reset">(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("cliente");
  const [municipality, setMunicipality] = useState("Uíge");
  const [bairro, setBairro] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const cleanEmail = email.trim().toLowerCase();
      const users = getStoredUsers();

      if (mode === "login") {
        if (!cleanEmail || !password) {
          throw new Error("Por favor, preencha o e-mail e a palavra-passe.");
        }

        // Demo login checks
        let user = users.find((u) => u.email.toLowerCase() === cleanEmail);
        
        // If demo credentials matched
        if (cleanEmail === "vendedor@mercadouige.ao" && (!user || password === "demo123")) {
          if (!user) {
            user = {
              id: "user-seller-1",
              name: "Tech Uíge Comércio",
              email: "vendedor@mercadouige.ao",
              phone: "+244 923 111 222",
              role: "comerciante",
              province: "Uíge",
              municipality: "Uíge",
              bairro: "Centro",
              walletBalance: 12500,
              isSuspended: false,
              isVerified: true,
              createdAt: new Date().toISOString(),
            };
            users.push(user);
            saveUsers(users);
          }
        } else if (cleanEmail === "admin@mercadouige.ao") {
          if (!user) {
            user = {
              id: "user-admin-1",
              name: "Administrador Mercado Uíge",
              email: "admin@mercadouige.ao",
              phone: "+244 923 000 001",
              role: "admin",
              province: "Uíge",
              municipality: "Uíge",
              bairro: "Candombe",
              walletBalance: 85000,
              isSuspended: false,
              isVerified: true,
              createdAt: new Date().toISOString(),
            };
            users.push(user);
            saveUsers(users);
          }
        }

        if (!user) {
          throw new Error("Conta não encontrada com este e-mail. Crie uma nova conta no separador 'Registar'.");
        }

        if (user.isSuspended) {
          throw new Error("Esta conta encontra-se suspensa pela administração. Contacte o suporte.");
        }

        saveCurrentUser(user);
        onSuccess(user);
        showToast(`Bem-vindo de volta, ${user.name}!`);
        onClose();
        return;
      }

      if (mode === "register") {
        if (!name.trim()) throw new Error("Por favor, indique o seu nome completo.");
        if (!cleanEmail) throw new Error("Por favor, indique um e-mail válido.");
        if (!password || password.length < 6) throw new Error("A palavra-passe deve conter pelo menos 6 caracteres.");

        const existing = users.find((u) => u.email.toLowerCase() === cleanEmail);
        if (existing) {
          throw new Error("Já existe uma conta registada com este e-mail.");
        }

        // Admin email rule
        const finalRole: UserRole =
          cleanEmail === "admin@mercadouige.ao" ? "admin" : role;

        const newUser: User = {
          id: `user-${Date.now()}`,
          name: name.trim(),
          email: cleanEmail,
          phone: phone.trim() || null,
          role: finalRole,
          province: "Uíge",
          municipality,
          bairro: bairro.trim() || null,
          walletBalance: 12500, // Demo welcome balance
          isSuspended: false,
          isVerified: true,
          createdAt: new Date().toISOString(),
        };

        users.push(newUser);
        saveUsers(users);
        saveCurrentUser(newUser);
        onSuccess(newUser);
        showToast("Conta criada com sucesso! Seja bem-vindo ao Mercado Uíge.");
        onClose();
        return;
      }

      if (mode === "recover") {
        if (!cleanEmail) throw new Error("Indique o e-mail da sua conta.");
        setMode("reset");
        showToast("Código de demonstração: MU-2025-UG enviado.");
        return;
      }

      if (mode === "reset") {
        if (code.trim() !== "MU-2025-UG") {
          throw new Error("Código de verificação incorrecto. Use o código demo: MU-2025-UG.");
        }
        if (!password || password.length < 6) {
          throw new Error("A nova palavra-passe deve ter pelo menos 6 caracteres.");
        }
        showToast("Palavra-passe redefinida com sucesso. Inicie sessão agora.");
        setMode("login");
      }
    } catch (err: any) {
      setError(err.message || "Ocorreu um erro no processamento. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const fillDemoAccount = (demoRole: "seller" | "admin" | "client") => {
    if (demoRole === "seller") {
      setEmail("vendedor@mercadouige.ao");
      setPassword("demo123");
      setMode("login");
    } else if (demoRole === "admin") {
      setEmail("admin@mercadouige.ao");
      setPassword("demo123");
      setMode("login");
    } else {
      setEmail("cliente@mercadouige.ao");
      setPassword("demo123");
      setMode("login");
    }
    setError("");
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/75 backdrop-blur-sm anim-fadeUp"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-5 sm:p-7 border shadow-2xl anim-pop max-h-[92vh] overflow-y-auto"
        style={{
          backgroundColor: "var(--surface)",
          borderColor: "var(--border)",
          color: "var(--text-primary)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <div
              className="w-9 h-9 rounded-2xl grid place-items-center shadow-sm"
              style={{ background: "linear-gradient(135deg, #246BFD, #07111F)" }}
            >
              <ShoppingCart size={18} color="#B7F34A" />
            </div>
            <div>
              <h2 className="font-black text-base sm:text-lg leading-tight">Mercado Uíge</h2>
              <p className="text-[11px]" style={{ color: "var(--text-secondary)" }}>
                {mode === "login"
                  ? "Aceda à sua conta"
                  : mode === "register"
                  ? "Crie a sua conta gratuita"
                  : "Recuperar palavra-passe"}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full border grid place-items-center hover:bg-slate-500/10 cursor-pointer"
            style={{ borderColor: "var(--border)" }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div
          className="flex gap-1 p-1 rounded-2xl my-4 border text-xs font-black"
          style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
        >
          <button
            type="button"
            onClick={() => {
              setMode("login");
              setError("");
            }}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer ${
              mode === "login" ? "bg-[#246BFD] text-white shadow-sm" : "hover:text-[#246BFD]"
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("register");
              setError("");
            }}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer ${
              mode === "register" ? "bg-[#246BFD] text-white shadow-sm" : "hover:text-[#246BFD]"
            }`}
          >
            Registar
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("recover");
              setError("");
            }}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer ${
              mode === "recover" || mode === "reset"
                ? "bg-[#246BFD] text-white shadow-sm"
                : "hover:text-[#246BFD]"
            }`}
          >
            Recuperar
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-bold flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0 text-red-500" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === "register" && (
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                Nome Completo *
              </label>
              <div
                className="flex items-center gap-2.5 px-3 py-2.5 rounded-2xl border bg-transparent text-sm focus-within:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
              >
                <UserIcon size={16} className="opacity-50" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: João Baptista"
                  className="w-full bg-transparent outline-none text-xs sm:text-sm"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
              Endereço de E-mail *
            </label>
            <div
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-2xl border bg-transparent text-sm focus-within:border-[#246BFD]"
              style={{ borderColor: "var(--border)" }}
            >
              <Mail size={16} className="opacity-50" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nome@exemplo.ao"
                className="w-full bg-transparent outline-none text-xs sm:text-sm"
              />
            </div>
          </div>

          {mode === "register" && (
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                Telefone (Angola)
              </label>
              <div
                className="flex items-center gap-2.5 px-3 py-2.5 rounded-2xl border bg-transparent text-sm focus-within:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
              >
                <Phone size={16} className="opacity-50" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+244 923 000 000"
                  className="w-full bg-transparent outline-none text-xs sm:text-sm"
                />
              </div>
            </div>
          )}

          {mode !== "recover" && (
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                {mode === "reset" ? "Nova Palavra-passe *" : "Palavra-passe *"}
              </label>
              <div
                className="flex items-center gap-2.5 px-3 py-2.5 rounded-2xl border bg-transparent text-sm focus-within:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
              >
                <Lock size={16} className="opacity-50" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full bg-transparent outline-none text-xs sm:text-sm"
                />
              </div>
            </div>
          )}

          {mode === "register" && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Perfil / Função *
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full p-2.5 rounded-2xl border text-xs sm:text-sm bg-transparent outline-none focus:border-[#246BFD]"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <option value="cliente">Cliente (Comprador)</option>
                    <option value="comerciante">Comerciante (Vendedor)</option>
                    <option value="entregador">Entregador</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Município de Residência
                  </label>
                  <select
                    value={municipality}
                    onChange={(e) => setMunicipality(e.target.value)}
                    className="w-full p-2.5 rounded-2xl border text-xs sm:text-sm bg-transparent outline-none focus:border-[#246BFD]"
                    style={{ borderColor: "var(--border)" }}
                  >
                    {UIGE_MUNICIPALITIES.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                  Bairro em Uíge
                </label>
                <div
                  className="flex items-center gap-2.5 px-3 py-2.5 rounded-2xl border bg-transparent text-sm focus-within:border-[#246BFD]"
                  style={{ borderColor: "var(--border)" }}
                >
                  <MapPin size={16} className="opacity-50" />
                  <input
                    type="text"
                    value={bairro}
                    onChange={(e) => setBairro(e.target.value)}
                    placeholder="Ex: Candombe Velho, Centro..."
                    className="w-full bg-transparent outline-none text-xs sm:text-sm"
                  />
                </div>
              </div>
            </>
          )}

          {mode === "reset" && (
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                Código de Confirmação (Demo: MU-2025-UG)
              </label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="MU-2025-UG"
                className="w-full p-3 rounded-2xl border bg-transparent text-xs sm:text-sm outline-none focus:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-2xl font-black text-sm text-white shadow-lg cursor-pointer transition-transform active:scale-95 disabled:opacity-50 mt-2"
            style={{ backgroundColor: "var(--primary)" }}
          >
            {loading
              ? "A processar..."
              : mode === "login"
              ? "Entrar na Conta"
              : mode === "register"
              ? "Criar Conta no Mercado"
              : mode === "recover"
              ? "Pedir Código de Recuperação"
              : "Definir Nova Palavra-passe"}
          </button>
        </form>

        {/* Demo Fast-Login Presets */}
        <div className="mt-5 pt-4 border-t" style={{ borderColor: "var(--border)" }}>
          <p className="text-[11px] font-bold text-center mb-2" style={{ color: "var(--text-secondary)" }}>
            Acesso Rápido de Teste (Contas Demo):
          </p>
          <div className="flex flex-wrap gap-1.5 justify-center">
            <button
              type="button"
              onClick={() => fillDemoAccount("seller")}
              className="px-2.5 py-1 rounded-xl text-[11px] font-semibold border hover:border-[#246BFD] transition-colors cursor-pointer"
              style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
            >
              Comerciante (Vendedor)
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount("admin")}
              className="px-2.5 py-1 rounded-xl text-[11px] font-semibold border hover:border-[#246BFD] transition-colors cursor-pointer"
              style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
            >
              Administrador (Demo)
            </button>
            <button
              type="button"
              onClick={() => fillDemoAccount("client")}
              className="px-2.5 py-1 rounded-xl text-[11px] font-semibold border hover:border-[#246BFD] transition-colors cursor-pointer"
              style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
            >
              Cliente Comprador
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
