import React, { useState } from "react";
import { X, Wallet, CreditCard, ArrowRight, CheckCircle2 } from "lucide-react";
import { fmtKz } from "@/lib/utils";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
  onRecharge: (amount: number) => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
  currentBalance,
  onRecharge,
}) => {
  const [amount, setAmount] = useState("5000");
  const [phone, setPhone] = useState("+244 923 000 000");
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleRecharge = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(amount);
    if (num > 0) {
      onRecharge(num);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1800);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/75 backdrop-blur-sm anim-fadeUp"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-6 border shadow-2xl anim-pop"
        style={{
          backgroundColor: "var(--surface)",
          borderColor: "var(--border)",
          color: "var(--text-primary)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl grid place-items-center bg-amber-500/20 text-amber-400">
              <Wallet size={18} />
            </div>
            <div>
              <h2 className="font-black text-base">Carteira Digital Mercado Uíge</h2>
              <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
                Saldo actual: <b style={{ color: "var(--accent)" }}>{fmtKz(currentBalance)}</b>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full border grid place-items-center hover:bg-slate-500/10 cursor-pointer"
            style={{ borderColor: "var(--border)" }}
          >
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle2 size={48} className="text-emerald-500 mx-auto animate-bounce" />
            <h3 className="text-lg font-black">Recarga Efectuada com Sucesso!</h3>
            <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
              O valor de {fmtKz(amount)} foi adicionado ao seu saldo de demonstração.
            </p>
          </div>
        ) : (
          <form onSubmit={handleRecharge} className="space-y-4 pt-4">
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                Valor da Recarga (Kz)
              </label>
              <div className="grid grid-cols-3 gap-2 mb-2">
                {["2000", "5000", "10000", "20000", "50000", "100000"].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAmount(val)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                      amount === val ? "bg-[#246BFD] text-white border-[#246BFD]" : "border-[var(--border)] hover:border-[#246BFD]"
                    }`}
                  >
                    {fmtKz(val)}
                  </button>
                ))}
              </div>
              <input
                type="number"
                min="500"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full p-3 rounded-2xl border bg-transparent text-sm font-bold outline-none focus:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
                placeholder="Outro valor..."
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                Número Multicaixa Express
              </label>
              <div className="flex items-center gap-2 p-3 rounded-2xl border bg-transparent text-sm" style={{ borderColor: "var(--border)" }}>
                <CreditCard size={18} className="opacity-50" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-transparent outline-none text-xs sm:text-sm font-medium"
                />
              </div>
              <p className="text-[10px] mt-1 opacity-60">
                Receberá uma notificação no telemóvel para autorizar a operação com o PIN Multicaixa Express.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl font-black text-sm text-white shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
              style={{ backgroundColor: "var(--primary)" }}
            >
              <span>Confirmar Recarga de {fmtKz(amount)}</span>
              <ArrowRight size={16} />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
