import React, { useState } from "react";
import { X, MapPin, Check, Search } from "lucide-react";
import { UIGE_MUNICIPALITIES, ANGOLA_PROVINCES } from "@/lib/utils";

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation: string;
  onSelectLocation: (location: string) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  currentLocation,
  onSelectLocation,
}) => {
  const [tab, setTab] = useState<"uige" | "provinces" | "custom">("uige");
  const [bairroInput, setBairroInput] = useState("");
  const [filterText, setFilterText] = useState("");

  if (!isOpen) return null;

  const handleSelect = (loc: string) => {
    onSelectLocation(loc);
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bairroInput.trim()) {
      onSelectLocation(`Uíge, ${bairroInput.trim()}`);
      onClose();
    }
  };

  const filteredMunicipalities = UIGE_MUNICIPALITIES.filter((m) =>
    m.toLowerCase().includes(filterText.toLowerCase())
  );

  const filteredProvinces = ANGOLA_PROVINCES.filter((p) =>
    p.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/75 backdrop-blur-sm anim-fadeUp"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-5 sm:p-6 border shadow-2xl anim-pop max-h-[90vh] flex flex-col"
        style={{
          backgroundColor: "var(--surface)",
          borderColor: "var(--border)",
          color: "var(--text-primary)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-xl grid place-items-center"
              style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
            >
              <MapPin size={18} />
            </div>
            <div>
              <h2 className="font-black text-base sm:text-lg leading-tight">Escolher Localização</h2>
              <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
                Encontre produtos e lojas próximos de si
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full border grid place-items-center hover:bg-slate-500/10 cursor-pointer"
            style={{ borderColor: "var(--border)" }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1.5 p-1 rounded-2xl my-3 border text-xs font-bold" style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}>
          <button
            type="button"
            onClick={() => setTab("uige")}
            className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              tab === "uige" ? "bg-[#246BFD] text-white shadow-sm" : "hover:text-[#246BFD]"
            }`}
          >
            Municípios do Uíge
          </button>
          <button
            type="button"
            onClick={() => setTab("provinces")}
            className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              tab === "provinces" ? "bg-[#246BFD] text-white shadow-sm" : "hover:text-[#246BFD]"
            }`}
          >
            Outras Províncias
          </button>
          <button
            type="button"
            onClick={() => setTab("custom")}
            className={`flex-1 py-1.5 rounded-xl transition-all cursor-pointer ${
              tab === "custom" ? "bg-[#246BFD] text-white shadow-sm" : "hover:text-[#246BFD]"
            }`}
          >
            Bairro Manual
          </button>
        </div>

        {tab !== "custom" && (
          <div className="relative mb-3">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
            <input
              type="text"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder="Filtrar por nome..."
              className="w-full pl-9 pr-3 py-2 rounded-xl text-xs border bg-transparent outline-none focus:border-[#246BFD]"
              style={{ borderColor: "var(--border)" }}
            />
          </div>
        )}

        {/* Content */}
        <div className="overflow-y-auto flex-1 pr-1 space-y-1">
          {tab === "uige" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {filteredMunicipalities.map((municipality) => {
                const label = `${municipality}, Uíge`;
                const isSelected = currentLocation.includes(municipality);
                return (
                  <button
                    key={municipality}
                    type="button"
                    onClick={() => handleSelect(label)}
                    className={`flex items-center justify-between p-2.5 rounded-xl text-xs font-bold border transition-colors text-left cursor-pointer ${
                      isSelected
                        ? "bg-[#246BFD]/15 border-[#246BFD] text-[#246BFD]"
                        : "border-[var(--border)] hover:border-[#246BFD]"
                    }`}
                  >
                    <span className="truncate">{municipality}</span>
                    {isSelected && <Check size={14} className="text-[#246BFD] shrink-0" />}
                  </button>
                );
              })}
            </div>
          )}

          {tab === "provinces" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {filteredProvinces.map((province) => {
                const label = `${province}, Angola`;
                const isSelected = currentLocation.includes(province);
                return (
                  <button
                    key={province}
                    type="button"
                    onClick={() => handleSelect(label)}
                    className={`flex items-center justify-between p-2.5 rounded-xl text-xs font-bold border transition-colors text-left cursor-pointer ${
                      isSelected
                        ? "bg-[#246BFD]/15 border-[#246BFD] text-[#246BFD]"
                        : "border-[var(--border)] hover:border-[#246BFD]"
                    }`}
                  >
                    <span className="truncate">{province}</span>
                    {isSelected && <Check size={14} className="text-[#246BFD] shrink-0" />}
                  </button>
                );
              })}
            </div>
          )}

          {tab === "custom" && (
            <form onSubmit={handleCustomSubmit} className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                  Indique o seu Bairro ou Rua em Uíge
                </label>
                <input
                  type="text"
                  value={bairroInput}
                  onChange={(e) => setBairroInput(e.target.value)}
                  placeholder="Ex: Candombe Velho, Papá Simão, Centro..."
                  className="w-full p-3 rounded-2xl border bg-transparent text-sm outline-none focus:border-[#246BFD]"
                  style={{ borderColor: "var(--border)" }}
                  autoFocus
                />
              </div>

              <div className="text-xs space-y-1" style={{ color: "var(--text-secondary)" }}>
                <p className="font-semibold">Bairros Populares de Uíge:</p>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {["Centro", "Candombe Velho", "Papá Simão", "Mabanza Sosso", "Bairro Popular", "Catapa"].map((b) => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => {
                        setBairroInput(b);
                        onSelectLocation(`Uíge, ${b}`);
                        onClose();
                      }}
                      className="px-2.5 py-1 rounded-full text-[11px] border hover:border-[#246BFD] cursor-pointer"
                      style={{ borderColor: "var(--border)" }}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl font-black text-sm text-white shadow-md cursor-pointer transition-transform active:scale-95"
                style={{ backgroundColor: "var(--primary)" }}
              >
                Definir Localização
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
