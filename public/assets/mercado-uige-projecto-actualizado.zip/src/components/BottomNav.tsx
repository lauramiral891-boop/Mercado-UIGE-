import React from "react";
import { Home, LayoutGrid, Search, ShoppingCart, User as UserIcon } from "lucide-react";

interface BottomNavProps {
  activeView: string;
  onSelectNav: (view: string) => void;
  cartCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeView,
  onSelectNav,
  cartCount,
}) => {
  const navItems = [
    { id: "home", label: "Início", icon: Home },
    { id: "categories", label: "Categorias", icon: LayoutGrid },
    { id: "search", label: "Pesquisa", icon: Search },
    { id: "cart", label: "Carrinho", icon: ShoppingCart, isCart: true },
    { id: "profile", label: "Conta", icon: UserIcon },
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t backdrop-blur-xl transition-colors duration-200 pb-safe"
      style={{
        backgroundColor: "var(--nav-bg)",
        borderColor: "var(--border)",
      }}
    >
      <div className="grid grid-cols-5 items-center px-1 pt-1.5 pb-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            activeView === item.id ||
            (item.id === "profile" && (activeView === "seller" || activeView === "admin" || activeView === "orders" || activeView === "favorites"));

          if (item.isCart) {
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectNav(item.id)}
                className="flex flex-col items-center justify-center relative cursor-pointer group active:scale-95 transition-transform"
                title="Ver Carrinho de Compras"
              >
                <div
                  className="w-12 h-12 -mt-6 rounded-full flex items-center justify-center shadow-lg transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: "var(--primary)",
                    border: "3px solid var(--background)",
                  }}
                >
                  <Icon size={20} color="#FFFFFF" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-0.5 w-5 h-5 rounded-full bg-red-600 text-white text-[10px] font-black flex items-center justify-center shadow-md animate-bounce ring-1 ring-white">
                      {cartCount > 99 ? "99+" : cartCount}
                    </span>
                  )}
                </div>
                <span
                  className="text-[10px] font-bold mt-0.5 transition-colors"
                  style={{
                    color: isActive ? "var(--accent)" : "var(--text-secondary)",
                  }}
                >
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectNav(item.id)}
              className="flex flex-col items-center justify-center py-1 relative cursor-pointer active:scale-95 transition-transform"
              title={item.label}
            >
              <div className="relative">
                <Icon
                  size={20}
                  className="transition-colors duration-200"
                  style={{
                    color: isActive ? "var(--accent)" : "var(--text-secondary)",
                  }}
                />
                {isActive && (
                  <span
                    className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full"
                    style={{ backgroundColor: "var(--accent)" }}
                  />
                )}
              </div>
              <span
                className="text-[10px] font-bold mt-1 transition-colors"
                style={{
                  color: isActive ? "var(--accent)" : "var(--text-secondary)",
                }}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
