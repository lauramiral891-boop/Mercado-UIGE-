import React, { useRef, useState, useEffect } from "react";
import {
  Search,
  MapPin,
  Bell,
  Mic,
  SlidersHorizontal,
  Sun,
  Moon,
  Laptop,
  ShoppingCart,
  User as UserIcon,
  X,
  ChevronDown,
} from "lucide-react";
import { User, ThemeMode } from "@/types";

interface HeaderProps {
  currentLocation: string;
  onOpenLocationModal: () => void;
  query: string;
  onQueryChange: (q: string) => void;
  onSearch: (q: string) => void;
  onVoiceSearch: () => void;
  isListening: boolean;
  onToggleFilters: () => void;
  filtersActive: boolean;
  themeMode: ThemeMode;
  onSetThemeMode: (mode: ThemeMode) => void;
  unreadCount: number;
  onOpenNotifications: () => void;
  user: User | null;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onNavigateHome: () => void;
  activeView: string;
  onSelectNav: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLocation,
  onOpenLocationModal,
  query,
  onQueryChange,
  onSearch,
  onVoiceSearch,
  isListening,
  onToggleFilters,
  filtersActive,
  themeMode,
  onSetThemeMode,
  unreadCount,
  onOpenNotifications,
  user,
  onOpenAuth,
  onOpenProfile,
  onNavigateHome,
  activeView,
  onSelectNav,
}) => {
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const themeMenuRef = useRef<HTMLDivElement>(null);

  // Close theme menu on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(e.target as Node)) {
        setShowThemeMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      onSearch(query);
    }
  };

  return (
    <header
      className="sticky top-0 z-40 backdrop-blur-xl border-b transition-colors duration-200"
      style={{
        backgroundColor: "var(--header-bg)",
        borderColor: "var(--border)",
      }}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 sm:py-2.5">
        {/* Top Area: Logo + Location + Actions */}
        <div className="flex items-center justify-between gap-2 sm:gap-3">
          {/* Logo & Brand */}
          <button
            type="button"
            onClick={onNavigateHome}
            className="flex items-center gap-2 group text-left cursor-pointer focus:outline-none"
            title="Mercado Uíge - Início"
          >
            <div
              className="relative w-9 h-9 sm:w-10 sm:h-10 grid place-items-center rounded-2xl transition-transform group-hover:scale-105 duration-200 shadow-md"
              style={{
                background: "linear-gradient(135deg, #246BFD, #07111F)",
                border: "1px solid rgba(183, 243, 74, 0.4)",
              }}
            >
              <ShoppingCart size={20} color="#B7F34A" strokeWidth={2.4} />
              <span className="absolute -top-1 -right-1 text-[9px] animate-pulse">⭐</span>
            </div>
            <div className="leading-tight">
              <span className="font-black text-base sm:text-lg tracking-tight flex items-center">
                Mercado <span className="ml-1" style={{ color: "var(--accent)" }}>Uíge</span>
              </span>
              <span
                className="hidden sm:block text-[9px] font-bold tracking-widest uppercase opacity-75"
                style={{ color: "var(--text-secondary)" }}
              >
                Comprar • Vender • Conectar
              </span>
            </div>
          </button>

          {/* Location Selector */}
          <button
            type="button"
            onClick={onOpenLocationModal}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full border text-xs font-semibold max-w-[130px] sm:max-w-[200px] truncate transition-colors duration-200 hover:border-[#246BFD] cursor-pointer"
            style={{
              backgroundColor: "var(--surface)",
              borderColor: "var(--border)",
              color: "var(--text-primary)",
            }}
            title="Alterar localização seleccionada"
          >
            <MapPin size={13} className="shrink-0" style={{ color: "var(--accent)" }} />
            <span className="truncate">{currentLocation}</span>
            <ChevronDown size={12} className="shrink-0 opacity-60" />
          </button>

          {/* Right Actions: Theme + Notifications + User */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Theme Toggle dropdown */}
            <div className="relative" ref={themeMenuRef}>
              <button
                type="button"
                aria-label="Escolher tema de visualização"
                onClick={() => setShowThemeMenu(!showThemeMenu)}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border grid place-items-center transition-colors duration-200 hover:border-[#246BFD] cursor-pointer"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                  color: "var(--text-primary)",
                }}
                title={`Tema actual: ${themeMode === "dark" ? "Escuro" : themeMode === "light" ? "Claro" : "Automático (Android)"}`}
              >
                {themeMode === "dark" ? (
                  <Moon size={16} />
                ) : themeMode === "light" ? (
                  <Sun size={16} />
                ) : (
                  <Laptop size={16} />
                )}
              </button>

              {showThemeMenu && (
                <div
                  className="absolute right-0 mt-2 w-48 rounded-2xl p-1.5 shadow-2xl border text-xs font-bold z-50 anim-pop"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                    color: "var(--text-primary)",
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSetThemeMode("dark");
                      setShowThemeMenu(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                      themeMode === "dark" ? "bg-[#246BFD] text-white" : "hover:bg-slate-500/10"
                    }`}
                  >
                    <Moon size={14} /> Modo Escuro
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSetThemeMode("light");
                      setShowThemeMenu(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                      themeMode === "light" ? "bg-[#246BFD] text-white" : "hover:bg-slate-500/10"
                    }`}
                  >
                    <Sun size={14} /> Modo Claro
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSetThemeMode("system");
                      setShowThemeMenu(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left transition-colors cursor-pointer ${
                      themeMode === "system" ? "bg-[#246BFD] text-white" : "hover:bg-slate-500/10"
                    }`}
                  >
                    <Laptop size={14} /> Automático (Android)
                  </button>
                </div>
              )}
            </div>

            {/* Notifications */}
            <button
              type="button"
              aria-label="Notificações"
              onClick={onOpenNotifications}
              className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-full border grid place-items-center transition-colors duration-200 hover:border-[#246BFD] cursor-pointer"
              style={{
                backgroundColor: "var(--surface)",
                borderColor: "var(--border)",
                color: "var(--text-primary)",
              }}
              title="Notificações"
            >
              <Bell size={16} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-600 text-white font-black text-[9px] grid place-items-center ring-2 ring-[var(--background)]">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>

            {/* User Account Button */}
            {user ? (
              <button
                type="button"
                onClick={onOpenProfile}
                className="flex items-center gap-2 p-0.5 rounded-full hover:opacity-90 transition-opacity cursor-pointer"
                title={`${user.name} (${user.role})`}
              >
                <div
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full grid place-items-center font-black text-xs text-white shadow-sm"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div className="hidden lg:block text-left leading-none pr-1">
                  <span className="block text-xs font-bold truncate max-w-[100px]" style={{ color: "var(--text-primary)" }}>
                    {user.name.split(" ")[0]}
                  </span>
                  <span className="block text-[10px] capitalize opacity-65" style={{ color: "var(--text-secondary)" }}>
                    {user.role}
                  </span>
                </div>
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="px-3 sm:px-3.5 py-1.5 rounded-full font-bold text-xs text-white shadow-sm transition-transform active:scale-95 cursor-pointer flex items-center gap-1.5"
                style={{ backgroundColor: "var(--primary)" }}
              >
                <UserIcon size={13} />
                <span>Entrar</span>
              </button>
            )}
          </div>
        </div>

        {/* Second Area: Smart Search Bar */}
        <div className="mt-2 sm:mt-2.5 flex items-center gap-2">
          <div
            className="flex-1 flex items-center gap-2 px-3 py-1.5 sm:py-2 rounded-2xl border transition-all duration-200 focus-within:ring-2 focus-within:ring-[#246BFD]"
            style={{
              backgroundColor: "var(--surface)",
              borderColor: "var(--border)",
            }}
          >
            <Search size={16} className="opacity-50 shrink-0" style={{ color: "var(--text-secondary)" }} />
            <input
              type="text"
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Pesquisar telemóveis, computadores, lojas ou produtos em Uíge…"
              className="flex-1 bg-transparent outline-none text-xs sm:text-sm min-w-0"
              style={{ color: "var(--text-primary)" }}
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  onQueryChange("");
                  onSearch("");
                }}
                className="p-1 opacity-60 hover:opacity-100 cursor-pointer"
              >
                <X size={14} />
              </button>
            )}
            <button
              type="button"
              onClick={onVoiceSearch}
              className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                isListening ? "bg-red-500 text-white animate-pulse" : "hover:bg-slate-500/10 text-[#246BFD]"
              }`}
              title="Pesquisa por voz"
            >
              <Mic size={15} />
            </button>
          </div>

          {/* Quick Filter Button */}
          <button
            type="button"
            onClick={onToggleFilters}
            className={`px-3 py-1.5 sm:py-2 rounded-2xl border font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              filtersActive ? "bg-[#246BFD] text-white border-[#246BFD]" : "hover:border-[#246BFD]"
            }`}
            style={
              !filtersActive
                ? {
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                    color: "var(--text-primary)",
                  }
                : {}
            }
            title="Filtros e ordenação"
          >
            <SlidersHorizontal size={14} />
            <span className="hidden sm:inline">Filtros</span>
          </button>
        </div>

        {/* Desktop Quick Nav Tabs */}
        <nav className="hidden md:flex gap-1.5 mt-2.5 overflow-x-auto no-scrollbar text-xs font-bold pt-1">
          {[
            { id: "home", label: "Início" },
            { id: "categories", label: "Categorias" },
            { id: "stores", label: "Lojas" },
            { id: "search", label: "Pesquisa & Internet" },
            { id: "cart", label: "Carrinho" },
            { id: "orders", label: "Encomendas" },
            { id: "favorites", label: "Favoritos" },
            { id: "seller", label: "Vender no Uíge" },
            { id: "admin", label: "Administração" },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => onSelectNav(tab.id)}
              className={`px-3.5 py-1.5 rounded-full whitespace-nowrap transition-all duration-200 cursor-pointer ${
                activeView === tab.id
                  ? "bg-[#246BFD] text-white shadow-sm"
                  : "border hover:border-[#246BFD]"
              }`}
              style={
                activeView !== tab.id
                  ? {
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                      color: "var(--text-secondary)",
                    }
                  : {}
              }
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};
