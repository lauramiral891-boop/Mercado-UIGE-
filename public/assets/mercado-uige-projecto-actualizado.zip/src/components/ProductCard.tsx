import React from "react";
import { Heart, ShoppingCart, Star, MapPin, Store as StoreIcon, Crown } from "lucide-react";
import { Product } from "@/types";
import { fmtKz } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onOpenProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
  onOpenProduct,
}) => {
  const isOutOfStock = Number(product.stock) <= 0;
  const isLowStock = Number(product.stock) > 0 && Number(product.stock) <= 5;

  return (
    <div
      className="group relative rounded-3xl overflow-hidden border transition-all duration-300 hover:shadow-xl flex flex-col justify-between"
      style={{
        backgroundColor: "var(--surface)",
        borderColor: "var(--border)",
        boxShadow: "var(--shadow-card)",
      }}
    >
      {/* Image & Badges */}
      <div
        className="relative aspect-4/3 w-full overflow-hidden cursor-pointer"
        onClick={() => onOpenProduct(product)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=600&q=80";
          }}
        />

        {/* Gradient overlay on top for contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 opacity-70 group-hover:opacity-60 transition-opacity" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.discount > 0 && (
            <span
              className="text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-md"
              style={{
                backgroundColor: "var(--accent)",
                color: "var(--accent-text)",
              }}
            >
              -{product.discount}%
            </span>
          )}
          {product.storeVip && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 flex items-center gap-1 shadow-sm">
              <Crown size={10} className="fill-current" /> VIP
            </span>
          )}
        </div>

        {/* Favorite Button */}
        <button
          type="button"
          aria-label={isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(product);
          }}
          className="absolute top-2.5 right-2.5 w-9 h-9 rounded-full grid place-items-center bg-black/40 hover:bg-black/60 backdrop-blur-md transition-transform active:scale-90 z-10"
        >
          <Heart
            size={18}
            className={`transition-colors duration-200 ${
              isFavorite ? "text-red-500 fill-red-500" : "text-white fill-none"
            }`}
          />
        </button>

        {/* Bottom Stock Badge */}
        <div className="absolute bottom-2.5 left-2.5 z-10">
          {isOutOfStock ? (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-600/90 text-white backdrop-blur-sm">
              Esgotado
            </span>
          ) : isLowStock ? (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/95 text-slate-950 font-black backdrop-blur-sm">
              Só {product.stock} un.
            </span>
          ) : (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/80 text-white backdrop-blur-sm">
              Em Stock
            </span>
          )}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-3.5 flex flex-col flex-1 justify-between gap-2.5">
        <div>
          {/* Store & Location */}
          <div className="flex items-center justify-between text-[11px] gap-2" style={{ color: "var(--text-secondary)" }}>
            <span className="truncate flex items-center gap-1 font-medium">
              <StoreIcon size={12} className="shrink-0 text-[#246BFD]" />
              {product.storeName || "Loja Uíge"}
            </span>
            <span className="shrink-0 flex items-center gap-0.5">
              <MapPin size={11} className="shrink-0" />
              {product.municipality || "Uíge"}
            </span>
          </div>

          {/* Product Name */}
          <h3
            onClick={() => onOpenProduct(product)}
            className="font-bold text-sm leading-snug line-clamp-2 mt-1.5 cursor-pointer hover:text-[#246BFD] transition-colors"
            style={{ color: "var(--text-primary)" }}
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Rating & Reviews */}
          <div className="flex items-center gap-1.5 text-xs mt-1" style={{ color: "var(--text-secondary)" }}>
            <div className="flex items-center text-amber-400 gap-0.5">
              <Star size={13} className="fill-amber-400" />
              <span className="font-bold text-[12px]">{Number(product.rating || 4.8).toFixed(1)}</span>
            </div>
            <span className="opacity-60 text-[11px]">({product.reviewsCount || 12})</span>
            <span className="opacity-40">•</span>
            <span className="text-[11px] font-medium capitalize">{product.condition === "usado" ? "Usado" : "Novo"}</span>
          </div>
        </div>

        {/* Pricing and Action */}
        <div>
          <div className="flex items-baseline gap-2 mt-1">
            <span
              className="font-black text-base md:text-lg tracking-tight"
              style={{ color: "var(--accent)" }}
            >
              {fmtKz(product.price)}
            </span>
            {product.oldPrice && (
              <span className="text-xs line-through opacity-50" style={{ color: "var(--text-muted)" }}>
                {fmtKz(product.oldPrice)}
              </span>
            )}
          </div>

          {/* Add to Cart Button */}
          <button
            type="button"
            disabled={isOutOfStock}
            onClick={() => onAddToCart(product)}
            className="mt-3 w-full py-2.5 px-3 rounded-2xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-sm text-white"
            style={{
              backgroundColor: "var(--primary)",
            }}
          >
            <ShoppingCart size={15} />
            <span>{isOutOfStock ? "Indisponível" : "Adicionar"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
