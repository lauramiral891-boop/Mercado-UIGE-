import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Bell,
  Smartphone,
  Shirt,
  Home as HomeIcon,
  Apple,
  Hammer,
  Wrench,
  Sparkles,
  Dumbbell,
  Tag,
  Truck,
  ShieldCheck,
  Zap,
  Headphones,
  Crown,
  Wallet,
  LogOut,
  Moon,
  Sun,
  Laptop,
  Trash2,
  Edit3,
  Eye,
  TrendingUp,
  DollarSign,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Send,
  MessageCircle,
  Flag,
  SlidersHorizontal,
  ArrowRight,
  BadgeCheck,
  Clock,
  Package,
  PackageCheck,
  Store as StoreIcon,
  Users,
  Megaphone,
  ChevronRight,
  ChevronLeft,
  SearchX,
  RefreshCw,
  Plus,
  Minus,
  Globe,
  Play,
  Share2,
  Camera,
  Search as SearchIcon,
  ShoppingCart,
  Heart,
  Star,
  MapPin,
} from "lucide-react";

import {
  Product,
  Store,
  Category,
  User,
  Order,
  NotificationItem,
  ReportItem,
  ThemeMode,
  ExternalSearchResponse,
} from "@/types";
import { fmtKz, normalize, UIGE_MUNICIPALITIES, ORDER_STATUSES } from "@/lib/utils";
import { LOCAL_SERVICES } from "@/lib/seed";
import {
  getStoredLocation,
  saveStoredLocation,
  getStoredCurrentUser,
  saveCurrentUser,
  getStoredUsers,
  saveUsers,
} from "@/lib/storage";
import { api } from "@/services/api";

import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { ProductCard } from "@/components/ProductCard";
import { LocationModal } from "@/components/LocationModal";
import { AuthModal } from "@/components/AuthModal";
import { ProductDetailModal } from "@/components/ProductDetailModal";
import { WalletModal } from "@/components/WalletModal";

const CAT_ICON_MAP: Record<string, any> = {
  smartphone: Smartphone,
  shirt: Shirt,
  home: HomeIcon,
  apple: Apple,
  hammer: Hammer,
  wrench: Wrench,
  sparkles: Sparkles,
  dumbbell: Dumbbell,
  tag: Tag,
};

export default function App() {
  // Splash & Onboarding
  const [booted, setBooted] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardStep, setOnboardStep] = useState(0);

  // Theme & Location
  const [themeMode, setThemeMode] = useState<ThemeMode>("dark");
  const [location, setLocation] = useState(getStoredLocation());
  const [showLocationModal, setShowLocationModal] = useState(false);

  // Core Data
  const [products, setProducts] = useState<Product[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Navigation / Views
  const [view, setView] = useState("home");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);

  // User & Auth
  const [user, setUser] = useState<User | null>(getStoredCurrentUser());
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<"login" | "register" | "recover">("login");
  const [walletModalOpen, setWalletModalOpen] = useState(false);

  // Cart & Wishlist
  const [cart, setCart] = useState<{ productId: string; qty: number; selectedVariant?: string }[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("mu_cart_v2") || "[]");
    } catch {
      return [];
    }
  });
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("mu_favs_v2") || "[]");
    } catch {
      return [];
    }
  });

  // Orders & Notifications
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Search State
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searchSuggestions, setSearchSuggestions] = useState<string[]>([]);
  const [searchSource, setSearchSource] = useState("plataforma");
  const [externalSearchResponse, setExternalSearchResponse] = useState<ExternalSearchResponse | null>(null);
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("mu_history_v2") || "[]");
    } catch {
      return ["telemóvel", "iphone barato", "computador para jogos", "sapatos no Uíge"];
    }
  });
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    sort: "relevancia",
    maxPrice: "",
    location: "todas",
    category: "todas",
    available: false,
  });
  const [isListening, setIsListening] = useState(false);

  // Promotional Banner Slider
  const [bannerIdx, setBannerIdx] = useState(0);

  // Checkout form
  const [checkoutAddress, setCheckoutAddress] = useState(
    user ? `${user.bairro ? user.bairro + ", " : ""}${user.municipality || "Uíge"}, Uíge` : ""
  );
  const [checkoutPayment, setCheckoutPayment] = useState("Multicaixa Express");
  const [checkoutDelivery, setCheckoutDelivery] = useState(1500);

  // Seller Dashboard Form
  const [sellerForm, setSellerForm] = useState({
    name: "",
    description: "",
    price: "",
    oldPrice: "",
    stock: "10",
    categoryName: "Electrónicos",
    brand: "",
    condition: "novo" as "novo" | "usado",
    image: "",
    municipality: "Uíge",
  });
  const [storeForm, setStoreForm] = useState({
    name: "",
    description: "",
    municipality: "Uíge",
    category: "Electrónicos",
  });

  // Admin Dashboard State
  const [adminData, setAdminData] = useState<{
    stats: { users: number; stores: number; products: number; orders: number; revenue: number };
    users: User[];
    stores: Store[];
    products: Product[];
    orders: Order[];
    reports: ReportItem[];
  } | null>(null);
  const [broadcastTitle, setBroadcastTitle] = useState("");
  const [broadcastBody, setBroadcastBody] = useState("");
  const [newCatName, setNewCatName] = useState("");

  // User Profile Form
  const [profileForm, setProfileForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    municipality: user?.municipality || "Uíge",
    bairro: user?.bairro || "",
  });

  // UI Toast message
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  // --- THEME SYNC ---
  useEffect(() => {
    const savedTheme = localStorage.getItem("mu_theme_mode_v2") as ThemeMode;
    if (savedTheme) {
      setThemeMode(savedTheme);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("mu_theme_mode_v2", themeMode);

    const applyTheme = (isDark: boolean) => {
      if (isDark) {
        document.documentElement.classList.remove("light");
        document.body.classList.remove("light");
      } else {
        document.documentElement.classList.add("light");
        document.body.classList.add("light");
      }
    };

    if (themeMode === "system") {
      const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
      applyTheme(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => applyTheme(e.matches);
      mediaQuery.addEventListener("change", listener);
      return () => mediaQuery.removeEventListener("change", listener);
    } else {
      applyTheme(themeMode === "dark");
    }
  }, [themeMode]);

  // --- BOOT & ONBOARDING ---
  useEffect(() => {
    const onboarded = localStorage.getItem("mu_onboarded_v2");
    const timer = setTimeout(() => {
      setBooted(true);
      if (!onboarded) {
        setShowOnboarding(true);
      }
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  // --- PERSISTENCE OF CART, FAVS, HISTORY ---
  useEffect(() => {
    localStorage.setItem("mu_cart_v2", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("mu_favs_v2", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem("mu_history_v2", JSON.stringify(searchHistory));
  }, [searchHistory]);

  // --- LOAD CATALOG & DATA ---
  const loadCatalogData = async () => {
    setLoading(true);
    try {
      const data = await api.getCatalog();
      setProducts(data.products);
      setStores(data.stores);
      setCategories(data.categories);
    } catch {
      showToast("Apresentando catálogo local com dados de teste.");
    } finally {
      setLoading(false);
    }
  };

  const loadUserData = async () => {
    if (!user) return;
    try {
      const userOrders = await api.getOrders();
      setOrders(userOrders);
      const notifs = await api.getNotifications();
      setNotifications(notifs);
    } catch {}
  };

  useEffect(() => {
    loadCatalogData();
  }, []);

  useEffect(() => {
    if (user) {
      loadUserData();
      setProfileForm({
        name: user.name || "",
        phone: user.phone || "",
        municipality: user.municipality || "Uíge",
        bairro: user.bairro || "",
      });
      setCheckoutAddress(
        `${user.bairro ? user.bairro + ", " : ""}${user.municipality || "Uíge"}, Uíge`
      );
    }
  }, [user]);

  // Promotional Banner Rotation
  useEffect(() => {
    const interval = setInterval(() => {
      setBannerIdx((i) => (i + 1) % 3);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  // Cart Calculations
  const detailedCart = useMemo(() => {
    return cart
      .map((item) => {
        const product = products.find((p) => p.id === item.productId);
        return {
          ...item,
          product,
        };
      })
      .filter((item): item is { productId: string; qty: number; selectedVariant?: string; product: Product } =>
        Boolean(item.product)
      );
  }, [cart, products]);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const cartSubtotal = detailedCart.reduce(
    (sum, item) => sum + item.product.price * item.qty,
    0
  );
  const cartTotal = cartSubtotal + checkoutDelivery;
  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;

  // --- PRODUCT ACTIONS ---
  const handleAddToCart = (product: Product, quantity = 1, variant?: string) => {
    if (Number(product.stock) <= 0) {
      showToast("Lamentamos, este produto está de momento esgotado.");
      return;
    }

    const existingIdx = cart.findIndex((item) => item.productId === product.id);
    if (existingIdx !== -1) {
      const currentQty = cart[existingIdx].qty;
      const newQty = currentQty + quantity;
      if (newQty > Number(product.stock)) {
        showToast(`Stock insuficiente. Só temos ${product.stock} unidades disponíveis.`);
        return;
      }
      const updated = [...cart];
      updated[existingIdx].qty = newQty;
      if (variant) updated[existingIdx].selectedVariant = variant;
      setCart(updated);
    } else {
      setCart([...cart, { productId: product.id, qty: quantity, selectedVariant: variant }]);
    }

    showToast(`Adicionado ao carrinho: ${product.name} ✓`);
  };

  const handleToggleFavorite = (product: Product) => {
    const exists = favorites.includes(product.id);
    if (exists) {
      setFavorites(favorites.filter((id) => id !== product.id));
      showToast("Removido dos favoritos.");
    } else {
      setFavorites([...favorites, product.id]);
      showToast("Guardado nos teus favoritos ❤️");
    }
  };

  const handleUpdateCartQty = (productId: string, delta: number) => {
    const product = products.find((p) => p.id === productId);
    const existing = cart.find((c) => c.productId === productId);
    if (!existing) return;

    const newQty = existing.qty + delta;
    if (newQty <= 0) {
      setCart(cart.filter((c) => c.productId !== productId));
      showToast("Item removido do carrinho.");
      return;
    }
    if (product && newQty > Number(product.stock)) {
      showToast(`Apenas ${product.stock} unidades disponíveis em stock.`);
      return;
    }
    setCart(
      cart.map((c) => (c.productId === productId ? { ...c, qty: newQty } : c))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter((c) => c.productId !== productId));
    showToast("Produto retirado do carrinho.");
  };

  // --- SEARCH EXECUTION ---
  const handlePerformSearch = async (queryText: string, source = searchSource) => {
    setSearchQuery(queryText);
    const trimmed = queryText.trim();

    if (source !== "plataforma") {
      const resp = api.getExternalSearchStatus(trimmed, source);
      setExternalSearchResponse(resp);
      setSearchResults([]);
      setView("search");
      return;
    }

    setExternalSearchResponse(null);

    const res = await api.search(trimmed, {
      sort: filters.sort,
      maxPrice: filters.maxPrice ? Number(filters.maxPrice) : undefined,
      location: filters.location,
      category: filters.category,
      available: filters.available,
      source: "plataforma",
    });

    setSearchResults(res.results);
    setSearchSuggestions(res.suggestions);

    if (trimmed && !searchHistory.includes(trimmed)) {
      setSearchHistory([trimmed, ...searchHistory.slice(0, 7)]);
    }

    setView("search");
  };

  const handleVoiceSearch = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      showToast("O seu navegador não suporta pesquisa por voz. Utilize o teclado.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "pt-PT";
      setIsListening(true);
      showToast("A ouvir... Diga o que procura no Mercado Uíge.");

      recognition.onresult = (event: any) => {
        setIsListening(false);
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handlePerformSearch(transcript);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
        showToast("Não foi possível captar a voz. Tente novamente.");
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
      showToast("Erro ao iniciar microfone.");
    }
  };

  // --- ORDERS / CHECKOUT ---
  const handleConfirmOrder = async () => {
    if (!user) {
      setAuthModalMode("login");
      setAuthModalOpen(true);
      return;
    }
    if (!checkoutAddress.trim()) {
      showToast("Por favor, preencha o seu endereço de entrega em Uíge.");
      return;
    }
    if (cart.length === 0) {
      showToast("O carrinho está vazio.");
      return;
    }

    try {
      const newOrder = await api.createOrder({
        items: cart,
        address: checkoutAddress,
        paymentMethod: checkoutPayment,
        deliveryFee: checkoutDelivery,
      });

      setCart([]);
      setOrders([newOrder, ...orders]);
      await loadCatalogData(); // Refresh updated stock
      await loadUserData();
      showToast("Encomenda confirmada com sucesso! 🎉");
      setView("orders");
    } catch (err: any) {
      showToast(err.message || "Erro ao processar encomenda.");
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: Order["status"]) => {
    try {
      await api.updateOrderStatus(orderId, status);
      setOrders(orders.map((o) => (o.id === orderId ? { ...o, status } : o)));
      showToast(`Estado da encomenda actualizado: ${status}`);
    } catch (err: any) {
      showToast(err.message || "Erro ao actualizar estado.");
    }
  };

  // --- SELLER DASHBOARD ---
  const handlePublishProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthModalMode("login");
      setAuthModalOpen(true);
      return;
    }

    try {
      const newProduct = await api.publishProduct({
        name: sellerForm.name,
        description: sellerForm.description,
        price: Number(sellerForm.price),
        oldPrice: sellerForm.oldPrice ? Number(sellerForm.oldPrice) : null,
        stock: Number(sellerForm.stock),
        categoryName: sellerForm.categoryName,
        brand: sellerForm.brand,
        condition: sellerForm.condition,
        image: sellerForm.image,
        municipality: sellerForm.municipality,
      });

      setProducts([newProduct, ...products]);
      setSellerForm({
        name: "",
        description: "",
        price: "",
        oldPrice: "",
        stock: "10",
        categoryName: "Electrónicos",
        brand: "",
        condition: "novo",
        image: "",
        municipality: "Uíge",
      });
      showToast("Produto publicado com sucesso no catálogo!");
      loadCatalogData();
    } catch (err: any) {
      showToast(err.message || "Erro ao publicar produto.");
    }
  };

  const handleCreateStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setAuthModalMode("login");
      setAuthModalOpen(true);
      return;
    }
    try {
      const newStore = await api.createStore(storeForm);
      setStores([...stores, newStore]);
      showToast("Loja criada com sucesso!");
      loadCatalogData();
    } catch (err: any) {
      showToast(err.message || "Erro ao criar loja.");
    }
  };

  // --- ADMIN ACTIONS ---
  const loadAdminDashboard = async () => {
    const data = await api.getAdminData();
    setAdminData(data);
  };

  const handleAdminSuspendUser = async (userId: string, currentSuspended: boolean) => {
    await api.suspendUser(userId, currentSuspended);
    await loadAdminDashboard();
    showToast(currentSuspended ? "Utilizador reactivado com sucesso." : "Utilizador suspenso.");
  };

  const handleAdminToggleVip = async (storeId: string, currentVip: boolean) => {
    await api.toggleStoreVip(storeId, currentVip);
    await loadAdminDashboard();
    await loadCatalogData();
    showToast(currentVip ? "Estatuto VIP removido." : "Loja marcada como VIP! ⭐");
  };

  const handleAdminRemoveProduct = async (productId: string) => {
    if (confirm("Tem a certeza que deseja remover este produto da plataforma?")) {
      await api.deleteProduct(productId);
      await loadAdminDashboard();
      await loadCatalogData();
      showToast("Produto removido com sucesso.");
    }
  };

  const handleAdminResolveReport = async (reportId: string) => {
    await api.resolveReport(reportId);
    await loadAdminDashboard();
    showToast("Denúncia marcada como resolvida.");
  };

  const handleAdminBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.broadcastMessage(broadcastTitle, broadcastBody);
      setBroadcastTitle("");
      setBroadcastBody("");
      await loadUserData();
      showToast("Aviso transmitido com sucesso a todos os utilizadores!");
    } catch (err: any) {
      showToast(err.message || "Erro ao transmitir aviso.");
    }
  };

  const handleAdminAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const cat = await api.addCategory(newCatName);
      setCategories([...categories, cat]);
      setNewCatName("");
      showToast(`Categoria "${cat.name}" criada com sucesso!`);
    } catch (err: any) {
      showToast(err.message || "Erro ao criar categoria.");
    }
  };

  // --- USER PROFILE & LOGOUT ---
  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const users = getStoredUsers();
    const idx = users.findIndex((u) => u.id === user.id);
    const updatedUser: User = {
      ...user,
      name: profileForm.name.trim() || user.name,
      phone: profileForm.phone.trim() || user.phone,
      municipality: profileForm.municipality,
      bairro: profileForm.bairro.trim() || user.bairro,
    };
    if (idx !== -1) {
      users[idx] = updatedUser;
      saveUsers(users);
    }
    saveCurrentUser(updatedUser);
    setUser(updatedUser);
    showToast("Dados do perfil actualizados.");
  };

  const handleLogout = () => {
    saveCurrentUser(null);
    setUser(null);
    showToast("Sessão terminada. Volte sempre ao Mercado Uíge!");
    setView("home");
  };

  const handleDeleteAccount = () => {
    if (confirm("Tem a certeza absoluta? Esta acção eliminará os seus dados permanentemente.")) {
      if (user) {
        const users = getStoredUsers().filter((u) => u.id !== user.id);
        saveUsers(users);
      }
      handleLogout();
      showToast("A sua conta foi eliminada.");
    }
  };

  // Sections derivation
  const featuredProducts = useMemo(() => products.filter((p) => p.isFeatured), [products]);
  const bestSellers = useMemo(
    () => [...products].sort((a, b) => (b.sales || 0) - (a.sales || 0)).slice(0, 8),
    [products]
  );
  const recentProducts = useMemo(
    () =>
      [...products].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 8),
    [products]
  );
  const specialOffers = useMemo(
    () => products.filter((p) => p.discount > 0).sort((a, b) => b.discount - a.discount).slice(0, 8),
    [products]
  );
  const sponsoredProducts = useMemo(
    () => products.filter((p) => p.isSponsored || p.discount >= 25).slice(0, 6),
    [products]
  );
  const recommendedForYou = useMemo(() => {
    if (favorites.length > 0) {
      const favCats = products.filter((p) => favorites.includes(p.id)).map((p) => p.categoryName);
      return products.filter((p) => favCats.includes(p.categoryName)).slice(0, 8);
    }
    return bestSellers.slice(0, 8);
  }, [favorites, products, bestSellers]);

  // Seller metrics
  const mySellerProducts = useMemo(
    () => (user ? products.filter((p) => p.sellerId === user.id) : []),
    [user, products]
  );
  const sellerRevenue = useMemo(() => {
    return orders
      .filter((o) => o.status !== "Cancelada")
      .reduce((sum, o) => sum + Number(o.total || 0), 0);
  }, [orders]);

  // --- SPLASH SCREEN ---
  if (!booted) {
    return (
      <div
        className="min-h-screen grid place-items-center px-6 selection:bg-[#B7F34A] selection:text-slate-950"
        style={{
          background: "radial-gradient(ellipse at top, #0B2A5B 0%, #07111F 65%)",
          color: "#F8FAFC",
        }}
      >
        <div className="text-center anim-fadeUp max-w-sm">
          <div
            className="mx-auto w-28 h-28 grid place-items-center rounded-3xl anim-float anim-glow shadow-2xl"
            style={{
              background: "linear-gradient(135deg, #246BFD, #07111F)",
              border: "1.5px solid rgba(183, 243, 74, 0.45)",
            }}
          >
            <ShoppingCart size={54} color="#B7F34A" strokeWidth={2.3} />
          </div>
          <h1 className="mt-6 text-4xl font-black tracking-tight">
            Mercado <span style={{ color: "var(--accent)" }}>Uíge</span>
          </h1>
          <p className="mt-1 text-xs tracking-widest uppercase opacity-75 font-semibold">
            Comprar • Vender • Conectar
          </p>

          <div
            className="mt-8 w-9 h-9 mx-auto rounded-full border-3 border-white/20 border-t-[#B7F34A]"
            style={{ animation: "mu-spin 0.9s linear infinite" }}
          />
          <p className="mt-4 text-xs opacity-60">A carregar o mercado digital da província…</p>

          <p className="mt-8 text-sm italic font-medium opacity-85">
            Uíge cresce com o <span style={{ color: "var(--accent)" }}>comércio digital</span>
          </p>
        </div>
      </div>
    );
  }

  // --- ONBOARDING FLOW ---
  if (showOnboarding) {
    const steps = [
      {
        title: "Tudo o que precisas, num só lugar!",
        desc: "Produtos, lojas de confiança e serviços locais em toda a província do Uíge, com levantamento fácil ou entrega rápida.",
        icon: Zap,
      },
      {
        title: "Pesquisa inteligente em Português",
        desc: "Encontra telemóveis, computadores, moda ou comida sem te preocupares com acentos. “telemovel” encontra “telemóvel”, e “iphone barato” ordena pelo menor preço.",
        icon: SearchIcon,
      },
      {
        title: "Compra segura e vende com facilidade",
        desc: "Paga comodamente com Multicaixa Express, acompanha cada passo da tua encomenda e abre a tua loja para venderes os teus artigos.",
        icon: ShieldCheck,
      },
    ];

    const currentStep = steps[onboardStep];
    const StepIcon = currentStep.icon;

    return (
      <div
        className="min-h-screen grid place-items-center px-6 selection:bg-[#B7F34A] selection:text-slate-950"
        style={{
          background: "radial-gradient(ellipse at top, #0B2A5B 0%, #07111F 70%)",
          color: "#F8FAFC",
        }}
      >
        <div className="w-full max-w-md text-center anim-fadeUp">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div
              className="w-10 h-10 rounded-2xl grid place-items-center"
              style={{ background: "linear-gradient(135deg, #246BFD, #07111F)" }}
            >
              <ShoppingCart size={22} color="#B7F34A" />
            </div>
            <span className="font-black text-xl">
              Mercado <span style={{ color: "var(--accent)" }}>Uíge</span>
            </span>
          </div>

          <div
            className="mx-auto w-24 h-24 grid place-items-center rounded-3xl shadow-xl anim-pop"
            style={{
              background: "rgba(36, 107, 253, 0.18)",
              border: "1.5px solid rgba(36, 107, 253, 0.4)",
            }}
          >
            <StepIcon size={46} color="#B7F34A" />
          </div>

          <h2 className="mt-6 text-2xl font-black">{currentStep.title}</h2>
          <p className="mt-3 text-sm opacity-80 leading-relaxed max-w-sm mx-auto">
            {currentStep.desc}
          </p>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {steps.map((_, i) => (
              <span
                key={i}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  i === onboardStep ? "w-8 bg-[#B7F34A]" : "w-2.5 bg-white/30"
                }`}
              />
            ))}
          </div>

          {/* Buttons */}
          <div className="flex gap-3 mt-8">
            <button
              type="button"
              onClick={() => {
                localStorage.setItem("mu_onboarded_v2", "1");
                setShowOnboarding(false);
              }}
              className="flex-1 py-3.5 rounded-2xl font-bold text-xs border border-white/25 hover:bg-white/10 transition-colors cursor-pointer"
            >
              Saltar
            </button>
            <button
              type="button"
              onClick={() => {
                if (onboardStep < steps.length - 1) {
                  setOnboardStep(onboardStep + 1);
                } else {
                  localStorage.setItem("mu_onboarded_v2", "1");
                  setShowOnboarding(false);
                }
              }}
              className="flex-1 py-3.5 rounded-2xl font-black text-xs shadow-lg transition-transform active:scale-95 cursor-pointer text-slate-950"
              style={{ backgroundColor: "var(--accent)" }}
            >
              {onboardStep < steps.length - 1 ? "Avançar" : "Entrar no Mercado"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- MAIN APP RENDER ---
  return (
    <div
      className="min-h-screen flex flex-col justify-between pb-24 md:pb-6 transition-colors duration-200"
      style={{
        backgroundColor: "var(--background)",
        color: "var(--text-primary)",
      }}
    >
      {/* 1. Header (Requirement 5) */}
      <Header
        currentLocation={location}
        onOpenLocationModal={() => setShowLocationModal(true)}
        query={searchQuery}
        onQueryChange={setSearchQuery}
        onSearch={(q) => handlePerformSearch(q)}
        onVoiceSearch={handleVoiceSearch}
        isListening={isListening}
        onToggleFilters={() => setShowFilters(!showFilters)}
        filtersActive={showFilters}
        themeMode={themeMode}
        onSetThemeMode={setThemeMode}
        unreadCount={unreadNotifsCount}
        onOpenNotifications={() => {
          if (!user) {
            setAuthModalMode("login");
            setAuthModalOpen(true);
          } else {
            setView("notifications");
          }
        }}
        user={user}
        onOpenAuth={() => {
          setAuthModalMode("login");
          setAuthModalOpen(true);
        }}
        onOpenProfile={() => setView("profile")}
        onNavigateHome={() => setView("home")}
        activeView={view}
        onSelectNav={(v) => {
          if (v === "admin") loadAdminDashboard();
          setView(v);
        }}
      />

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 py-2 sm:py-3">
        {/* Testing Demonstration Notice Banner */}
        <div
          className="w-full mb-3 px-3.5 py-2 rounded-2xl border flex items-center justify-between text-xs font-bold shadow-sm"
          style={{
            backgroundColor: "var(--surface)",
            borderColor: "var(--border)",
            color: "var(--text-secondary)",
          }}
        >
          <span className="flex items-center gap-1.5 truncate">
            <BadgeCheck size={15} style={{ color: "var(--accent)" }} className="shrink-0" />
            <span className="truncate">
              <b>Mercado Uíge:</b> Catálogo oficial provincial. Os artigos listados são produtos de demonstração para testes no Uíge.
            </span>
          </span>
          <span
            className="shrink-0 hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-black"
            style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
          >
            Angola • Kwanza (Kz)
          </span>
        </div>

        {/* ============================================================ */}
        {/* VIEW: HOME (Requirement 7 - 12 Organised Sections) */}
        {/* ============================================================ */}
        {view === "home" && (
          <div className="space-y-6 anim-fadeUp">
            {/* 3. Banner Promocional Slider */}
            <div
              className="relative rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-10"
              style={{
                background:
                  bannerIdx === 0
                    ? "linear-gradient(120deg, #246BFD 0%, #0B2A5B 55%, #07111F 100%)"
                    : bannerIdx === 1
                    ? "linear-gradient(120deg, #07111F 0%, #15325B 60%, #246BFD 100%)"
                    : "linear-gradient(120deg, #111D30 0%, #17386D 60%, #00C2A8 100%)",
                color: "#FFFFFF",
              }}
            >
              <div className="max-w-lg z-10 relative">
                <span
                  className="text-xs font-black px-3 py-1 rounded-full shadow-md uppercase tracking-wider text-slate-950"
                  style={{ backgroundColor: "var(--accent)" }}
                >
                  {bannerIdx === 0
                    ? "ATÉ -70% DE DESCONTO EM UÍGE"
                    : bannerIdx === 1
                    ? "AUTÊNTICO CAFÉ DO UÍGE"
                    : "TELEMÓVEIS E INFORMÁTICA"}
                </span>

                <h1 className="mt-3.5 text-2xl sm:text-4xl md:text-5xl font-black leading-tight tracking-tight">
                  {bannerIdx === 0
                    ? "Grandes Ofertas no Uíge!"
                    : bannerIdx === 1
                    ? "O Melhor da Nossa Província"
                    : "Gaming & Tecnologia"}
                </h1>

                <p className="mt-2 text-xs sm:text-sm md:text-base opacity-85 leading-relaxed">
                  {bannerIdx === 0
                    ? "Telemóveis, moda de cerimónia, produtos frescos do campo e entrega rápida na cidade."
                    : bannerIdx === 1
                    ? "Apoie os produtores do Negage e do Uíge. Produtos frescos e café seleccionados directamente."
                    : "Laptops com RTX 4060, teclados mecânicos e smartphones testados com assistência local."}
                </p>

                <div className="flex flex-wrap gap-2.5 mt-5">
                  <button
                    type="button"
                    onClick={() => handlePerformSearch(bannerIdx === 1 ? "café" : bannerIdx === 2 ? "computador para jogos" : "oferta")}
                    className="px-5 py-2.5 sm:py-3 rounded-2xl font-black text-xs sm:text-sm text-slate-950 shadow-lg cursor-pointer transition-transform active:scale-95"
                    style={{ backgroundColor: "var(--accent)" }}
                  >
                    Comprar Agora
                  </button>
                  <button
                    type="button"
                    onClick={() => setView("stores")}
                    className="px-4 py-2.5 sm:py-3 rounded-2xl font-bold text-xs sm:text-sm border border-white/30 hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    Ver Lojas Locais
                  </button>
                </div>
              </div>

              {/* Slider Dots */}
              <div className="absolute bottom-3 right-4 flex gap-1.5 z-10">
                {[0, 1, 2].map((idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setBannerIdx(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      idx === bannerIdx ? "w-6 bg-[#B7F34A]" : "w-2 bg-white/40"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Trust Strip */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2.5">
              {[
                { icon: Zap, title: "Pesquisa Inteligente", sub: "Tolerante a erros e sotaques" },
                { icon: ShieldCheck, title: "Compra Confiável", sub: "Garantia e vendedores locais" },
                { icon: Truck, title: "Entregas em Uíge", sub: "No centro e no Negage" },
                { icon: StoreIcon, title: "Lojas Provinciais", sub: "Comércio moderno angolano" },
                { icon: Headphones, title: "Apoio ao Cliente", sub: "WhatsApp e mensagem directa" },
              ].map((item, i) => {
                const Icon = item.icon;
                return (
                  <div
                    key={i}
                    className="flex items-center gap-2.5 p-3 rounded-2xl border transition-colors shadow-sm"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div
                      className="w-8 h-8 rounded-xl grid place-items-center shrink-0"
                      style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
                    >
                      <Icon size={17} />
                    </div>
                    <div className="leading-tight min-w-0">
                      <div className="text-xs font-black truncate">{item.title}</div>
                      <div className="text-[10px] opacity-65 truncate" style={{ color: "var(--text-secondary)" }}>
                        {item.sub}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 4. Categorias */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Categorias Principais</h2>
                <button
                  type="button"
                  onClick={() => setView("categories")}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Explorar todas</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 sm:gap-3">
                {categories.map((c) => {
                  const Icon = CAT_ICON_MAP[c.icon] || Tag;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setFilters({ ...filters, category: c.name });
                        handlePerformSearch("", "plataforma");
                      }}
                      className="flex flex-col items-center justify-center p-3 rounded-2xl border transition-all duration-200 hover:shadow-md hover:border-[#246BFD] group cursor-pointer"
                      style={{
                        backgroundColor: "var(--surface)",
                        borderColor: "var(--border)",
                      }}
                    >
                      <div
                        className="w-11 h-11 rounded-2xl grid place-items-center transition-transform group-hover:scale-110 mb-1.5 shadow-sm"
                        style={{
                          backgroundColor: `${c.color}20`,
                          color: c.color,
                        }}
                      >
                        <Icon size={22} />
                      </div>
                      <span className="text-[11px] font-bold text-center leading-tight truncate w-full" style={{ color: "var(--text-primary)" }}>
                        {c.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Produtos em Destaque */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Produtos em Destaque</h2>
                <button
                  type="button"
                  onClick={() => handlePerformSearch("")}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Ver todos ({featuredProducts.length})</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              {loading ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="skeleton h-64 rounded-3xl" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                  {featuredProducts.slice(0, 8).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isFavorite={favorites.includes(product.id)}
                      onToggleFavorite={handleToggleFavorite}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                      onOpenProduct={(p) => setSelectedProduct(p)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* 6. Mais Vendidos */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Mais Vendidos da Província</h2>
                <button
                  type="button"
                  onClick={() => {
                    setFilters({ ...filters, sort: "vendas" });
                    handlePerformSearch("");
                  }}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Mais procurados</span>
                  <ChevronRight size={14} />
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {bestSellers.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isFavorite={favorites.includes(product.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onOpenProduct={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            </div>

            {/* 7. Ofertas Especiais */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg flex items-center gap-2">
                  <span>Ofertas Especiais com Desconto</span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-red-600 text-white">
                    PROMO
                  </span>
                </h2>
                <button
                  type="button"
                  onClick={() => handlePerformSearch("oferta")}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Ver todas</span>
                  <ChevronRight size={14} />
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {specialOffers.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isFavorite={favorites.includes(product.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onOpenProduct={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            </div>

            {/* 8. Produtos Recentes */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Chegados Recentemente</h2>
                <button
                  type="button"
                  onClick={() => handlePerformSearch("")}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Ver novidades</span>
                  <ChevronRight size={14} />
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {recentProducts.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isFavorite={favorites.includes(product.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onOpenProduct={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            </div>

            {/* 9. Lojas Recomendadas */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Lojas de Confiança em Uíge</h2>
                <button
                  type="button"
                  onClick={() => setView("stores")}
                  className="text-xs font-bold text-[#246BFD] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Todas as lojas ({stores.length})</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {stores.slice(0, 4).map((store) => (
                  <div
                    key={store.id}
                    onClick={() => {
                      setSelectedStore(store);
                      setView("store");
                    }}
                    className="p-4 rounded-3xl border flex items-center gap-3.5 transition-all duration-200 hover:shadow-lg hover:border-[#246BFD] cursor-pointer"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <img
                      src={store.logo}
                      alt={store.name}
                      className="w-14 h-14 rounded-2xl object-cover shrink-0 shadow-sm"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-black text-sm truncate flex items-center gap-1.5">
                        <span className="truncate">{store.name}</span>
                        {store.isVip && <Crown size={13} className="text-amber-400 fill-amber-400 shrink-0" />}
                      </div>
                      <div className="text-xs flex items-center gap-1 mt-0.5" style={{ color: "var(--text-secondary)" }}>
                        <Star size={11} className="text-amber-400 fill-amber-400" />
                        <span className="font-bold">{Number(store.rating || 4.8).toFixed(1)}</span>
                        <span>•</span>
                        <span>{store.municipality}</span>
                      </div>
                      <p className="text-[11px] opacity-70 truncate mt-1" style={{ color: "var(--text-secondary)" }}>
                        {store.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 10. Serviços Locais */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Serviços Locais Especializados</h2>
                <span className="text-xs opacity-60 font-medium">Uíge e Negage</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {LOCAL_SERVICES.map((srv) => {
                  const Icon = CAT_ICON_MAP[srv.icon] || Wrench;
                  return (
                    <div
                      key={srv.id}
                      className="p-4 rounded-3xl border flex flex-col justify-between shadow-sm transition-all hover:border-[#246BFD]"
                      style={{
                        backgroundColor: "var(--surface)",
                        borderColor: "var(--border)",
                      }}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <div
                            className="w-10 h-10 rounded-2xl grid place-items-center"
                            style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
                          >
                            <Icon size={20} />
                          </div>
                          <span
                            className="text-[10px] font-bold px-2.5 py-0.5 rounded-full"
                            style={{ backgroundColor: "var(--surface-secondary)", color: "var(--accent)" }}
                          >
                            {srv.badge}
                          </span>
                        </div>
                        <h3 className="font-black text-sm mt-3">{srv.title}</h3>
                        <p className="text-xs opacity-70 mt-1 leading-snug" style={{ color: "var(--text-secondary)" }}>
                          {srv.subtitle}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          showToast(`A contactar ${srv.title} (${srv.phone})...`);
                        }}
                        className="mt-4 w-full py-2 rounded-xl text-xs font-bold border hover:border-[#246BFD] transition-colors cursor-pointer"
                        style={{ borderColor: "var(--border)" }}
                      >
                        Solicitar Serviço
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 11. Produtos Patrocinados */}
            {sponsoredProducts.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-black text-base sm:text-lg flex items-center gap-2">
                    <span>Produtos Patrocinados</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/15 text-[#246BFD]">
                      DESTAQUE
                    </span>
                  </h2>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                  {sponsoredProducts.slice(0, 4).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isFavorite={favorites.includes(product.id)}
                      onToggleFavorite={handleToggleFavorite}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                      onOpenProduct={(p) => setSelectedProduct(p)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 12. Recomendações Personalizadas */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-black text-base sm:text-lg">Recomendações para Si</h2>
                <span className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>
                  Baseado nas suas preferências
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {recommendedForYou.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isFavorite={favorites.includes(product.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                    onOpenProduct={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: CATEGORIES */}
        {/* ============================================================ */}
        {view === "categories" && (
          <div className="space-y-4 anim-fadeUp">
            <div className="flex items-center justify-between">
              <h1 className="text-xl sm:text-2xl font-black">Todas as Categorias</h1>
              <span className="text-xs opacity-60">{categories.length} categorias disponíveis</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {categories.map((c) => {
                const Icon = CAT_ICON_MAP[c.icon] || Tag;
                const catProductsCount = products.filter(
                  (p) => normalize(p.categoryName) === normalize(c.name)
                ).length;

                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      setFilters({ ...filters, category: c.name });
                      handlePerformSearch("", "plataforma");
                    }}
                    className="p-5 rounded-3xl border transition-all duration-200 hover:shadow-xl hover:border-[#246BFD] cursor-pointer flex flex-col justify-between"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div>
                      <div
                        className="w-12 h-12 rounded-2xl grid place-items-center mb-3 shadow-sm"
                        style={{ backgroundColor: `${c.color}20`, color: c.color }}
                      >
                        <Icon size={24} />
                      </div>
                      <h3 className="font-black text-base leading-tight">{c.name}</h3>
                      <p className="text-xs opacity-60 mt-1" style={{ color: "var(--text-secondary)" }}>
                        {catProductsCount} produtos no Uíge
                      </p>
                    </div>

                    <button
                      type="button"
                      className="mt-4 flex items-center justify-between text-xs font-bold pt-2 border-t"
                      style={{ borderColor: "var(--border)", color: "#246BFD" }}
                    >
                      <span>Explorar</span>
                      <ArrowRight size={13} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: STORES LIST */}
        {/* ============================================================ */}
        {view === "stores" && (
          <div className="space-y-4 anim-fadeUp">
            <div className="flex items-center justify-between">
              <h1 className="text-xl sm:text-2xl font-black">Lojas Comerciais no Uíge</h1>
              <button
                type="button"
                onClick={() => setView("seller")}
                className="text-xs font-bold text-white px-3.5 py-2 rounded-full cursor-pointer shadow-sm"
                style={{ backgroundColor: "var(--primary)" }}
              >
                Abrir Minha Loja
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {stores.map((store) => (
                <div
                  key={store.id}
                  onClick={() => {
                    setSelectedStore(store);
                    setView("store");
                  }}
                  className="rounded-3xl border overflow-hidden transition-all duration-200 hover:shadow-xl hover:border-[#246BFD] cursor-pointer flex flex-col justify-between"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <div className="relative h-36 w-full overflow-hidden">
                    <img
                      src={store.cover || store.logo}
                      alt={store.name}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-3 left-3 flex items-center gap-2.5">
                      <img
                        src={store.logo}
                        alt={store.name}
                        className="w-12 h-12 rounded-2xl object-cover border-2 border-white/80 shadow-md"
                      />
                      <div className="text-white">
                        <h3 className="font-black text-sm truncate flex items-center gap-1">
                          {store.name}
                          {store.isVip && <Crown size={12} className="text-amber-400 fill-amber-400 shrink-0" />}
                        </h3>
                        <div className="text-[11px] opacity-80">{store.category}</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <p className="text-xs opacity-75 line-clamp-2 leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                      {store.description}
                    </p>

                    <div className="mt-4 pt-3 border-t flex items-center justify-between text-xs" style={{ borderColor: "var(--border)" }}>
                      <span className="flex items-center gap-1 text-amber-400 font-bold">
                        <Star size={12} className="fill-current" />
                        <span>{Number(store.rating || 4.8).toFixed(1)}</span>
                      </span>
                      <span className="flex items-center gap-1 opacity-70" style={{ color: "var(--text-secondary)" }}>
                        <MapPin size={12} />
                        <span>{store.municipality}, Uíge</span>
                      </span>
                      <span className="font-bold text-[#246BFD]">Visitar Loja →</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: SINGLE STORE PROFILE */}
        {/* ============================================================ */}
        {view === "store" && selectedStore && (
          <div className="space-y-4 anim-fadeUp">
            <button
              type="button"
              onClick={() => setView("stores")}
              className="flex items-center gap-1 text-xs font-bold text-[#246BFD] cursor-pointer"
            >
              <ChevronLeft size={16} /> Voltar às Lojas
            </button>

            {/* Store Banner */}
            <div
              className="p-5 sm:p-6 rounded-3xl border flex flex-col sm:flex-row gap-4 items-center shadow-lg"
              style={{
                backgroundColor: "var(--surface)",
                borderColor: "var(--border)",
              }}
            >
              <img
                src={selectedStore.logo}
                alt={selectedStore.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover shadow-md shrink-0"
              />
              <div className="flex-1 text-center sm:text-left">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <h1 className="text-xl sm:text-2xl font-black">{selectedStore.name}</h1>
                  {selectedStore.isVip && (
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 flex items-center gap-1">
                      <Crown size={12} className="fill-current" /> Loja VIP
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm opacity-80 mt-1 max-w-xl" style={{ color: "var(--text-secondary)" }}>
                  {selectedStore.description}
                </p>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-2.5 text-xs font-semibold" style={{ color: "var(--text-secondary)" }}>
                  <span className="flex items-center gap-1 text-amber-400">
                    <Star size={13} className="fill-current" /> {Number(selectedStore.rating || 4.8).toFixed(1)}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin size={13} /> {selectedStore.municipality}, Uíge
                  </span>
                  <span>•</span>
                  <span>Categoria: {selectedStore.category}</span>
                </div>
              </div>
            </div>

            {/* Store Products */}
            <div>
              <h2 className="font-black text-base sm:text-lg mb-3">Produtos desta Loja</h2>
              {products.filter((p) => p.storeId === selectedStore.id).length === 0 ? (
                <div
                  className="p-12 text-center rounded-3xl border"
                  style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
                >
                  <Package size={36} className="mx-auto opacity-40 mb-2" />
                  <p className="text-sm font-bold">Esta loja ainda não tem produtos activos no catálogo.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                  {products
                    .filter((p) => p.storeId === selectedStore.id)
                    .map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        isFavorite={favorites.includes(product.id)}
                        onToggleFavorite={handleToggleFavorite}
                        onAddToCart={(p) => handleAddToCart(p, 1)}
                        onOpenProduct={(p) => setSelectedProduct(p)}
                      />
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: SEARCH & EXTERNAL (Requirements 9 & 10) */}
        {/* ============================================================ */}
        {view === "search" && (
          <div className="space-y-4 anim-fadeUp">
            {/* Search Source Tabs (Requirement 10) */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {[
                { id: "plataforma", label: "Mercado Uíge", icon: StoreIcon },
                { id: "internet", label: "Internet Geral", icon: Globe },
                { id: "google", label: "Google", icon: SearchIcon },
                { id: "youtube", label: "YouTube", icon: Play },
                { id: "facebook", label: "Facebook", icon: Share2 },
                { id: "instagram", label: "Instagram", icon: Camera },
              ].map((src) => {
                const Icon = src.icon;
                return (
                  <button
                    key={src.id}
                    type="button"
                    onClick={() => {
                      setSearchSource(src.id);
                      handlePerformSearch(searchQuery, src.id);
                    }}
                    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                      searchSource === src.id
                        ? "bg-[#246BFD] text-white shadow-sm"
                        : "border hover:border-[#246BFD]"
                    }`}
                    style={
                      searchSource !== src.id
                        ? {
                            backgroundColor: "var(--surface)",
                            borderColor: "var(--border)",
                            color: "var(--text-secondary)",
                          }
                        : {}
                    }
                  >
                    <Icon size={14} />
                    <span>{src.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Filter Panel (if toggled) */}
            {showFilters && searchSource === "plataforma" && (
              <div
                className="p-4 sm:p-5 rounded-3xl border shadow-lg grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                }}
              >
                <div>
                  <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Ordenar por
                  </label>
                  <select
                    value={filters.sort}
                    onChange={(e) => setFilters({ ...filters, sort: e.target.value })}
                    className="w-full p-2 rounded-xl border bg-transparent font-medium outline-none"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <option value="relevancia">Mais Relevantes</option>
                    <option value="preco-asc">Preço: Mais Baixo</option>
                    <option value="preco-desc">Preço: Mais Alto</option>
                    <option value="vendas">Mais Vendidos</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Preço Máximo (Kz)
                  </label>
                  <input
                    type="number"
                    value={filters.maxPrice}
                    onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                    placeholder="Ex: 50000"
                    className="w-full p-2 rounded-xl border bg-transparent font-medium outline-none"
                    style={{ borderColor: "var(--border)" }}
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Município
                  </label>
                  <select
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                    className="w-full p-2 rounded-xl border bg-transparent font-medium outline-none"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <option value="todas">Todos os Municípios</option>
                    {UIGE_MUNICIPALITIES.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                    Categoria
                  </label>
                  <select
                    value={filters.category}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                    className="w-full p-2 rounded-xl border bg-transparent font-medium outline-none"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <option value="todas">Todas as Categorias</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 font-bold cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={filters.available}
                      onChange={(e) => setFilters({ ...filters, available: e.target.checked })}
                      className="rounded"
                    />
                    <span>Só com Stock</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => handlePerformSearch(searchQuery)}
                    className="w-full py-2 rounded-xl font-bold text-white shadow-sm cursor-pointer"
                    style={{ backgroundColor: "var(--primary)" }}
                  >
                    Filtrar
                  </button>
                </div>
              </div>
            )}

            {/* Search History Pills */}
            {searchHistory.length > 0 && searchSource === "plataforma" && (
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <span className="font-bold flex items-center gap-1 opacity-60">
                  <Clock size={12} /> Histórico:
                </span>
                {searchHistory.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => handlePerformSearch(item)}
                    className="px-2.5 py-1 rounded-full border text-[11px] font-medium hover:border-[#246BFD] transition-colors cursor-pointer"
                    style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
                  >
                    {item}
                  </button>
                ))}
              </div>
            )}

            {/* Suggestions */}
            {searchSuggestions.length > 0 && (
              <div className="text-xs" style={{ color: "var(--text-secondary)" }}>
                <b>Sugestões: </b>
                {searchSuggestions.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handlePerformSearch(s)}
                    className="underline mr-2 cursor-pointer hover:text-[#246BFD]"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {/* EXTERNAL SEARCH DISPLAY (Requirement 10) */}
            {searchSource !== "plataforma" && externalSearchResponse && (
              <div
                className="p-6 rounded-3xl border shadow-lg space-y-4"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-2xl grid place-items-center shrink-0"
                    style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
                  >
                    <Globe size={22} />
                  </div>
                  <div>
                    <h2 className="font-black text-base">
                      Pesquisa Externa — {externalSearchResponse.source.toUpperCase()}
                    </h2>
                    <p className="text-xs mt-1 leading-relaxed opacity-80" style={{ color: "var(--text-secondary)" }}>
                      {externalSearchResponse.message}
                    </p>
                    <a
                      href={externalSearchResponse.officialLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 mt-4 px-5 py-2.5 rounded-2xl font-black text-xs text-white shadow-md cursor-pointer hover:opacity-95"
                      style={{ backgroundColor: "var(--primary)" }}
                    >
                      <span>Abrir pesquisa oficial no {externalSearchResponse.source}</span>
                      <ArrowRight size={14} />
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* INTERNAL SEARCH RESULTS */}
            {searchSource === "plataforma" && (
              <div>
                <div className="flex items-center justify-between mb-3 text-xs">
                  <span className="font-bold">
                    {searchResults.length} resultado(s) encontrado(s){" "}
                    {searchQuery ? `para "${searchQuery}"` : "no catálogo"}
                  </span>
                </div>

                {searchResults.length === 0 ? (
                  <div
                    className="p-12 text-center rounded-3xl border space-y-3"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <SearchX size={44} className="mx-auto opacity-40 text-[#246BFD]" />
                    <h3 className="font-black text-base">Sem resultados para a sua pesquisa</h3>
                    <p className="text-xs opacity-70 max-w-sm mx-auto leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                      Experimente usar palavras mais simples ou navegue pelas sugestões populares da nossa província abaixo:
                    </p>
                    <div className="flex flex-wrap justify-center gap-2 pt-2">
                      {[
                        "telemóvel",
                        "iphone barato",
                        "computador para jogos",
                        "sapatos no Uíge",
                        "café de Uíge",
                        "alimentos frescos",
                      ].map((term) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => handlePerformSearch(term)}
                          className="px-3 py-1.5 rounded-full text-xs font-bold border hover:border-[#246BFD] transition-colors cursor-pointer"
                          style={{
                            borderColor: "var(--border)",
                            backgroundColor: "var(--surface-secondary)",
                          }}
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                    {searchResults.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        isFavorite={favorites.includes(product.id)}
                        onToggleFavorite={handleToggleFavorite}
                        onAddToCart={(p) => handleAddToCart(p, 1)}
                        onOpenProduct={(p) => setSelectedProduct(p)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: CART (Requirement 6 & Cart) */}
        {/* ============================================================ */}
        {view === "cart" && (
          <div className="max-w-3xl mx-auto space-y-4 anim-fadeUp">
            <h1 className="text-xl sm:text-2xl font-black">
              Carrinho de Compras ({cartCount} artigos)
            </h1>

            {detailedCart.length === 0 ? (
              <div
                className="p-12 text-center rounded-3xl border space-y-3"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                }}
              >
                <ShoppingCart size={44} className="mx-auto opacity-35" />
                <h3 className="font-black text-base">O seu carrinho está vazio</h3>
                <p className="text-xs opacity-70" style={{ color: "var(--text-secondary)" }}>
                  Adicione artigos do mercado digital de Uíge para começar as suas compras.
                </p>
                <button
                  type="button"
                  onClick={() => setView("home")}
                  className="px-6 py-3 rounded-2xl font-black text-xs text-white shadow-md cursor-pointer"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Explorar Produtos
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {/* Items List */}
                <div className="md:col-span-2 space-y-3">
                  {detailedCart.map((item) => (
                    <div
                      key={item.productId}
                      className="p-3.5 rounded-2xl border flex gap-3 items-center shadow-sm"
                      style={{
                        backgroundColor: "var(--surface)",
                        borderColor: "var(--border)",
                      }}
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-20 h-20 rounded-xl object-cover shrink-0 cursor-pointer"
                        onClick={() => setSelectedProduct(item.product)}
                      />

                      <div className="flex-1 min-w-0">
                        <h4
                          onClick={() => setSelectedProduct(item.product)}
                          className="font-bold text-xs sm:text-sm truncate cursor-pointer hover:text-[#246BFD]"
                        >
                          {item.product.name}
                        </h4>
                        {item.selectedVariant && (
                          <span className="text-[11px] opacity-60 block mt-0.5">
                            Variante: {item.selectedVariant}
                          </span>
                        )}
                        <div className="font-black text-sm mt-1" style={{ color: "var(--accent)" }}>
                          {fmtKz(item.product.price)}
                        </div>

                        {/* Quantity Stepper & Remove */}
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center border rounded-xl overflow-hidden" style={{ borderColor: "var(--border)" }}>
                            <button
                              type="button"
                              onClick={() => handleUpdateCartQty(item.productId, -1)}
                              className="w-7 h-7 grid place-items-center hover:bg-slate-500/10 cursor-pointer"
                            >
                              <Minus size={13} />
                            </button>
                            <span className="w-8 text-center text-xs font-black">{item.qty}</span>
                            <button
                              type="button"
                              onClick={() => handleUpdateCartQty(item.productId, 1)}
                              className="w-7 h-7 grid place-items-center hover:bg-slate-500/10 cursor-pointer"
                            >
                              <Plus size={13} />
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleRemoveFromCart(item.productId)}
                            className="text-red-500 p-1 hover:bg-red-500/10 rounded-lg cursor-pointer"
                            title="Remover"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary & Checkout */}
                <div
                  className="p-5 rounded-3xl border shadow-lg space-y-4 h-fit"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Resumo do Pedido
                  </h3>

                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>Subtotal ({cartCount} un.)</span>
                      <span className="font-bold">{fmtKz(cartSubtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>Taxa de Entrega (Uíge)</span>
                      <span className="font-bold">{fmtKz(checkoutDelivery)}</span>
                    </div>
                    <div
                      className="pt-2 border-t flex justify-between font-black text-base"
                      style={{ borderColor: "var(--border)" }}
                    >
                      <span>Total Geral</span>
                      <span style={{ color: "var(--accent)" }}>{fmtKz(cartTotal)}</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-2 text-xs">
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Endereço de Entrega no Uíge *
                      </label>
                      <input
                        type="text"
                        required
                        value={checkoutAddress}
                        onChange={(e) => setCheckoutAddress(e.target.value)}
                        placeholder="Ex: Candombe Velho, Rua do Comércio, nº 42"
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>

                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Forma de Pagamento
                      </label>
                      <select
                        value={checkoutPayment}
                        onChange={(e) => setCheckoutPayment(e.target.value)}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        <option value="Multicaixa Express">Multicaixa Express (Recomendado)</option>
                        <option value="Transferência Bancária">Transferência Bancária</option>
                        <option value="Pagamento no Levantamento">Pagamento no Levantamento / Entrega</option>
                      </select>
                    </div>

                    <button
                      type="button"
                      onClick={handleConfirmOrder}
                      className="w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm text-white shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
                      style={{ backgroundColor: "var(--primary)" }}
                    >
                      <PackageCheck size={18} />
                      <span>Confirmar Encomenda</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: ORDERS */}
        {/* ============================================================ */}
        {view === "orders" && (
          <div className="max-w-3xl mx-auto space-y-4 anim-fadeUp">
            <h1 className="text-xl sm:text-2xl font-black">Histórico de Encomendas</h1>

            {!user ? (
              <div
                className="p-8 text-center rounded-3xl border space-y-3"
                style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
              >
                <Package size={40} className="mx-auto opacity-35" />
                <h3 className="font-bold text-sm">Inicie sessão para consultar as suas encomendas</h3>
                <button
                  type="button"
                  onClick={() => {
                    setAuthModalMode("login");
                    setAuthModalOpen(true);
                  }}
                  className="px-5 py-2.5 rounded-2xl font-bold text-xs text-white"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Entrar na Conta
                </button>
              </div>
            ) : orders.length === 0 ? (
              <div
                className="p-12 text-center rounded-3xl border space-y-2"
                style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
              >
                <Package size={44} className="mx-auto opacity-35" />
                <h3 className="font-bold text-base">Ainda não realizou encomendas</h3>
                <p className="text-xs opacity-70" style={{ color: "var(--text-secondary)" }}>
                  As suas compras no Mercado Uíge surgirão aqui com o respectivo código de rastreio.
                </p>
                <button
                  type="button"
                  onClick={() => setView("home")}
                  className="mt-3 px-5 py-2.5 rounded-2xl font-bold text-xs text-white"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Fazer Compras
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {orders.map((ord) => (
                  <div
                    key={ord.id}
                    className="p-4 sm:p-5 rounded-3xl border shadow-sm space-y-3"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                      <div>
                        <span className="font-black text-sm">Código: #{ord.code}</span>
                        <span className="text-[11px] opacity-60 block mt-0.5">
                          {new Date(ord.createdAt).toLocaleDateString("pt-AO", {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      <span
                        className="px-3 py-1 rounded-full text-xs font-black shadow-sm"
                        style={{
                          backgroundColor:
                            ord.status === "Entregue"
                              ? "var(--accent)"
                              : ord.status === "Cancelada"
                              ? "var(--danger)"
                              : "#246BFD",
                          color: ord.status === "Entregue" ? "var(--accent-text)" : "#FFFFFF",
                        }}
                      >
                        {ord.status}
                      </span>
                    </div>

                    {/* Order items */}
                    <div className="space-y-2 text-xs">
                      {ord.items.map((item) => (
                        <div key={item.id} className="flex items-center justify-between">
                          <span className="truncate pr-2">
                            {item.qty}x {item.productName}{" "}
                            {item.selectedVariant ? `(${item.selectedVariant})` : ""}
                          </span>
                          <span className="font-bold shrink-0">{fmtKz(item.price * item.qty)}</span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t flex items-center justify-between text-xs" style={{ borderColor: "var(--border)" }}>
                      <span style={{ color: "var(--text-secondary)" }}>
                        Endereço: <b>{ord.address}</b> ({ord.paymentMethod})
                      </span>
                      <span className="font-black text-sm" style={{ color: "var(--accent)" }}>
                        Total: {fmtKz(ord.total)}
                      </span>
                    </div>

                    {/* Quick status stepper simulation */}
                    <div className="pt-2 flex flex-wrap gap-1.5 items-center">
                      <span className="text-[10px] font-bold opacity-60">Simular estado:</span>
                      {ORDER_STATUSES.map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => handleUpdateOrderStatus(ord.id, st)}
                          className={`text-[10px] px-2.5 py-1 rounded-full font-bold border transition-colors cursor-pointer ${
                            ord.status === st
                              ? "bg-[#246BFD] text-white border-[#246BFD]"
                              : "border-[var(--border)] hover:border-[#246BFD]"
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: FAVORITES */}
        {/* ============================================================ */}
        {view === "favorites" && (
          <div className="space-y-4 anim-fadeUp">
            <h1 className="text-xl sm:text-2xl font-black">
              Os Meus Favoritos ({favorites.length})
            </h1>

            {favorites.length === 0 ? (
              <div
                className="p-12 text-center rounded-3xl border space-y-3"
                style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
              >
                <Heart size={44} className="mx-auto opacity-35 text-red-500" />
                <h3 className="font-bold text-base">Ainda não adicionou favoritos</h3>
                <p className="text-xs opacity-70" style={{ color: "var(--text-secondary)" }}>
                  Clique no ícone de coração em qualquer artigo para guardá-lo aqui.
                </p>
                <button
                  type="button"
                  onClick={() => setView("home")}
                  className="px-5 py-2.5 rounded-2xl font-bold text-xs text-white"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Explorar Catálogo
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {products
                  .filter((p) => favorites.includes(p.id))
                  .map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isFavorite={true}
                      onToggleFavorite={handleToggleFavorite}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                      onOpenProduct={(p) => setSelectedProduct(p)}
                    />
                  ))}
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: PROFILE & ACCOUNT (Requirement 12) */}
        {/* ============================================================ */}
        {view === "profile" && (
          <div className="max-w-2xl mx-auto space-y-4 anim-fadeUp">
            <h1 className="text-xl sm:text-2xl font-black">Minha Conta</h1>

            {!user ? (
              <div
                className="p-8 text-center rounded-3xl border space-y-4"
                style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
              >
                <Users size={44} className="mx-auto opacity-35 text-[#246BFD]" />
                <h3 className="font-black text-base">Aceda à sua conta Mercado Uíge</h3>
                <p className="text-xs opacity-70 max-w-sm mx-auto" style={{ color: "var(--text-secondary)" }}>
                  Inicie sessão para gerir os seus dados, consultar encomendas, aceder à carteira ou gerir as suas vendas.
                </p>
                <div className="flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthModalMode("login");
                      setAuthModalOpen(true);
                    }}
                    className="px-6 py-2.5 rounded-2xl font-black text-xs text-white shadow-md cursor-pointer"
                    style={{ backgroundColor: "var(--primary)" }}
                  >
                    Entrar
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthModalMode("register");
                      setAuthModalOpen(true);
                    }}
                    className="px-6 py-2.5 rounded-2xl font-bold text-xs border hover:border-[#246BFD] cursor-pointer"
                    style={{ borderColor: "var(--border)" }}
                  >
                    Criar Conta
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* User card header */}
                <div
                  className="p-6 rounded-3xl border shadow-lg flex items-center gap-4"
                  style={{
                    background: "linear-gradient(135deg, #246BFD, #07111F)",
                    color: "#FFFFFF",
                  }}
                >
                  <div className="w-16 h-16 rounded-3xl bg-white/15 grid place-items-center text-2xl font-black shadow-inner">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h2 className="font-black text-lg truncate flex items-center gap-1.5">
                      <span>{user.name}</span>
                      <BadgeCheck size={16} className="text-[#B7F34A]" />
                    </h2>
                    <p className="text-xs opacity-80">{user.email}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] font-bold">
                      <span className="px-2.5 py-0.5 rounded-full bg-white/20 capitalize">
                        {user.role}
                      </span>
                      <span>• {user.municipality || "Uíge"}, Angola</span>
                    </div>
                  </div>
                </div>

                {/* Wallet Balance Widget */}
                <div
                  className="p-4 sm:p-5 rounded-3xl border flex items-center justify-between shadow-md"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl grid place-items-center bg-amber-500/20 text-amber-400">
                      <Wallet size={20} />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold opacity-60 block" style={{ color: "var(--text-secondary)" }}>
                        Saldo da Carteira Digital
                      </span>
                      <span className="font-black text-lg sm:text-xl" style={{ color: "var(--accent)" }}>
                        {fmtKz(user.walletBalance || 12500)}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setWalletModalOpen(true)}
                    className="px-4 py-2 rounded-2xl font-black text-xs text-slate-950 shadow-md cursor-pointer hover:opacity-90"
                    style={{ backgroundColor: "var(--accent)" }}
                  >
                    Recarregar
                  </button>
                </div>

                {/* Edit profile form */}
                <form
                  onSubmit={handleUpdateProfile}
                  className="p-5 rounded-3xl border space-y-3 shadow-sm"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Actualizar Dados Pessoais
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Nome Completo
                      </label>
                      <input
                        type="text"
                        value={profileForm.name}
                        onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>

                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Telefone
                      </label>
                      <input
                        type="tel"
                        value={profileForm.phone}
                        onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>

                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Município
                      </label>
                      <select
                        value={profileForm.municipality}
                        onChange={(e) => setProfileForm({ ...profileForm, municipality: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        {UIGE_MUNICIPALITIES.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Bairro
                      </label>
                      <input
                        type="text"
                        value={profileForm.bairro}
                        onChange={(e) => setProfileForm({ ...profileForm, bairro: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-2xl font-bold text-xs text-white shadow-sm cursor-pointer"
                    style={{ backgroundColor: "var(--primary)" }}
                  >
                    Guardar Alterações
                  </button>
                </form>

                {/* Account Navigation / Panels */}
                <div
                  className="p-5 rounded-3xl border space-y-2 shadow-sm text-xs font-bold"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Painéis e Acessos
                  </h3>

                  <button
                    type="button"
                    onClick={() => setView("seller")}
                    className="w-full flex items-center justify-between p-3 rounded-2xl border hover:border-[#246BFD] transition-colors cursor-pointer text-left"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <span className="flex items-center gap-2">
                      <StoreIcon size={16} className="text-[#246BFD]" />
                      Painel do Comerciante (Vendas & Artigos)
                    </span>
                    <ChevronRight size={16} />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      loadAdminDashboard();
                      setView("admin");
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl border hover:border-[#246BFD] transition-colors cursor-pointer text-left"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck size={16} className="text-emerald-500" />
                      Painel Administrativo da Plataforma
                    </span>
                    <ChevronRight size={16} />
                  </button>

                  <button
                    type="button"
                    onClick={handleLogout}
                    className="w-full flex items-center justify-between p-3 rounded-2xl border text-amber-500 hover:border-amber-500 transition-colors cursor-pointer text-left"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <span className="flex items-center gap-2">
                      <LogOut size={16} />
                      Terminar Sessão
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDeleteAccount}
                    className="w-full flex items-center justify-between p-3 rounded-2xl border text-red-500 hover:border-red-500 transition-colors cursor-pointer text-left"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <span className="flex items-center gap-2">
                      <Trash2 size={16} />
                      Eliminar Conta Definitivamente
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: SELLER DASHBOARD (Requirement 13) */}
        {/* ============================================================ */}
        {view === "seller" && (
          <div className="space-y-5 anim-fadeUp">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h1 className="text-xl sm:text-2xl font-black">Painel do Comerciante</h1>
                <p className="text-xs opacity-70" style={{ color: "var(--text-secondary)" }}>
                  Gira os seus produtos, acompanhe vendas e crie a sua loja no Mercado Uíge.
                </p>
              </div>

              {!user && (
                <button
                  type="button"
                  onClick={() => {
                    setAuthModalMode("login");
                    setAuthModalOpen(true);
                  }}
                  className="px-4 py-2 rounded-2xl font-bold text-xs text-white"
                  style={{ backgroundColor: "var(--primary)" }}
                >
                  Entrar como Vendedor
                </button>
              )}
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "Total de Produtos", value: mySellerProducts.length, icon: Package },
                {
                  label: "Disponíveis com Stock",
                  value: mySellerProducts.filter((p) => p.stock > 0).length,
                  icon: CheckCircle2,
                },
                {
                  label: "Esgotados",
                  value: mySellerProducts.filter((p) => p.stock <= 0).length,
                  icon: AlertCircle,
                },
                {
                  label: "Receita de Vendas",
                  value: fmtKz(sellerRevenue),
                  icon: DollarSign,
                },
              ].map((m, i) => {
                const Icon = m.icon;
                return (
                  <div
                    key={i}
                    className="p-4 rounded-3xl border shadow-sm"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div
                      className="w-8 h-8 rounded-xl grid place-items-center mb-2"
                      style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
                    >
                      <Icon size={16} />
                    </div>
                    <div className="text-lg sm:text-xl font-black">{m.value}</div>
                    <div className="text-[11px] opacity-65" style={{ color: "var(--text-secondary)" }}>
                      {m.label}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 7-Day Sales Chart */}
            <div
              className="p-5 rounded-3xl border shadow-sm space-y-3"
              style={{
                backgroundColor: "var(--surface)",
                borderColor: "var(--border)",
              }}
            >
              <div className="flex items-center justify-between">
                <span className="font-black text-sm flex items-center gap-2">
                  <BarChart3 size={16} className="text-[#246BFD]" />
                  Actividade de Vendas nos últimos 7 dias (Uíge)
                </span>
                <span className="text-xs font-bold" style={{ color: "var(--accent)" }}>
                  +28% esta semana
                </span>
              </div>

              <div className="flex items-end gap-2.5 h-32 pt-4">
                {[45, 60, 50, 75, 65, 95, 80].map((val, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                    <div
                      className="w-full rounded-t-xl transition-all duration-300"
                      style={{
                        height: `${val}%`,
                        backgroundColor: idx === 5 ? "var(--accent)" : "var(--primary)",
                      }}
                    />
                    <span className="text-[10px] opacity-60">
                      {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"][idx]}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Forms: Publish Product & Create Store */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Publish Product */}
              <form
                onSubmit={handlePublishProduct}
                className="p-5 rounded-3xl border shadow-sm space-y-3"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                }}
              >
                <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                  Publicar Novo Produto no Mercado
                </h3>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                      Nome do Produto *
                    </label>
                    <input
                      type="text"
                      required
                      value={sellerForm.name}
                      onChange={(e) => setSellerForm({ ...sellerForm, name: e.target.value })}
                      placeholder="Ex: Telemóvel Samsung A55 128GB"
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                      Descrição detalhada *
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={sellerForm.description}
                      onChange={(e) => setSellerForm({ ...sellerForm, description: e.target.value })}
                      placeholder="Indique os detalhes técnicos, estado de conservação e garantia..."
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Preço em Kz *
                      </label>
                      <input
                        type="number"
                        required
                        min="100"
                        value={sellerForm.price}
                        onChange={(e) => setSellerForm({ ...sellerForm, price: e.target.value })}
                        placeholder="Ex: 185000"
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Preço Anterior (Opcional)
                      </label>
                      <input
                        type="number"
                        value={sellerForm.oldPrice}
                        onChange={(e) => setSellerForm({ ...sellerForm, oldPrice: e.target.value })}
                        placeholder="Ex: 220000"
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Stock *
                      </label>
                      <input
                        type="number"
                        required
                        min="0"
                        value={sellerForm.stock}
                        onChange={(e) => setSellerForm({ ...sellerForm, stock: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                        style={{ borderColor: "var(--border)" }}
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Estado
                      </label>
                      <select
                        value={sellerForm.condition}
                        onChange={(e) => setSellerForm({ ...sellerForm, condition: e.target.value as any })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        <option value="novo">Novo</option>
                        <option value="usado">Usado</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Categoria
                      </label>
                      <select
                        value={sellerForm.categoryName}
                        onChange={(e) => setSellerForm({ ...sellerForm, categoryName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.name}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                      Fotografia do Produto (URL) *
                    </label>
                    <input
                      type="url"
                      required
                      value={sellerForm.image}
                      onChange={(e) => setSellerForm({ ...sellerForm, image: e.target.value })}
                      placeholder="https://exemplo.com/foto.jpg"
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />

                    {/* Quick photo presets */}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <span className="text-[10px] opacity-60">Usar imagem demo:</span>
                      {[
                        { label: "Telemóvel", url: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=800&q=80" },
                        { label: "Laptop", url: "https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=800&q=80" },
                        { label: "Café", url: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=800&q=80" },
                      ].map((item) => (
                        <button
                          key={item.label}
                          type="button"
                          onClick={() => setSellerForm({ ...sellerForm, image: item.url })}
                          className="text-[10px] px-2 py-0.5 rounded-full border hover:border-[#246BFD] cursor-pointer"
                          style={{ borderColor: "var(--border)" }}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-2xl font-black text-xs text-slate-950 shadow-md cursor-pointer transition-transform active:scale-95"
                    style={{ backgroundColor: "var(--accent)" }}
                  >
                    Publicar Anúncio
                  </button>
                </div>
              </form>

              {/* Create Store */}
              <form
                onSubmit={handleCreateStore}
                className="p-5 rounded-3xl border shadow-sm space-y-3 h-fit"
                style={{
                  backgroundColor: "var(--surface)",
                  borderColor: "var(--border)",
                }}
              >
                <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                  Criar ou Expandir Loja Comercial
                </h3>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                      Nome da Loja *
                    </label>
                    <input
                      type="text"
                      required
                      value={storeForm.name}
                      onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })}
                      placeholder="Ex: Eletrónica & Variedades Uíge"
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                      Descrição da Loja
                    </label>
                    <input
                      type="text"
                      value={storeForm.description}
                      onChange={(e) => setStoreForm({ ...storeForm, description: e.target.value })}
                      placeholder="A sua apresentação comercial para os clientes do Uíge..."
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Município
                      </label>
                      <select
                        value={storeForm.municipality}
                        onChange={(e) => setStoreForm({ ...storeForm, municipality: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        {UIGE_MUNICIPALITIES.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold mb-1" style={{ color: "var(--text-secondary)" }}>
                        Categoria da Loja
                      </label>
                      <select
                        value={storeForm.category}
                        onChange={(e) => setStoreForm({ ...storeForm, category: e.target.value })}
                        className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none"
                        style={{ borderColor: "var(--border)" }}
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.name}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-2xl font-black text-xs text-white shadow-md cursor-pointer"
                    style={{ backgroundColor: "var(--primary)" }}
                  >
                    Registar Nova Loja
                  </button>
                </div>
              </form>
            </div>

            {/* My Listed Products */}
            <div
              className="p-5 rounded-3xl border shadow-sm space-y-3"
              style={{
                backgroundColor: "var(--surface)",
                borderColor: "var(--border)",
              }}
            >
              <div className="flex items-center justify-between pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                <h3 className="font-black text-sm">Meus Artigos em Venda ({mySellerProducts.length})</h3>
                <span className="text-xs opacity-60">Gestão imediata de preços e stock</span>
              </div>

              {mySellerProducts.length === 0 ? (
                <div className="py-8 text-center text-xs opacity-60">
                  Ainda não publicou nenhum artigo com esta conta. Utilize o formulário acima para publicar o primeiro.
                </div>
              ) : (
                <div className="grid gap-2">
                  {mySellerProducts.map((p) => (
                    <div
                      key={p.id}
                      className="p-2.5 rounded-2xl border flex items-center justify-between gap-3 text-xs"
                      style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={p.image} alt={p.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                        <div className="min-w-0">
                          <h4 className="font-bold truncate">{p.name}</h4>
                          <span className="opacity-60 block">
                            {fmtKz(p.price)} • Stock actual: <b>{p.stock} un.</b>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            const newStockStr = prompt(`Actualizar stock para "${p.name}":`, String(p.stock));
                            if (newStockStr !== null) {
                              const ns = parseInt(newStockStr, 10);
                              if (!isNaN(ns) && ns >= 0) {
                                api.updateProductStock(p.id, ns);
                                setProducts(products.map((item) => (item.id === p.id ? { ...item, stock: ns } : item)));
                                showToast("Stock actualizado.");
                              }
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-xl border hover:border-[#246BFD] font-bold cursor-pointer"
                          style={{ borderColor: "var(--border)" }}
                        >
                          Stock
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Eliminar o produto "${p.name}"?`)) {
                              api.deleteProduct(p.id);
                              setProducts(products.filter((item) => item.id !== p.id));
                              showToast("Produto eliminado.");
                            }
                          }}
                          className="p-1.5 text-red-500 hover:bg-red-500/10 rounded-xl cursor-pointer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: ADMIN DASHBOARD (Requirement 14) */}
        {/* ============================================================ */}
        {view === "admin" && (
          <div className="space-y-5 anim-fadeUp">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl sm:text-2xl font-black flex items-center gap-2">
                  <ShieldCheck size={24} style={{ color: "var(--accent)" }} />
                  Painel Administrativo Mercado Uíge
                </h1>
                <p className="text-xs opacity-70" style={{ color: "var(--text-secondary)" }}>
                  Controlo de utilizadores, moderação de lojas, denúncias e difusão provincial.
                </p>
              </div>

              <button
                type="button"
                onClick={loadAdminDashboard}
                className="px-3.5 py-1.5 rounded-full border text-xs font-bold flex items-center gap-1.5 cursor-pointer hover:border-[#246BFD]"
                style={{ borderColor: "var(--border)" }}
              >
                <RefreshCw size={13} />
                <span>Actualizar</span>
              </button>
            </div>

            {/* Global Stats */}
            {adminData && (
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {[
                  { label: "Utilizadores", value: adminData.stats.users, icon: Users },
                  { label: "Lojas Registadas", value: adminData.stats.stores, icon: StoreIcon },
                  { label: "Produtos no Catálogo", value: adminData.stats.products, icon: Package },
                  { label: "Encomendas Feitas", value: adminData.stats.orders, icon: PackageCheck },
                  { label: "Volume de Vendas", value: fmtKz(adminData.stats.revenue), icon: DollarSign },
                ].map((s, idx) => {
                  const Icon = s.icon;
                  return (
                    <div
                      key={idx}
                      className="p-4 rounded-3xl border shadow-sm"
                      style={{
                        backgroundColor: "var(--surface)",
                        borderColor: "var(--border)",
                      }}
                    >
                      <div
                        className="w-8 h-8 rounded-xl grid place-items-center mb-2"
                        style={{ backgroundColor: "rgba(36, 107, 253, 0.15)", color: "#246BFD" }}
                      >
                        <Icon size={16} />
                      </div>
                      <div className="text-lg font-black truncate">{s.value}</div>
                      <div className="text-[10px] opacity-65 truncate" style={{ color: "var(--text-secondary)" }}>
                        {s.label}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Management grids */}
            {adminData && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Users Management */}
                <div
                  className="p-5 rounded-3xl border shadow-sm space-y-3"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Gestão de Utilizadores ({adminData.users.length})
                  </h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {adminData.users.map((u) => (
                      <div
                        key={u.id}
                        className="p-2.5 rounded-2xl border flex items-center justify-between text-xs"
                        style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
                      >
                        <div className="min-w-0 pr-2">
                          <span className="font-black truncate block">{u.name}</span>
                          <span className="text-[11px] opacity-60 block">
                            {u.email} • <span className="capitalize">{u.role}</span>
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleAdminSuspendUser(u.id, !!u.isSuspended)}
                          className={`px-3 py-1 rounded-full text-[11px] font-black cursor-pointer shadow-sm ${
                            u.isSuspended
                              ? "bg-emerald-500 text-white"
                              : "bg-red-500/15 text-red-400 border border-red-500/30"
                          }`}
                        >
                          {u.isSuspended ? "Reactivar" : "Suspender"}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stores VIP Management */}
                <div
                  className="p-5 rounded-3xl border shadow-sm space-y-3"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Gestão de Lojas & Selos VIP ({adminData.stores.length})
                  </h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {adminData.stores.map((s) => (
                      <div
                        key={s.id}
                        className="p-2.5 rounded-2xl border flex items-center justify-between text-xs"
                        style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
                      >
                        <div className="min-w-0 pr-2">
                          <span className="font-black truncate flex items-center gap-1">
                            {s.name}
                            {s.isVip && <Crown size={12} className="text-amber-400 fill-amber-400" />}
                          </span>
                          <span className="text-[11px] opacity-60 block">
                            {s.municipality} • Avaliação: {Number(s.rating || 4.8).toFixed(1)}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleAdminToggleVip(s.id, s.isVip)}
                          className={`px-3 py-1 rounded-full text-[11px] font-black cursor-pointer border ${
                            s.isVip
                              ? "bg-amber-400 text-slate-950 border-amber-400"
                              : "border-[var(--border)] hover:border-[#246BFD]"
                          }`}
                        >
                          {s.isVip ? "Remover VIP" : "Tornar VIP ⭐"}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Complaints & Reports */}
                <div
                  className="p-5 rounded-3xl border shadow-sm space-y-3"
                  style={{
                    backgroundColor: "var(--surface)",
                    borderColor: "var(--border)",
                  }}
                >
                  <h3 className="font-black text-sm pb-2 border-b" style={{ borderColor: "var(--border)" }}>
                    Denúncias de Anúncios ({adminData.reports.length})
                  </h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {adminData.reports.length === 0 ? (
                      <div className="py-6 text-center text-xs opacity-50">Sem denúncias pendentes.</div>
                    ) : (
                      adminData.reports.map((rep) => (
                        <div
                          key={rep.id}
                          className="p-2.5 rounded-2xl border flex items-center justify-between text-xs"
                          style={{ borderColor: "var(--border)", backgroundColor: "var(--surface-secondary)" }}
                        >
                          <div className="min-w-0 pr-2">
                            <span className="font-bold block truncate">{rep.productName || "Produto"}</span>
                            <span className="text-[11px] opacity-70 block">{rep.reason}</span>
                            <span className="text-[10px] opacity-50 block capitalize">Estado: {rep.status}</span>
                          </div>
                          {rep.status === "pendente" && (
                            <button
                              type="button"
                              onClick={() => handleAdminResolveReport(rep.id)}
                              className="px-3 py-1 rounded-full text-[11px] font-black bg-emerald-500 text-white cursor-pointer"
                            >
                              Resolver
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Broadcast and New Category */}
                <div className="space-y-4">
                  {/* Broadcast */}
                  <form
                    onSubmit={handleAdminBroadcast}
                    className="p-5 rounded-3xl border shadow-sm space-y-2 text-xs"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <h3 className="font-black text-sm pb-1 flex items-center gap-1.5">
                      <Megaphone size={16} className="text-[#246BFD]" />
                      Broadcast / Aviso Geral aos Utilizadores
                    </h3>
                    <input
                      type="text"
                      required
                      value={broadcastTitle}
                      onChange={(e) => setBroadcastTitle(e.target.value)}
                      placeholder="Título do aviso..."
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                    <input
                      type="text"
                      required
                      value={broadcastBody}
                      onChange={(e) => setBroadcastBody(e.target.value)}
                      placeholder="Mensagem para todos os utilizadores..."
                      className="w-full p-2.5 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl font-black text-white shadow-sm cursor-pointer"
                      style={{ backgroundColor: "var(--primary)" }}
                    >
                      Enviar Notificação Geral
                    </button>
                  </form>

                  {/* Add category */}
                  <form
                    onSubmit={handleAdminAddCategory}
                    className="p-4 rounded-3xl border shadow-sm flex gap-2 text-xs"
                    style={{
                      backgroundColor: "var(--surface)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <input
                      type="text"
                      required
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      placeholder="Nome de nova categoria..."
                      className="flex-1 p-2 rounded-xl border bg-transparent font-medium outline-none focus:border-[#246BFD]"
                      style={{ borderColor: "var(--border)" }}
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl font-black text-slate-950 cursor-pointer"
                      style={{ backgroundColor: "var(--accent)" }}
                    >
                      Adicionar
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW: NOTIFICATIONS */}
        {/* ============================================================ */}
        {view === "notifications" && (
          <div className="max-w-2xl mx-auto space-y-4 anim-fadeUp">
            <div className="flex items-center justify-between">
              <h1 className="text-xl sm:text-2xl font-black">Notificações</h1>
              <button
                type="button"
                onClick={async () => {
                  await api.markAllNotificationsRead();
                  setNotifications(notifications.map((n) => ({ ...n, isRead: true })));
                  showToast("Todas as notificações marcadas como lidas.");
                }}
                className="text-xs font-bold text-[#246BFD] hover:underline cursor-pointer"
              >
                Marcar todas como lidas
              </button>
            </div>

            {notifications.length === 0 ? (
              <div
                className="p-12 text-center rounded-3xl border space-y-2"
                style={{ backgroundColor: "var(--surface)", borderColor: "var(--border)" }}
              >
                <Bell size={40} className="mx-auto opacity-35" />
                <h3 className="font-bold text-sm">Sem notificações no momento</h3>
                <p className="text-xs opacity-65" style={{ color: "var(--text-secondary)" }}>
                  Será avisado sobre o estado das suas compras e novidades da província aqui.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className="p-4 rounded-3xl border transition-all duration-200"
                    style={{
                      backgroundColor: notif.isRead ? "var(--surface)" : "rgba(36, 107, 253, 0.12)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-black text-sm">{notif.title}</span>
                      <span className="text-[10px] opacity-60">
                        {new Date(notif.createdAt).toLocaleDateString("pt-AO")}
                      </span>
                    </div>
                    <p className="text-xs opacity-80 leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                      {notif.body}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer (Desktop only) */}
      <footer
        className="hidden md:block mt-12 border-t py-6 text-xs transition-colors"
        style={{
          borderColor: "var(--border)",
          color: "var(--text-secondary)",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-black" style={{ color: "var(--text-primary)" }}>
              Mercado Uíge
            </span>
            <span>• Comprar, Vender e Conectar na Província do Uíge, Angola.</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Preços em Kwanzas (Kz)</span>
            <span>• Modo: {themeMode === "dark" ? "Escuro" : themeMode === "light" ? "Claro" : "Automático"}</span>
            <span>• Uíge, Negage e Municípios</span>
          </div>
        </div>
      </footer>

      {/* 6. Bottom Navigation (Android Mobile) */}
      <BottomNav
        activeView={view}
        onSelectNav={(v) => {
          if (v === "admin") loadAdminDashboard();
          setView(v);
        }}
        cartCount={cartCount}
      />

      {/* MODALS */}
      <LocationModal
        isOpen={showLocationModal}
        onClose={() => setShowLocationModal(false)}
        currentLocation={location}
        onSelectLocation={(loc) => {
          setLocation(loc);
          saveStoredLocation(loc);
          showToast(`Localização definida para: ${loc}`);
        }}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
        onSuccess={(newUser) => {
          setUser(newUser);
          loadUserData();
        }}
        showToast={showToast}
      />

      <ProductDetailModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        isFavorite={selectedProduct ? favorites.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onAddToCart={handleAddToCart}
        similarProducts={
          selectedProduct
            ? products.filter(
                (p) =>
                  p.id !== selectedProduct.id &&
                  (p.categoryName === selectedProduct.categoryName ||
                    p.municipality === selectedProduct.municipality)
              )
            : []
        }
        onSelectProduct={(p) => setSelectedProduct(p)}
        onSendMessage={async (productId, msg) => {
          showToast("Mensagem enviada ao vendedor no Mercado Uíge!");
        }}
        onReportProduct={async (productId, reason) => {
          await api.reportProduct(productId, reason);
          showToast("Denúncia recebida. A administração irá analisar.");
        }}
      />

      <WalletModal
        isOpen={walletModalOpen}
        onClose={() => setWalletModalOpen(false)}
        currentBalance={user?.walletBalance || 12500}
        onRecharge={(amount) => {
          if (user) {
            const updated = {
              ...user,
              walletBalance: (user.walletBalance || 12500) + amount,
            };
            setUser(updated);
            saveCurrentUser(updated);
            const users = getStoredUsers().map((u) => (u.id === user.id ? updated : u));
            saveUsers(users);
            showToast(`Recarga de ${fmtKz(amount)} confirmada!`);
          }
        }}
      />

      {/* Global Toast Notification */}
      {toast && (
        <div
          className="fixed bottom-20 md:bottom-8 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm shadow-2xl anim-pop text-slate-950 flex items-center gap-2 border border-black/10"
          style={{ backgroundColor: "var(--accent)" }}
        >
          <CheckCircle2 size={16} />
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
}
