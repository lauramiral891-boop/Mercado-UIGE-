export const fmtKz = (n: number | string | undefined | null) => {
  const val = Number(n || 0);
  return `${val.toLocaleString("pt-AO", { maximumFractionDigits: 0 })} Kz`;
};

export const normalize = (s: string) =>
  (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

export const SYNONYMS: Record<string, string[]> = {
  telemovel: ["telemovel", "telemóvel", "telefone", "smartphone", "celular", "samsung", "iphone", "xiaomi", "galaxy"],
  telefone: ["telemovel", "telemóvel", "telefone", "smartphone", "celular"],
  smartphone: ["telemovel", "telemóvel", "smartphone", "telefone"],
  celular: ["telemovel", "telemóvel", "smartphone", "celular"],
  iphone: ["iphone", "apple", "ios", "telemovel"],
  samsung: ["samsung", "galaxy", "android", "telemovel"],
  xiaomi: ["xiaomi", "redmi", "telemovel"],
  computador: ["computador", "laptop", "pc", "notebook", "gaming", "portatil", "computador para jogos"],
  laptop: ["laptop", "computador", "notebook", "gaming", "portatil"],
  pc: ["pc", "computador", "computador para jogos", "desktop"],
  jogos: ["gaming", "jogos", "rtx", "gpu", "laptop", "computador", "teclado gaming"],
  gaming: ["gaming", "jogos", "rtx", "laptop", "computador", "computador para jogos"],
  tenis: ["tenis", "tênis", "sneakers", "nike", "adidas", "calcado", "calçado", "sapatos"],
  sapatos: ["sapatos", "tenis", "calcado", "calçado", "nike", "adidas"],
  calcado: ["calcado", "calçado", "sapatos", "tenis", "sneakers"],
  fone: ["fone", "fones", "auscultadores", "headphones", "auriculares", "sony", "jbl", "bluetooth"],
  auscultadores: ["auscultadores", "fone", "fones", "headphones", "auriculares"],
  headphones: ["headphones", "auscultadores", "fone"],
  roupa: ["roupa", "vestido", "moda", "camisa", "calca"],
  vestido: ["vestido", "moda", "roupa", "feminino"],
  comida: ["comida", "alimentos", "fruta", "verdura", "legumes", "fresco"],
  alimentos: ["alimentos", "comida", "fruta", "verdura", "tomate", "cesto"],
  beleza: ["beleza", "cosmetico", "creme", "serum", "sérum", "facial"],
  casa: ["casa", "sofa", "sofá", "mobilia", "mobília", "lar", "mesa"],
  barato: ["barato", "promocao", "promoção", "oferta", "desconto", "economico"],
  uige: ["uige", "uíge", "negage", "local"],
};

export function expandQuery(q: string): string[] {
  const n = normalize(q);
  const tokens = n.split(" ").filter(Boolean);
  const out = new Set<string>(tokens);
  
  for (const t of tokens) {
    (SYNONYMS[t] || []).forEach((s) => out.add(normalize(s)));
  }
  
  // Specific intent detection requested in prompt
  if (n.includes("para jogos") || n.includes("jogos") || n.includes("gaming")) {
    ["gaming", "laptop", "rtx", "computador"].forEach((s) => out.add(s));
  }
  if (n.includes("no uige") || n.includes("em uige") || n.includes("uige")) {
    ["uige", "uíge"].forEach((s) => out.add(s));
  }
  if (n.includes("barato") || n.includes("oferta") || n.includes("promocao")) {
    ["barato", "desconto"].forEach((s) => out.add(s));
  }
  
  return Array.from(out);
}

export function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 1; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return dp[m][n];
}

export function fuzzyScore(query: string, text: string): number {
  const q = normalize(query);
  const t = normalize(text);
  if (!q || !t) return 0;
  if (t === q) return 100;
  if (t.includes(q)) return 95;

  const expanded = expandQuery(q);
  let best = 0;

  for (const e of expanded) {
    if (t.includes(e)) {
      best = Math.max(best, 85);
    }
  }

  const qTokens = q.split(" ").filter(Boolean);
  const tTokens = t.split(" ").filter(Boolean);

  for (const qt of qTokens) {
    for (const tt of tTokens) {
      if (tt === qt) {
        best = Math.max(best, 90);
        continue;
      }
      if (tt.includes(qt) || qt.includes(tt)) {
        best = Math.max(best, 75);
        continue;
      }
      const d = levenshtein(qt, tt);
      const maxLen = Math.max(qt.length, tt.length, 1);
      const sim = (1 - d / maxLen) * 100;
      if (sim > 68) {
        best = Math.max(best, sim);
      }
    }
  }

  return best;
}

export function smartSearch<T extends {
  name: string;
  description?: string | null;
  brand?: string | null;
  categoryName?: string | null;
  municipality?: string | null;
  province?: string | null;
  price?: any;
  stock?: any;
  rating?: any;
  sales?: any;
}>(
  items: T[],
  query: string,
  opts?: {
    sort?: string;
    maxPrice?: number;
    location?: string;
    category?: string;
    onlyAvailable?: boolean;
  }
) {
  const q = (query || "").trim();
  let list = [...items];

  // Specific query location intent: "sapatos no Uíge" -> filter location automatically if user asked
  const normQ = normalize(q);
  let locationFilter = opts?.location;
  if ((normQ.includes("no uige") || normQ.includes("em uige") || normQ.includes("uige")) && (!locationFilter || locationFilter === "todas")) {
    locationFilter = "Uíge";
  }

  if (opts?.category && opts.category !== "todas") {
    list = list.filter((i) => normalize(i.categoryName || "") === normalize(opts.category!));
  }
  if (locationFilter && locationFilter !== "todas") {
    list = list.filter(
      (i) =>
        normalize(i.municipality || "").includes(normalize(locationFilter!)) ||
        normalize(i.province || "").includes(normalize(locationFilter!))
    );
  }
  if (opts?.maxPrice && opts.maxPrice > 0) {
    list = list.filter((i) => Number(i.price) <= opts.maxPrice!);
  }
  if (opts?.onlyAvailable) {
    list = list.filter((i) => Number(i.stock) > 0);
  }

  const wantsCheap = normQ.includes("barato") || normQ.includes("promocao") || normQ.includes("oferta") || normQ.includes("desconto");

  if (!q) {
    if (opts?.sort === "preco-asc") list.sort((a, b) => Number(a.price) - Number(b.price));
    else if (opts?.sort === "preco-desc") list.sort((a, b) => Number(b.price) - Number(a.price));
    else if (opts?.sort === "vendas") list.sort((a, b) => Number(b.sales || 0) - Number(a.sales || 0));
    else if (opts?.sort === "avaliacao") list.sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0));
    return list.map((i) => ({ item: i, score: 0 }));
  }

  const scored = list
    .map((i) => {
      const hay = `${i.name} ${i.description || ""} ${i.brand || ""} ${i.categoryName || ""} ${i.municipality || ""} ${i.province || ""}`;
      const score = fuzzyScore(q, hay);
      return { item: i, score };
    })
    .filter((s) => s.score > 35);

  scored.sort((a, b) => {
    // If the query specifically has "barato" (e.g. "iphone barato"), sort ascending by price!
    if (wantsCheap) return Number(a.item.price) - Number(b.item.price);
    if (opts?.sort === "preco-asc") return Number(a.item.price) - Number(b.item.price);
    if (opts?.sort === "preco-desc") return Number(b.item.price) - Number(a.item.price);
    if (opts?.sort === "vendas") return Number(b.item.sales || 0) - Number(a.item.sales || 0);
    return b.score - a.score;
  });

  return scored;
}

export const ANGOLA_PROVINCES = [
  "Uíge", "Luanda", "Benguela", "Huambo", "Huíla", "Cabinda", "Bengo", "Malanje",
  "Namibe", "Cuando Cubango", "Cunene", "Lunda Norte", "Lunda Sul", "Bié", "Moxico", "Zaire", "Cuanza Norte", "Cuanza Sul"
];

export const UIGE_MUNICIPALITIES = [
  "Uíge", "Negage", "Banga", "Bolongongo", "Bembe", "Canza", "Damba",
  "Maquela do Zombo", "Mucaba", "Pombo", "Quimbele", "Sanza Pombo", "Songo", "Uíge Cidade", "Ambuíla", "Quitexe"
];

export const ORDER_STATUSES = [
  "Pendente",
  "Confirmada",
  "Em preparação",
  "Pronta para levantamento",
  "Em entrega",
  "Entregue",
  "Cancelada",
] as const;

export function generateOrderCode() {
  const letters = "UG";
  const num = Math.floor(10000 + Math.random() * 90000);
  return `MU-${letters}-${num}`;
}
