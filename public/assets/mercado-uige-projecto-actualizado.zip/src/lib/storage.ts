import { Product, Store, Category, User, Order, NotificationItem, ReportItem } from "@/types";
import { SEED_CATEGORIES, SEED_STORES, SEED_PRODUCTS } from "./seed";
import { generateOrderCode } from "./utils";

const STORAGE_KEYS = {
  PRODUCTS: "mu_products_v2",
  STORES: "mu_stores_v2",
  CATEGORIES: "mu_categories_v2",
  USERS: "mu_users_v2",
  CURRENT_USER: "mu_current_user_v2",
  CART: "mu_cart_v2",
  FAVORITES: "mu_favorites_v2",
  ORDERS: "mu_orders_v2",
  NOTIFICATIONS: "mu_notifications_v2",
  REPORTS: "mu_reports_v2",
  SEARCH_HISTORY: "mu_history_v2",
  THEME: "mu_theme_mode_v2",
  LOCATION: "mu_selected_location_v2",
  ONBOARDED: "mu_onboarded_v2",
};

// Default seed users
const INITIAL_USERS: User[] = [
  {
    id: "user-seller-1",
    name: "Tech Uíge Comércio",
    email: "vendedor@mercadouige.ao",
    phone: "+244 923 111 222",
    role: "comerciante",
    province: "Uíge",
    municipality: "Uíge",
    bairro: "Centro",
    walletBalance: 12500,
    isSuspended: false,
    isVerified: true,
    createdAt: "2025-01-01T00:00:00Z",
  },
  {
    id: "user-admin-1",
    name: "Administrador Mercado Uíge",
    email: "admin@mercadouige.ao",
    phone: "+244 923 000 001",
    role: "admin",
    province: "Uíge",
    municipality: "Uíge",
    bairro: "Candombe",
    walletBalance: 85000,
    isSuspended: false,
    isVerified: true,
    createdAt: "2025-01-01T00:00:00Z",
  },
  {
    id: "user-client-1",
    name: "Manuel Afonso",
    email: "cliente@mercadouige.ao",
    phone: "+244 912 345 678",
    role: "cliente",
    province: "Uíge",
    municipality: "Uíge",
    bairro: "Papá Simão",
    walletBalance: 12500,
    isSuspended: false,
    isVerified: true,
    createdAt: "2025-02-01T00:00:00Z",
  },
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "notif-1",
    userId: "user-seller-1",
    title: "Bem-vindo ao Mercado Uíge!",
    body: "A sua conta comercial foi aprovada. Pode agora publicar produtos e expandir as suas vendas na província.",
    type: "welcome",
    isRead: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: "notif-2",
    userId: "user-seller-1",
    title: "Promoção de Café e Electrónicos",
    body: "Os produtos de informática e café do Uíge estão com destaque especial na página inicial esta semana.",
    type: "promo",
    isRead: true,
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
];

export const getStoredProducts = (): Product[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(SEED_PRODUCTS));
      return SEED_PRODUCTS;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_PRODUCTS;
  }
};

export const saveProducts = (prods: Product[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(prods));
  } catch (e) {
    console.error("Error saving products to storage", e);
  }
};

export const getStoredStores = (): Store[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STORES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(SEED_STORES));
      return SEED_STORES;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_STORES;
  }
};

export const saveStores = (stores: Store[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.STORES, JSON.stringify(stores));
  } catch (e) {
    console.error("Error saving stores", e);
  }
};

export const getStoredCategories = (): Category[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(SEED_CATEGORIES));
      return SEED_CATEGORIES;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_CATEGORIES;
  }
};

export const saveCategories = (cats: Category[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(cats));
  } catch (e) {
    console.error("Error saving categories", e);
  }
};

export const getStoredUsers = (): User[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_USERS;
  }
};

export const saveUsers = (users: User[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  } catch (e) {
    console.error("Error saving users", e);
  }
};

export const getStoredCurrentUser = (): User | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

export const saveCurrentUser = (user: User | null) => {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  } catch (e) {
    console.error("Error saving current user", e);
  }
};

export const getStoredOrders = (): Order[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ORDERS);
    if (!raw) {
      // Default demo order
      const initialOrders: Order[] = [
        {
          id: "ord-demo-1",
          code: "MU-UG-94821",
          userId: "user-seller-1",
          userName: "Tech Uíge Comércio",
          userPhone: "+244 923 111 222",
          storeId: "store-1",
          storeName: "Tech Uíge Store",
          status: "Em preparação",
          items: [
            {
              id: "item-1",
              productId: "prod-1",
              productName: "Samsung Galaxy A55 5G (256GB)",
              productImage: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=800&q=80",
              qty: 1,
              price: 182000,
              selectedVariant: "Azul Marinho",
            },
          ],
          subtotal: 182000,
          deliveryFee: 1500,
          total: 183500,
          address: "Bairro Centro, Rua do Comércio, nº 12, Uíge",
          paymentMethod: "Multicaixa Express",
          createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        },
      ];
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(initialOrders));
      return initialOrders;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveOrders = (orders: Order[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  } catch (e) {
    console.error("Error saving orders", e);
  }
};

export const getStoredNotifications = (): NotificationItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_NOTIFICATIONS;
  }
};

export const saveNotifications = (notifs: NotificationItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
  } catch (e) {
    console.error("Error saving notifications", e);
  }
};

export const getStoredReports = (): ReportItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.REPORTS);
    return raw ? JSON.parse(raw) : [
      {
        id: "rep-1",
        reporterId: "user-client-1",
        reporterName: "Manuel Afonso",
        productId: "prod-3",
        productName: "Apple iPhone 12 (Barato / Promoção)",
        reason: "Verificação de autenticidade de bateria",
        status: "pendente",
        createdAt: "2025-02-14T16:00:00Z",
      }
    ];
  } catch {
    return [];
  }
};

export const saveReports = (reports: ReportItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
  } catch (e) {
    console.error("Error saving reports", e);
  }
};

export const getStoredLocation = (): string => {
  try {
    return localStorage.getItem(STORAGE_KEYS.LOCATION) || "Uíge, Centro";
  } catch {
    return "Uíge, Centro";
  }
};

export const saveStoredLocation = (loc: string) => {
  try {
    localStorage.setItem(STORAGE_KEYS.LOCATION, loc);
  } catch {}
};
